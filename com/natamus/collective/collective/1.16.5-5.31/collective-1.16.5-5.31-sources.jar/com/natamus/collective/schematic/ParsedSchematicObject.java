package com.natamus.collective.schematic;

import com.mojang.datafixers.util.Pair;
import net.minecraft.block.BlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

public class ParsedSchematicObject {
    public List<Pair<BlockPos, BlockState>> blocks;
    public List<BlockPos> blockEntityPositions;
    public String parseMessageString;
    public boolean parsedCorrectly;

    public int offsetX;
    public int offsetY;
    public int offsetZ;

    public ParsedSchematicObject(Schematic schematic, List<Pair<BlockPos, BlockState>> b, List<BlockPos> bEP, String pMS, boolean pC) {
        blocks = b;
        blockEntityPositions = bEP;
        parseMessageString = pMS;
        parsedCorrectly = pC;

        offsetX = schematic.getOffsetX();
        offsetY = schematic.getOffsetY();
        offsetZ = schematic.getOffsetZ();
    }

    public List<Pair<BlockPos, TileEntity>> getBlockEntities(World level) {
        List<Pair<BlockPos, TileEntity>> blockEntities = new ArrayList<Pair<BlockPos, TileEntity>>();
        for (BlockPos pos : blockEntityPositions) {
            blockEntities.add(new Pair<BlockPos, TileEntity>(pos, level.getBlockEntity(pos)));
        }
        return blockEntities;
    }
}