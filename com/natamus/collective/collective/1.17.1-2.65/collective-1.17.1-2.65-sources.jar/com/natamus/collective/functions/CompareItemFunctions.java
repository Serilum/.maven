package com.natamus.collective.functions;

import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SaplingBlock;

public class CompareItemFunctions {
	public static boolean isSapling(Item item) {
		if (ItemTags.SAPLINGS.contains(item) || Block.byItem(item) instanceof SaplingBlock) {
			return true;
		}
		return false;
	}
	public static boolean isSapling(ItemStack itemstack) {
		return isSapling(itemstack.getItem());
	}
	
	public static boolean isLog(Item item) {
		if (ItemTags.LOGS.contains(item)) {
			return true;
		}
		return false;
	}
	public static boolean isLog(ItemStack itemstack) {
		return isLog(itemstack.getItem());
	}
	
	public static boolean isPlank(Item item) {
		if (ItemTags.PLANKS.contains(item)) {
			return true;
		}
		return false;
	}
	public static boolean isPlank(ItemStack itemstack) {
		return isPlank(itemstack.getItem());
	}
	
	public static boolean isChest(Item item) {
		Block block = Block.byItem(item);
		if (block.equals(Blocks.CHEST) || block.equals(Blocks.TRAPPED_CHEST)) {
			return true;
		}
		return false;
	}
	public static boolean isChest(ItemStack itemstack) {
		return isChest(itemstack.getItem());
	}
	
	public static boolean isStone(Item item) {
		if (ItemTags.STONE_CRAFTING_MATERIALS.contains(item)) {
			return true;
		}
		return false;
	}
	public static boolean isStone(ItemStack itemstack) {
		return isStone(itemstack.getItem());
	}
	
	public static boolean isSlab(Item item) {
		if (ItemTags.SLABS.contains(item)) {
			return true;
		}
		return false;
	}
	public static boolean isSlab(ItemStack itemstack) {
		return isSlab(itemstack.getItem());
	}
}
