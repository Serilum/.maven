package com.natamus.collective.functions;

import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.minecraftforge.common.ToolActions;

public class ToolFunctions {
	public static Boolean isTool(ItemStack itemstack) {
		if (itemstack == null) {
			return false;
		}
		
		Item item = itemstack.getItem();
		if (item instanceof ShovelItem || item instanceof AxeItem || item instanceof PickaxeItem || item instanceof SwordItem || item instanceof HoeItem) {
			return true;
		}
		
		String itemname = item.toString().toLowerCase();
		if (itemname.contains("_sword") || itemname.contains("_pickaxe") || itemname.contains("_axe") || itemname.contains("_shovel") || itemname.contains("_hoe")) {
			return true;
		}
		return false;
	}
	
	public static Boolean isSword(ItemStack itemstack) {
		if (itemstack.getItem() instanceof SwordItem) {
			return true;
		}
		return false;
	}
	
	public static Boolean isPickaxe(ItemStack itemstack) {
		if (itemstack.getItem() instanceof PickaxeItem || itemstack.canPerformAction(ToolActions.PICKAXE_DIG)) {
			return true;
		}
		return false;
	}
	
	public static Boolean isAxe(ItemStack itemstack) {
		if (itemstack.getItem() instanceof AxeItem || itemstack.canPerformAction(ToolActions.AXE_DIG)) {
			return true;
		}
		return false;
	}
	
	public static Boolean isShovel(ItemStack itemstack) {
		if (itemstack.getItem() instanceof ShovelItem || itemstack.canPerformAction(ToolActions.SHOVEL_DIG)) {
			return true;
		}
		return false;
	}
	
	public static Boolean isHoe(ItemStack itemstack) {
		if (itemstack.getItem() instanceof HoeItem || itemstack.canPerformAction(ToolActions.HOE_DIG)) {
			return true;
		}
		return false;
	}
}
