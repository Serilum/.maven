package com.natamus.collective.functions;

import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class TileEntityFunctions {
	public static void updateTileEntity(World world, BlockPos pos) {
		TileEntity tileentity = world.getTileEntity(pos);
		updateTileEntity(world, pos, tileentity);
	}
	public static void updateTileEntity(World world, BlockPos pos, TileEntity tileentity) {
		IBlockState state = world.getBlockState(pos);
		updateTileEntity(world, pos, state, tileentity);
	}
	public static void updateTileEntity(World world, BlockPos pos, IBlockState state, TileEntity tileentity) {
		world.markAndNotifyBlock(pos, null, state, state, 16);
		world.notifyBlockUpdate(pos, state, state, 3);
		tileentity.markDirty();
	}
}
