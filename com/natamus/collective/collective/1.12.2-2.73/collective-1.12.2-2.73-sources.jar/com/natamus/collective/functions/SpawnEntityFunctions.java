package com.natamus.collective.functions;

import com.natamus.collective.events.CollectiveEvents;

import net.minecraft.entity.Entity;
import net.minecraft.world.WorldServer;

public class SpawnEntityFunctions {
	public static void spawnEntityOnNextTick(WorldServer serverworld, Entity entity) {
		CollectiveEvents.entitiesToSpawn.get(serverworld).add(entity);
	}
	
	public static void startRidingEntityOnNextTick(WorldServer serverworld, Entity ridden, Entity rider) {
		CollectiveEvents.entitiesToRide.get(serverworld).put(ridden, rider);
	}
}
