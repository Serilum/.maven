package com.natamus.collective.functions;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class ConfigFunctions {
	public static List<String> getRawConfigValues(String modid) {
		return getRawConfigValues(modid, false);
	}
	
	public static List<String> getRawConfigValues(String modid, boolean tve) {
		String dirpath = System.getProperty("user.dir") + File.separator + "config";
		if (tve) {
			dirpath = dirpath + File.separator + "TVE";
		}
		
		File dir = new File(dirpath);
		File file = new File(dirpath + File.separator + modid + "-common.toml");
		
		List<String> values = new ArrayList<String>();
		if (dir.isDirectory() && file.isFile()) {
			try {
				String content = new String(Files.readAllBytes(Paths.get(dirpath + File.separator + modid + "-common.toml", new String[0])));
				for (String line : content.split("\n")) {
					String trimmedline = line.trim();
					if (trimmedline.startsWith("[") || trimmedline.startsWith("#")) {
						continue;
					}
					
					values.add(trimmedline);
				}
				
			} catch (IOException e) { }
		}
		
		return values;
	}
}
