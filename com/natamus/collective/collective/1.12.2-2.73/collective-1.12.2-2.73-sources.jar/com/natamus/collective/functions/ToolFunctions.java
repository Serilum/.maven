package com.natamus.collective.functions;

import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

public class ToolFunctions {
	public static Boolean isTool(ItemStack itemstack) {
		if (itemstack == null) {
			return false;
		}
		
		Item item = itemstack.getItem();
		if (item instanceof ItemSpade || item instanceof ItemAxe || item instanceof ItemPickaxe || item instanceof ItemSword || item instanceof ItemHoe) {
			return true;
		}
		
		String itemname = item.toString().toLowerCase();
		if (itemname.contains("_sword") || itemname.contains("_pickaxe") || itemname.contains("_axe") || itemname.contains("_shovel") || itemname.contains("_hoe")) {
			return true;
		}
		return false;
	}
	
	public static Boolean isSword(ItemStack itemstack) {
		if (itemstack.getItem() instanceof ItemSword) {
			return true;
		}
		return false;
	}
	
	public static Boolean isPickaxe(ItemStack itemstack) {
		if (itemstack.getItem() instanceof ItemPickaxe) {
			return true;
		}
		return false;
	}
	
	public static Boolean isAxe(ItemStack itemstack) {
		if (itemstack.getItem() instanceof ItemAxe) {
			return true;
		}
		return false;
	}
	
	public static Boolean isShovel(ItemStack itemstack) {
		if (itemstack.getItem() instanceof ItemSpade) {
			return true;
		}
		return false;
	}
	
	public static Boolean isHoe(ItemStack itemstack) {
		if (itemstack.getItem() instanceof ItemHoe) {
			return true;
		}
		return false;
	}
}
