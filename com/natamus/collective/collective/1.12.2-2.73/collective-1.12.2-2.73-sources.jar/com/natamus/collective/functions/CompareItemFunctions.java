package com.natamus.collective.functions;

import net.minecraft.block.Block;
import net.minecraft.block.BlockLog;
import net.minecraft.block.BlockSapling;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class CompareItemFunctions {
	public static boolean isSapling(Item item) {
		if (Block.getBlockFromItem(item) instanceof BlockSapling) {
			return true;
		}
		return false;
	}
	public static boolean isSapling(ItemStack itemstack) {
		return isSapling(itemstack.getItem());
	}
	
	public static boolean isLog(Item item) {
		if (Block.getBlockFromItem(item) instanceof BlockLog) {
			return true;
		}
		return false;
	}
	public static boolean isLog(ItemStack itemstack) {
		return isLog(itemstack.getItem());
	}
	
	public static boolean isPlank(Item item) {
		if (Block.getBlockFromItem(item).equals(Blocks.PLANKS)) {
			return true;
		}
		return false;
	}
	public static boolean isPlank(ItemStack itemstack) {
		return isPlank(itemstack.getItem());
	}
	
	public static boolean isChest(Item item) {
		Block block = Block.getBlockFromItem(item);
		if (block.equals(Blocks.CHEST) || block.equals(Blocks.TRAPPED_CHEST)) {
			return true;
		}
		return false;
	}
	public static boolean isChest(ItemStack itemstack) {
		return isChest(itemstack.getItem());
	}
	
	public static boolean isStone(Item item) {
		if (Block.getBlockFromItem(item).equals(Blocks.STONE)) {
			return true;
		}
		return false;
	}
	public static boolean isStone(ItemStack itemstack) {
		return isStone(itemstack.getItem());
	}
	
	public static boolean isSlab(Item item) {
		if (Block.getBlockFromItem(item).equals(Blocks.STONE_SLAB)) {
			return true;
		}
		return false;
	}
	public static boolean isSlab(ItemStack itemstack) {
		return isSlab(itemstack.getItem());
	}
}
