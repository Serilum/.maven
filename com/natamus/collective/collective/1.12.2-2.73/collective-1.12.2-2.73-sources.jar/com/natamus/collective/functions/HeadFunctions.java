package com.natamus.collective.functions;

import java.util.Base64;
import java.util.UUID;

import com.natamus.collective.data.GlobalVariables;

import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

public class HeadFunctions {
	public static ItemStack getPlayerHead(String playername, Integer amount) {
		// Head Data
		String data1 = DataFunctions.readStringFromURL(GlobalVariables.playerdataurl + playername.toLowerCase());
		if (data1 == "") {
			return null;
		}

		String[] sdata1 = data1.split("\":\"");
		String pname = sdata1[1].split("\"")[0];
		String pid = sdata1[2].split("\"")[0];
		
		String data2 = DataFunctions.readStringFromURL(GlobalVariables.skindataurl + pid);
		if (data2 == "") {
			return null;
		}
		
		String[] sdata2 = data2.replaceAll(" ", "").split("value\":\"");
		
		String tvalue = sdata2[1].split("\"")[0];
		String d = new String(Base64.getDecoder().decode((tvalue.getBytes())));
		
		String texture = new String(Base64.getEncoder().encodeToString((("{\"textures\"" + d.split("\"textures\"")[1]).getBytes())));
		String id = new UUID(texture.hashCode(), texture.hashCode()).toString();
		
		// Item creation
		ItemStack playerhead = new ItemStack(Items.SKULL, amount, 3);
		
		NBTTagCompound skullOwner = new NBTTagCompound();
		skullOwner.setString("Id", id);
		NBTTagCompound properties = new NBTTagCompound();
		NBTTagList textures = new NBTTagList();
		NBTTagCompound tex = new NBTTagCompound();
		tex.setString("Value", texture);
		textures.appendTag(tex);

		properties.setTag("textures", textures);
		skullOwner.setTag("Properties", properties);
		playerhead.setTagInfo("SkullOwner", skullOwner);
		
		//ITextComponent tcname = new StringTextComponent(pname + "'s Head");
		playerhead.setStackDisplayName(pname + "'s Head");
		
		return playerhead;
	}
	
	public static boolean hasStandardHead(String mobname) {
		if (mobname.equals("creeper") || mobname.equals("zombie") || mobname.equals("skeleton")) {
			return true;
		}
		return false;
	}
}
