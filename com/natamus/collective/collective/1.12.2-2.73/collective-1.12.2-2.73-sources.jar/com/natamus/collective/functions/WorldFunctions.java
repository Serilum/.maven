package com.natamus.collective.functions;

import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public class WorldFunctions {
	public static void setWorldTime(World world, Integer time) {
		if (time < 0 || time > 24000) {
			return;
		}
		
		Integer days = getTotalDaysPassed(world);
		world.setTotalWorldTime(time + (days*24000));
	}
	
	public static int getTotalTimePassed(World world) {
		return (int)world.getTotalWorldTime();
	}
	public static int getTotalDaysPassed(World world) {
		Integer currenttime = getTotalTimePassed(world);
		Integer days = (int)Math.floor((double)currenttime/24000);
		return days;
	}
	public static int getWorldTime(World world) {
		return getTotalTimePassed(world) - (getTotalDaysPassed(world)*24000);
	}
	
	// Dimension functions
	public static String getWorldDimensionName(World world) {
		return world.provider.getDimensionType().toString();
	}
	public static boolean isOverworld(World world) {
		return getWorldDimensionName(world).toLowerCase().endsWith("overworld");
	}
	public static boolean isNether(World world) {
		return getWorldDimensionName(world).toLowerCase().endsWith("nether");
	}
	public static boolean isEnd(World world) {
		return getWorldDimensionName(world).toLowerCase().endsWith("end");
	}
	
	/* IWorld functions
	public static World getWorldIfInstanceOfAndNotRemote(IWorld iworld) {
		if (iworld.isRemote()) {
			return null;
		}
		if (iworld instanceof World) {
			return ((World)iworld);
		}
		return null;
	}*/
	
	// Path
	public static String getWorldPath(WorldServer serverworld) {
		return serverworld.getSaveHandler().getWorldDirectory().getPath();
	}
}
