package com.natamus.collective.functions;

import java.util.Collections;
import java.util.Map;

import com.google.common.collect.ImmutableMap;
import com.natamus.collective.data.GlobalVariables;

import net.minecraft.block.Block;
import net.minecraft.block.IGrowable;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.ForgeEventFactory;

public class CropFunctions {
	public static boolean applyBonemeal(ItemStack itemstack, World world, BlockPos pos, EntityPlayer player) {
		IBlockState blockstate = world.getBlockState(pos);
		int hook = ForgeEventFactory.onApplyBonemeal(player, world, pos, blockstate, itemstack, EnumHand.MAIN_HAND);
		if (hook != 0) return hook > 0;
		
		if (blockstate.getBlock() instanceof IGrowable) {
			IGrowable igrowable = (IGrowable)blockstate.getBlock();
			if (igrowable.canGrow(world, pos, blockstate, world.isRemote)) {
				if (world instanceof WorldServer) {
					if (igrowable.canUseBonemeal(world, GlobalVariables.random, pos, blockstate)) {
						igrowable.grow((WorldServer)world, GlobalVariables.random, pos, blockstate);
					}
					
					if (!player.isCreative()) {
						itemstack.shrink(1);
					}
				}
				
				return true;
			}
		}
		
		return false;
	}
	
	public static boolean growCrop(World world, EntityPlayer player, IBlockState state, BlockPos pos) {
		if (world instanceof WorldServer == false) {
			return false;
		}
		
		ItemStack hand = player.getHeldItem(EnumHand.MAIN_HAND);
		Block block = state.getBlock();

		if (block instanceof IGrowable) {
			IGrowable igrowable = (IGrowable)block;
			while (igrowable.canGrow(world, pos, state, world.isRemote)) {
				if (!igrowable.canUseBonemeal(world, world.rand, pos, state)) {
					break;
				}
				igrowable.grow((WorldServer)world, world.rand, pos, state);
				state = world.getBlockState(pos);
				hand.shrink(1);
				if (hand.getCount() == 0) {
					break;
				}
			}
		}
		else {
			ImmutableMap<IProperty<?>, Comparable<?>> itp = state.getProperties();
			
			for (Map.Entry<IProperty<?>, Comparable<?>> entry : itp.entrySet()) {
				IProperty<?> property = entry.getKey();
				if (property instanceof PropertyInteger) {
					PropertyInteger prop = (PropertyInteger)property;
					String name = prop.getName();
					if (name.equals("age")) {
						Comparable<?> cv = state.getValue(property);
						int value = Integer.parseUnsignedInt(cv.toString());
						int max = Collections.max(prop.getAllowedValues());
						if (value == max) {
							return false;
						}
	
						while (value < max) {
							world.setBlockState(pos, world.getBlockState(pos).cycleProperty(property));
							if (!player.isCreative()) {
								hand.shrink(1);
								if (hand.getCount() == 0) {
									break;
								}
							}
							value+=1;
							
							if (!player.isSneaking()) {
								break;
							}
						}
					}
				}
			}
		}
		
		world.playEvent(2005, pos, 0);
		return true;
	}
	
	public static boolean growCactus(World world, BlockPos pos) {
		int height = world.getHeight();
		for (int y = pos.getY(); y <= height; y++) {
			BlockPos uppos = new BlockPos(pos.getX(), y, pos.getZ());
			Block block = world.getBlockState(uppos).getBlock();
			if (block != Blocks.CACTUS) {
				if (block.equals(Blocks.AIR)) {
					world.setBlockState(uppos, Blocks.CACTUS.getDefaultState());
					world.playEvent(2005, uppos, 0);
					world.playEvent(2005, uppos.up(), 0);
					return true;
				}
				break;
			}
		}
		return false;
	}
	
	public static boolean growSugarcane(World world, BlockPos pos) {
		int height = world.getHeight();
		for (int y = pos.getY(); y <= height; y++) {
			BlockPos uppos = new BlockPos(pos.getX(), y, pos.getZ());
			Block block = world.getBlockState(uppos).getBlock();
			if (block != Blocks.REEDS) {
				if (block.equals(Blocks.AIR)) {
					world.setBlockState(uppos, Blocks.REEDS.getDefaultState());
					world.playEvent(2005, uppos, 0);
					world.playEvent(2005, uppos.up(), 0);
					return true;
				}
				break;
			}
		}
		return false;
	}
	
	public static boolean growVine(World world, BlockPos pos) {
		for (int y = pos.getY(); y > 0; y--) {
			BlockPos downpos = new BlockPos(pos.getX(), y, pos.getZ());
			Block block = world.getBlockState(downpos).getBlock();
			if (block != Blocks.VINE) {
				if (block.equals(Blocks.AIR)) {
					world.setBlockState(downpos, world.getBlockState(pos));
					world.playEvent(2005, downpos, 0);
					world.playEvent(2005, downpos.down(), 0);
					return true;
				}
				break;
			}
		}
		return false;
	}
}
