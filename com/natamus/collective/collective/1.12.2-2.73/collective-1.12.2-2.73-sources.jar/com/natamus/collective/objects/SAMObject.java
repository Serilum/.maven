package com.natamus.collective.objects;

import com.natamus.collective.data.GlobalVariables;

import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;

public class SAMObject {
	public ResourceLocation fromtype;
	public ResourceLocation totype;
	public Item helditem;
	
	public double chance;
	public boolean spawner; 
	public boolean rideable;
	public boolean surface;
	
	public SAMObject(ResourceLocation fromentitytype, ResourceLocation toentitytype, Item itemtohold, double changechance, boolean mustbespawner, boolean ridenotreplace, boolean onlyonsurface) {
		fromtype = fromentitytype;
		totype = toentitytype;
		helditem = itemtohold;
		
		chance = changechance;
		spawner = mustbespawner;
		rideable = ridenotreplace;
		surface = onlyonsurface;
		
		GlobalVariables.samobjects.add(this);
		if (!GlobalVariables.activesams.contains(fromtype)) {
			GlobalVariables.activesams.add(fromtype);
		}
	}
}
