package com.natamus.collective.functions;

import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;

public class ItemFunctions {
	/*public static void generateEntityDropsFromLootTable(World world) {
		MinecraftServer server = world.getMinecraftServer();
		if (server == null) {
			return;
		}
		
		GlobalVariables.entitydrops = new HashMap<EntityType<?>, List<Item>>();
		
		FakePlayer fakeplayer = FakePlayerFactory.getMinecraft((WorldServer)world);
		BlockPos pos = new BlockPos(0, 0, 0);
		
		ItemStack lootingsword = new ItemStack(Items.DIAMOND_SWORD, 1);
		lootingsword.addEnchantment(Enchantments.LOOTING, 10);
		fakeplayer.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, lootingsword);
		
		Collection<EntityType<?>> entitytypes = ForgeRegistries.ENTITIES.valu.getValues();
		for (EntityType<?> type : entitytypes) {
			if (type == null) {
				continue;
			}
			Entity entity = type.create(world);
			if (entity == null || entity instanceof EntityLiving == false) {
				continue;
			}
			
			EntityLiving le = (EntityLiving)entity;
			ResourceLocation lootlocation = le.getType().getLootTable();
			
			LootTable loottable = server.getLootTableManager().getLootTableFromLocation(lootlocation);
			LootContext context = new LootContext.Builder((ServerWorld) world)
	                .withRandom(world.getRandom())
	                .withLuck(1000000F)
	                .withParameter(LootParameters.THIS_ENTITY, entity)
	                .withParameter(LootParameters.POSITION, pos)
	                .withParameter(LootParameters.KILLER_ENTITY, fakeplayer)
	                .withParameter(LootParameters.DAMAGE_SOURCE, DamageSource.causePlayerDamage(fakeplayer))
	                .build(LootParameterSets.ENTITY);
			
			List<Item> alldrops = new ArrayList<Item>();
			for (int n = 0; n < ConfigHandler.COLLECTIVE.loopsAmountUsedToGetAllEntityDrops.get(); n++) {
				List<ItemStack> newdrops = loottable.generate(context);
				for (ItemStack newdrop : newdrops) {
					Item newitem = newdrop.getItem();
					if (!alldrops.contains(newitem) && !newitem.equals(Items.AIR)) {
						alldrops.add(newitem);
					}
				}
			}
			
			GlobalVariables.entitydrops.put(type, alldrops);
		}
	}*/
	
	public static Boolean isTool(ItemStack itemstack) {
		return ToolFunctions.isTool(itemstack);
	}
	
	public static void shrinkGiveOrDropItemStack(EntityPlayer player, EnumHand hand, ItemStack used, ItemStack give) {
		used.shrink(1);
		
		if (used.isEmpty()) {
			Item giveitem = give.getItem();
			int maxstacksize = give.getMaxStackSize();
			List<ItemStack> inventory = player.inventory.mainInventory;
			
			boolean increased = false;
			for (int n = 0; n < inventory.size(); n++) {
				ItemStack slot = inventory.get(n);
				if (slot.getItem().equals(giveitem)) {
					int slotcount = slot.getCount();
					if (slotcount < maxstacksize) {
						slot.setCount(slotcount+1);
						increased = true;
						break;
					}
				}
			}
			
			if (!increased) {
				player.setHeldItem(hand, give);
			}
		}
		else if (!player.inventory.addItemStackToInventory(give)) {
			player.dropItem(give, false);
		}
	}
	
	public static void giveOrDropItemStack(EntityPlayer player, ItemStack give) {
		if (!player.inventory.addItemStackToInventory(give)) {
			player.dropItem(give, false);
		}
	}
	
	/*public static boolean isStoneTypeItem(Item item) {
		if (GlobalVariables.stoneblockitems.contains(item)) {
			return true;
		}
		return false;
	}*/
	
	public static String itemToReadableString(Item item, int amount) {
		String itemstring = "";
		String translationkey = item.getUnlocalizedName();
		if (translationkey.contains("block.")) {
			return BlockFunctions.blockToReadableString(Block.getBlockFromItem(item), amount);
		}
		
		String[] itemspl = translationkey.replace("item.", "").split("\\.");
		if (itemspl.length > 1) {
			itemstring = itemspl[1];
		}
		else {
			itemstring = itemspl[0];
		}
		
		itemstring = itemstring.replace("_", " ");
		if (amount > 1) {
			itemstring = itemstring + "s";
		}
		
		return itemstring;
	}
	public static String itemToReadableString(Item item) {
		return itemToReadableString(item, 1);
	}
}