package com.natamus.collective.functions;

import com.natamus.collective.data.GlobalVariables;

import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class FeatureFunctions {
	public static boolean placeBonusChest(World world, BlockPos position) {
		for (IBlockState iblockstate = world.getBlockState(position); (iblockstate.getBlock().isAir(iblockstate, world, position) || iblockstate.getBlock().isLeaves(iblockstate, world, position)) && position.getY() > 1; iblockstate = world.getBlockState(position)) {
			position = position.down();
		}
		
		if (position.getY() < 1) {
			return false;
		}
		else {
			position = position.up();
			
			for (int i = 0; i < 4; ++i) {
				BlockPos blockpos = position.add(GlobalVariables.random.nextInt(4) - GlobalVariables.random.nextInt(4), GlobalVariables.random.nextInt(3) - GlobalVariables.random.nextInt(3), GlobalVariables.random.nextInt(4) - GlobalVariables.random.nextInt(4));
				
				if (world.isAirBlock(blockpos) && world.getBlockState(blockpos.down()).isSideSolid(world, blockpos.down(), net.minecraft.util.EnumFacing.UP)) {
					world.setBlockState(blockpos, Blocks.CHEST.getDefaultState(), 2);
					TileEntity tileentity = world.getTileEntity(blockpos);
					
					if (tileentity instanceof TileEntityChest) {
						((TileEntityChest)tileentity).setLootTable(LootTableList.CHESTS_SPAWN_BONUS_CHEST, GlobalVariables.random.nextLong());
					}
					
					BlockPos blockpos1 = blockpos.east();
					BlockPos blockpos2 = blockpos.west();
					BlockPos blockpos3 = blockpos.north();
					BlockPos blockpos4 = blockpos.south();
					
					if (world.isAirBlock(blockpos2) && world.getBlockState(blockpos2.down()).isSideSolid(world, blockpos2.down(), net.minecraft.util.EnumFacing.UP)) {
						world.setBlockState(blockpos2, Blocks.TORCH.getDefaultState(), 2);
					}
					
					if (world.isAirBlock(blockpos1) && world.getBlockState(blockpos1.down()).isSideSolid(world, blockpos1.down(), net.minecraft.util.EnumFacing.UP)) {
						world.setBlockState(blockpos1, Blocks.TORCH.getDefaultState(), 2);
					}
					
					if (world.isAirBlock(blockpos3) && world.getBlockState(blockpos3.down()).isSideSolid(world, blockpos3.down(), net.minecraft.util.EnumFacing.UP)) {
						world.setBlockState(blockpos3, Blocks.TORCH.getDefaultState(), 2);
					}
					
					if (world.isAirBlock(blockpos4) && world.getBlockState(blockpos4.down()).isSideSolid(world, blockpos4.down(), net.minecraft.util.EnumFacing.UP)) {
						world.setBlockState(blockpos4, Blocks.TORCH.getDefaultState(), 2);
					}
					
					return true;
				}
			}
			
			return false;
		}
		}
}
