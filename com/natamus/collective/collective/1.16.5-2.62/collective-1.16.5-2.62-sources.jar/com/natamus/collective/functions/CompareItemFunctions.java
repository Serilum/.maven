package com.natamus.collective.functions;

import net.minecraft.block.Block;
import net.minecraft.block.SaplingBlock;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tags.ItemTags;

public class CompareItemFunctions {
	public static boolean isSapling(Item item) {
		if (ItemTags.SAPLINGS.contains(item) || Block.byItem(item) instanceof SaplingBlock) {
			return true;
		}
		return false;
	}
	public static boolean isSapling(ItemStack itemstack) {
		return isSapling(itemstack.getItem());
	}
}
