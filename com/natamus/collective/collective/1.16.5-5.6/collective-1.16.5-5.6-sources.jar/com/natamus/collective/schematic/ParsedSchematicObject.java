package com.natamus.collective.schematic;

import com.mojang.datafixers.util.Pair;
import net.minecraft.block.BlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;

import java.util.List;

public class ParsedSchematicObject {
    public List<Pair<BlockPos, BlockState>> blocks;
    public List<Pair<BlockPos, TileEntity>> blockEntities;
    public String parseMessageString;

    public ParsedSchematicObject(List<Pair<BlockPos, BlockState>> b, List<Pair<BlockPos, TileEntity>> bE, String pMS) {
        blocks = b;
        blockEntities = bE;
        parseMessageString = pMS;
    }
}