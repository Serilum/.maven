package com.natamus.collective.schematic;

import com.mojang.datafixers.util.Pair;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ParseSchematicFile {
    public static ParsedSchematicObject getParsedSchematicObject(String schematicPath, World level, BlockPos centerPos, int extraYOffset, boolean skipAir) {
        File schematicFile = new File(schematicPath);
        if(!schematicFile.exists() && schematicFile.isDirectory()) {
            return new ParsedSchematicObject(null, null, "Schematic file '" + schematicPath + "' does not exist.");
        }

        Schematic schematic = new Schematic(schematicFile);

        int maxBuildHeight = level.getMaxBuildHeight();
        int length = schematic.getLength();
        int width = schematic.getWidth();
        int height = schematic.getHeight();

        int yoffset = centerPos.getY() + extraYOffset;
        if (yoffset + height > maxBuildHeight) {
            yoffset = maxBuildHeight - height;
        }

        List<Pair<BlockPos, BlockState>> blocks = new ArrayList<Pair<BlockPos, BlockState>>();
        for (SchematicBlockObject blockObject : schematic.getBlocks()) {
            BlockState blockState = blockObject.getState();
            if (skipAir && blockState.getBlock().equals(Blocks.AIR)) {
                continue;
            }

            blocks.add(new Pair<BlockPos, BlockState>(blockObject.getPosition().offset(centerPos.getX() - (width/2), yoffset, centerPos.getZ() - (length/2)).immutable(), blockState));
        }

        List<Pair<BlockPos, TileEntity>> blockEntities = new ArrayList<Pair<BlockPos, TileEntity>>();
        for (CompoundNBT blockEntityCompoundTag : schematic.getBlockEntities()) {
            BlockPos blockPos = schematic.getBlockPosFromCompoundTag(blockEntityCompoundTag).offset(centerPos.getX() - (width/2), yoffset, centerPos.getZ() - (length/2));
            blockEntities.add(new Pair<BlockPos, TileEntity>(blockPos.immutable(), level.getBlockEntity(blockPos)));
        }

        return new ParsedSchematicObject(blocks, blockEntities, "Parsed successfully.");
    }
}
