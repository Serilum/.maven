package com.natamus.collective.schematic;

import com.mojang.brigadier.StringReader;
import com.mojang.datafixers.util.Pair;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.command.arguments.BlockStateParser;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.ListNBT;
import net.minecraft.util.math.BlockPos;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Schematic {
	private int size;
	private short width;
	private short height;
	private short length;
	private int offsetX;
	private int offsetY;
	private int offsetZ;
	private boolean oldVersion;
	private HashMap<Integer, String> palette;
	private SchematicBlockObject[] blockObjects;
	private List<CompoundNBT> blockEntities;
	private List<Pair<BlockPos, CompoundNBT>> entities;

	public Schematic(InputStream inputStream) {
		String type = "";
		try {
			CompoundNBT nbtdata = CompressedStreamTools.readCompressed(inputStream);
			inputStream.close();

			if (nbtdata.contains("Length")) {
				length = nbtdata.getShort("Length");
				width = nbtdata.getShort("Width");
				height = nbtdata.getShort("Height");
			}
			else {
				ListNBT sizeList = nbtdata.getList("size", 3);
				length = (short)sizeList.getInt(0);
				width = (short)sizeList.getInt(1);
				height = (short)sizeList.getInt(2);
			}

			size = length * width * height;

			if (nbtdata.contains("entities")) {
				type = "nbt";
			}
			else if (nbtdata.contains("DataVersion")) {
				type = "schem";
			}
			else {
				type = "schematic";
			}

			this.blockObjects = new SchematicBlockObject[size];
			this.entities = new ArrayList<Pair<BlockPos, CompoundNBT>>();

			if (type.equals("schem")) {
				byte[] blocks = nbtdata.getByteArray("BlockData");

				CompoundNBT palette = nbtdata.getCompound("Palette");
				this.palette = new HashMap<Integer, String>();
				for (String k : palette.getAllKeys()) {
					this.palette.put(palette.getInt(k), k);
				}

				int counter = 0;
				for (int i = 0; i < height; i++) {
					for (int j = 0; j < length; j++) {
						for (int k = 0; k < width; k++) {
							BlockPos pos = new BlockPos(k, i , j);
							int id = blocks[counter];

							if (id < 0) {
								id *= -1;
							}

							BlockState state = getStateFromID(id);

							blockObjects[counter] = new SchematicBlockObject(pos, state);
							counter++;
						}
					}
				}

				ListNBT tileentitynbtlist = nbtdata.getList("BlockEntities", 10);
				this.blockEntities = new ArrayList<CompoundNBT>();

				for (int i = 0; i < tileentitynbtlist.size(); i++) {
					this.blockEntities.add(tileentitynbtlist.getCompound(i));
				}

				CompoundNBT offsetCompoundNBT = nbtdata.getCompound("Metadata");
				offsetX = offsetCompoundNBT.getInt("WEOffsetX");
				offsetY = offsetCompoundNBT.getInt("WEOffsetY");
				offsetZ = offsetCompoundNBT.getInt("WEOffsetZ");

				return;
			}
			else if (type.equals("schematic")) {
				byte[] blockIDs_byte = nbtdata.getByteArray("Blocks");
				int[] blockIDs = new int[size];
				for (int x = 0; x < blockIDs_byte.length; x++) {
					blockIDs[x] = Byte.toUnsignedInt(blockIDs_byte[x]);
				}

				byte[] metadata = nbtdata.getByteArray("Data");

				int counter = 0;
				for (int i = 0; i < height; i++) {
					for (int j = 0; j < length; j++) {
						for (int k = 0; k < width; k++) {
							BlockPos pos = new BlockPos(k, i , j);
							BlockState state = getStateFromOldIds(blockIDs[counter], metadata[counter]);
							blockObjects[counter] = new SchematicBlockObject(pos, state);
							counter++;
						}
					}
				}

				ListNBT tileentitynbtlist = nbtdata.getList("TileEntities", 10);
				this.blockEntities = new ArrayList<CompoundNBT>();

				for (int i = 0; i < tileentitynbtlist.size(); i++) {
					CompoundNBT compound = tileentitynbtlist.getCompound(i);
					int i0 = compound.getInt("x");
					int i1 = compound.getInt("y");
					int i2 = compound.getInt("z");
					compound.putIntArray("Pos", new int[] {i0, i1, i2});
					this.blockEntities.add(compound);
				}

				offsetX = nbtdata.getInt("WEOffsetX");
				offsetY = nbtdata.getInt("WEOffsetY");
				offsetZ = nbtdata.getInt("WEOffsetZ");

				return;
			}
			else if (type.equals("nbt")) {
				ListNBT paletteNBTList = nbtdata.getList("palette", 10);

				this.palette = new HashMap<Integer, String>();
				for (int i = 0; i < paletteNBTList.size(); i++) {
					CompoundNBT compound = paletteNBTList.getCompound(i);
					String value = compound.getString("Name");

					if (compound.contains("Properties")) {
						StringBuilder metaData = new StringBuilder("[");

						CompoundNBT propertyCompound = compound.getCompound("Properties");
						for (String propertyKey : propertyCompound.getAllKeys()) {
							if (!metaData.toString().equals("[")) {
								metaData.append(",");
							}

							metaData.append(propertyKey).append("=").append(propertyCompound.get(propertyKey));
						}

						metaData.append("]");
						value += metaData;
					}

					this.palette.put(i, value);
				}

				this.blockEntities = new ArrayList<CompoundNBT>();

				ListNBT blocksNBTList = nbtdata.getList("blocks", 10);
				for (int i = 0; i < blocksNBTList.size(); i++) {
					CompoundNBT compound = blocksNBTList.getCompound(i);

					ListNBT posList = compound.getList("pos", 3);
					int i0 = posList.getInt(0);
					int i1 = posList.getInt(1);
					int i2 = posList.getInt(2);

					BlockPos pos = new BlockPos(i0, i1, i2);

					BlockState state = getStateFromID(compound.getInt("state"));
					blockObjects[i] = new SchematicBlockObject(pos, state);

					if (compound.contains("nbt")) {
						CompoundNBT blockEntityCompound = compound.getCompound("nbt");
						blockEntityCompound.putIntArray("Pos", new int[] {i0, i1, i2});
						blockEntityCompound.putString("Id", blockEntityCompound.getString("id"));
						blockEntityCompound.remove("id");
						this.blockEntities.add(blockEntityCompound);
					}
				}

				ListNBT entitiesNBTList = nbtdata.getList("entities", 10);
				for (int i = 0; i < entitiesNBTList.size(); i++) {
					CompoundNBT compound = entitiesNBTList.getCompound(i);

					CompoundNBT entityCompound = compound.getCompound("nbt");

					ListNBT posList = compound.getList("blockPos", 3);
					int i0 = posList.getInt(0);
					int i1 = posList.getInt(1);
					int i2 = posList.getInt(2);

					this.entities.add(new Pair<BlockPos, CompoundNBT>(new BlockPos(i0, i1, i2), entityCompound));
				}

				offsetX = 0;
				offsetY = 0;
				offsetZ = 0;

				return;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		System.err.println("Can't load " + type + " Schematic file.");
		this.width = 0;
		this.height = 0;
		this.length = 0;
		this.offsetX = 0;
		this.offsetY = 0;
		this.offsetZ = 0;
		this.size = 0;
		this.blockObjects = null;
		this.palette = null;
		this.blockEntities = null;
	}

	public boolean isOldVersion() {
		return oldVersion;
	}

	private BlockState getStateFromOldIds(int blockID, byte meta) {
		return Block.stateById(blockID);
	}

	public BlockState getBlockState(BlockPos pos) {
		for (SchematicBlockObject obj : this.blockObjects) {
			if (obj.getPosition().equals(pos)) {
				return obj.getState();
			}
		}
		return Blocks.AIR.defaultBlockState();
	}

	public int getSize() {
		return size;
	}

	public SchematicBlockObject[] getBlocks() {
		return blockObjects;
	}

	public BlockState getStateFromID(int id) {
		String iblockstateS = this.palette.get(id);

		try {
			BlockStateParser parser = new BlockStateParser(new StringReader(iblockstateS), true);
			parser.parse(false);

			return parser.getState();
		} catch (Exception ex) {
			return Blocks.AIR.defaultBlockState();
		}
	}

	public List<CompoundNBT> getBlockEntities() {
		return this.blockEntities;
	}

	public List<Pair<BlockPos, CompoundNBT>> getEntityRelativePosPairs() {
		return this.entities;
	}

	public CompoundNBT getTileEntity(BlockPos pos) {
		for (CompoundNBT compound : this.blockEntities) {
			int[] pos1 = compound.getIntArray("Pos");

			if (pos1[0] == pos.getX() && pos1[1] == pos.getY() && pos1[2] == pos.getZ()) {
				return compound;
			}
		}
		return null;
	}

	public BlockPos getBlockPosFromCompoundTag(CompoundNBT compoundTag) {
		int[] pos = compoundTag.getIntArray("Pos");
		return new BlockPos(pos[0], pos[1], pos[2]);
	}

	public short getWidth() {
		return width;
	}
	public short getHeight() {
		return height;
	}
	public short getLength() {
		return length;
	}

	public int getOffsetX() {
		return offsetX;
	}
	public int getOffsetY() {
		return offsetY;
	}
	public int getOffsetZ() {
		return offsetZ;
	}
}