package com.natamus.collective.schematic;


import com.mojang.datafixers.util.Pair;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

public class ParsedSchematicObject {
    public Schematic schematic;
    public List<Pair<BlockPos, BlockState>> blocks;
    public List<Pair<BlockPos, Entity>> entities;
    public List<BlockPos> blockEntityPositions;
    public String parseMessageString;
    public boolean parsedCorrectly;

    public int offsetX;
    public int offsetY;
    public int offsetZ;

    public ParsedSchematicObject(Schematic _schematic, List<Pair<BlockPos, BlockState>> _blocks, List<Pair<BlockPos, Entity>> _entities, List<BlockPos> _blockEntityPositions, String _parseMessageString, boolean _parsedCorrectly) {
        schematic = _schematic;
        blocks = _blocks;
        entities = _entities;
        blockEntityPositions = _blockEntityPositions;
        parseMessageString = _parseMessageString;
        parsedCorrectly = _parsedCorrectly;

        offsetX = _schematic.getOffsetX();
        offsetY = _schematic.getOffsetY();
        offsetZ = _schematic.getOffsetZ();
    }

    public void placeBlockEntitiesInWorld(World level) {
        List<CompoundNBT> compoundTags = schematic.getBlockEntities();

        int i = 0;
        for (Pair<BlockPos, TileEntity> pair : getBlockEntities(level)) {
            BlockPos pos = pair.getFirst();

            CompoundNBT compoundTag = compoundTags.get(i);
            compoundTag.remove("Pos");
            compoundTag.putString("id", compoundTag.getString("Id"));

            TileEntity blockEntity = TileEntity.loadStatic(level.getBlockState(pos), compoundTag);
            level.setBlockEntity(pos, blockEntity);
            i+=1;
        }
    }

    public List<Pair<BlockPos, TileEntity>> getBlockEntities(World level) {
        List<Pair<BlockPos, TileEntity>> blockEntities = new ArrayList<Pair<BlockPos, TileEntity>>();
        for (BlockPos pos : blockEntityPositions) {
            blockEntities.add(new Pair<BlockPos, TileEntity>(pos, level.getBlockEntity(pos)));
        }
        return blockEntities;
    }
}