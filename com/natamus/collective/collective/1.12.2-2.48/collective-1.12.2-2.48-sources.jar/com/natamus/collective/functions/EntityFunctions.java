package com.natamus.collective.functions;

import java.util.UUID;

import com.natamus.collective.data.GlobalVariables;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.AbstractHorse;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityDonkey;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityLlama;
import net.minecraft.entity.passive.EntityMule;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class EntityFunctions {
	// START: CHECK functions
	public static Boolean isHorse(Entity entity) {
		if (entity instanceof AbstractHorse) {
			return true;
		}
		return false;
	}
	
	public static boolean isModdedVillager(String entitystring) {
		String type = entitystring.split("\\[")[0];
		for (String moddedvillager : GlobalVariables.moddedvillagers) {
			if (type.equalsIgnoreCase(moddedvillager)) {
				return true;
			}
		}
		return false;
	}
	public static boolean isModdedVillager(Entity entity) {
		String entitystring = getEntityString(entity);
		return isModdedVillager(entitystring);
	}
	
	public static boolean isMilkable(Entity entity) {
		if (entity instanceof EntitySheep || entity instanceof EntityLlama || entity instanceof EntityPig || entity instanceof EntityDonkey || entity instanceof EntityHorse || entity instanceof EntityMule) {
			if (entity instanceof EntityAnimal == false) {
				return false;
			}
			
			EntityAnimal animal = (EntityAnimal)entity;
			if (animal.isChild()) {
				return false;
			}
			return true;
		}
		return false;	
	}
	// END: CHECK functions
	
	
	// START: GET functions
	public static String getEntityString(Entity entity) {
		String entitystring = "";
		
		ResourceLocation rl = EntityList.getKey(entity.getClass());
		if (rl != null) {
			entitystring = rl.toString(); // minecraft:villager, minecraft:wandering_trader
			if (entitystring.contains(":")) {
				entitystring = entitystring.split(":")[1];
			}
			
			entitystring = StringFunctions.capitalizeEveryWord(entitystring.replace("_", " ")).replace(" ", "") + "Entity";
		}
		
		return entitystring;
	}
	// END: GET functions
	
	
	// Do functions
	public static void nameEntity(Entity entity, String name) {
		if (name != "") {
			entity.setCustomNameTag(name);
		}
	}
	
	public static void addPotionEffect(Entity entity, Potion effect, Integer ms) {
		PotionEffect freeze = new PotionEffect(effect, ms/50);
		EntityLiving le = (EntityLiving)entity;
		le.addPotionEffect(freeze);
	}
	public static void removePotionEffect(Entity entity, Potion effect) {
		EntityLiving le = (EntityLiving)entity;
		le.removePotionEffect(effect);
	}
	
	public static void chargeEntity(Entity entity) {
		World world = entity.getEntityWorld();
		Vec3d evec = entity.getPositionVector();
		
		EntityLightningBolt lightning = new EntityLightningBolt(world, evec.x, evec.y, evec.z, true);
		lightning.setUniqueId(new UUID(0, (int)(GlobalVariables.random.nextInt()*1000000)));
		entity.onStruckByLightning(lightning);
		
		entity.extinguish();
	}

	public static void transferItemsBetweenEntities(Entity from, Entity to, boolean ignoremainhand) {
		if (from instanceof EntityMob == false) {
			return;
		}
		EntityMob mobfrom = (EntityMob)from;
		
		for(EntityEquipmentSlot equipmentslottype : EntityEquipmentSlot.values()) {
			if (ignoremainhand) {
				if (equipmentslottype.equals(EntityEquipmentSlot.MAINHAND)) {
					continue;
				}
			}
			
			ItemStack itemstack = mobfrom.getItemStackFromSlot(equipmentslottype);
			if (!itemstack.isEmpty()) {
				to.setItemStackToSlot(equipmentslottype, itemstack.copy());
			}
		}
	}
	public static void transferItemsBetweenEntities(Entity from, Entity to) {
		transferItemsBetweenEntities(from, to, false);
	}
	
	public static Boolean doesEntitySurviveThisDamage(EntityPlayer player, int halfheartdamage) {
		return doesEntitySurviveThisDamage((EntityLivingBase)player, halfheartdamage);
	}
	public static Boolean doesEntitySurviveThisDamage(EntityLivingBase entity, int halfheartdamage) {
		float newhealth = entity.getHealth() - (float)halfheartdamage;
		if (newhealth > 0f) {
			entity.attackEntityFrom(DamageSource.MAGIC, 0.1F);
			entity.setHealth(newhealth);
		}
		else {
			entity.attackEntityFrom(DamageSource.MAGIC, Float.MAX_VALUE);
			return false;
		}
		return true;
	}
}
