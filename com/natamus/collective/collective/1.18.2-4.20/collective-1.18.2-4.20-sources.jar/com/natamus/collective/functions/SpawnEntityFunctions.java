package com.natamus.collective.functions;

import com.natamus.collective.events.CollectiveEvents;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;

public class SpawnEntityFunctions {
	public static void spawnEntityOnNextTick(ServerLevel serverworld, Entity entity) {
		CollectiveEvents.entitiesToSpawn.get(serverworld).add(entity);
	}
	
	public static void startRidingEntityOnNextTick(ServerLevel serverworld, Entity ridden, Entity rider) {
		CollectiveEvents.entitiesToRide.get(serverworld).put(ridden, rider);
	}
}
