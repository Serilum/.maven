package com.natamus.collective.functions;

import net.minecraft.server.MinecraftServer;
import net.minecraft.util.concurrent.TickDelayedTask;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class TaskFunctions {
	public static void enqueueImmediateTask(World world, Runnable task, boolean allowClient) {
		if (world.isClientSide && allowClient) {
			task.run();
		}
		else {
			enqueueTask(world, task, 0);
		}
	}

	public static void enqueueTask(World world, Runnable task, int delay) {
    	if (!(world instanceof ServerWorld)) {
    		return;
    	}

    	MinecraftServer server = ((ServerWorld)world).getServer();
    	server.submit(new TickDelayedTask(server.getTickCount() + delay, task));
	}
}
