package com.natamus.collective.functions;

import net.minecraft.client.GameSettings;

public class GameSettingsFunctions {
    public static void setGamma(GameSettings options, double gamma) {
        options.gamma = gamma;
    }
    public static double getGamma(GameSettings options) {
        return options.gamma;
    }
}
