package com.natamus.collective.schematic;

import com.mojang.datafixers.util.Pair;
import net.minecraft.block.BlockState;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

public class ParsedSchematicObject {
    public Schematic schematic;
    public List<Pair<BlockPos, BlockState>> blocks;
    public List<BlockPos> blockEntityPositions;
    public String parseMessageString;
    public boolean parsedCorrectly;

    public int offsetX;
    public int offsetY;
    public int offsetZ;

    public ParsedSchematicObject(Schematic s, List<Pair<BlockPos, BlockState>> b, List<BlockPos> bEP, String pMS, boolean pC) {
        schematic = s;
        blocks = b;
        blockEntityPositions = bEP;
        parseMessageString = pMS;
        parsedCorrectly = pC;

        offsetX = s.getOffsetX();
        offsetY = s.getOffsetY();
        offsetZ = s.getOffsetZ();
    }

    public void placeBlockEntitiesInWorld(World level) {
        List<CompoundNBT> compoundTags = schematic.getBlockEntities();

        int i = 0;
        for (Pair<BlockPos, TileEntity> pair : getBlockEntities(level)) {
            BlockPos pos = pair.getFirst();

            CompoundNBT compoundTag = compoundTags.get(i);
            compoundTag.remove("Pos");
            compoundTag.putString("id", compoundTag.getString("Id"));

            TileEntity blockEntity = TileEntity.loadStatic(level.getBlockState(pos), compoundTag);
            level.setBlockEntity(pos, blockEntity);
            i+=1;
        }
    }

    public List<Pair<BlockPos, TileEntity>> getBlockEntities(World level) {
        List<Pair<BlockPos, TileEntity>> blockEntities = new ArrayList<Pair<BlockPos, TileEntity>>();
        for (BlockPos pos : blockEntityPositions) {
            blockEntities.add(new Pair<BlockPos, TileEntity>(pos, level.getBlockEntity(pos)));
        }
        return blockEntities;
    }
}