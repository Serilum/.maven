package com.natamus.collective.functions;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.IGrowable;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.Property;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.ForgeEventFactory;

import java.util.Collections;

public class CropFunctions {
	public static boolean applyBonemeal(ItemStack itemstack, World world, BlockPos pos, PlayerEntity player) {
		BlockState blockstate = world.getBlockState(pos);
		int hook = ForgeEventFactory.onApplyBonemeal(player, world, pos, blockstate, itemstack);
		if (hook != 0) return hook > 0;
		
		if (blockstate.getBlock() instanceof IGrowable) {
			IGrowable igrowable = (IGrowable)blockstate.getBlock();
			if (igrowable.isValidBonemealTarget(world, pos, blockstate, world.isClientSide)) {
				if (world instanceof ServerWorld) {
					if (igrowable.isBonemealSuccess(world, world.random, pos, blockstate)) {
						igrowable.performBonemeal((ServerWorld)world, world.random, pos, blockstate);
					}
					
					if (!player.isCreative()) {
						itemstack.shrink(1);
					}
				}
				
				return true;
			}
		}
		
		return false;
	}
	
	public static boolean growCrop(World world, PlayerEntity player, BlockState state, BlockPos pos) {
		if (!(world instanceof ServerWorld)) {
			return false;
		}
		
		ItemStack hand = player.getItemInHand(Hand.MAIN_HAND);
		Block block = state.getBlock();

		if (block instanceof IGrowable) {
			IGrowable igrowable = (IGrowable)block;
			while (igrowable.isValidBonemealTarget(world, pos, state, world.isClientSide)) {
				if (!igrowable.isBonemealSuccess(world, world.random, pos, state)) {
					break;
				}
				igrowable.performBonemeal((ServerWorld)world, world.random, pos, state);
				state = world.getBlockState(pos);
				hand.shrink(1);
				if (hand.getCount() == 0) {
					break;
				}
			}
		}
		else {

			for (Property<?> property : Collections.unmodifiableCollection(state.getValues().keySet())) {
				if (property instanceof IntegerProperty) {
					IntegerProperty prop = (IntegerProperty) property;
					String name = prop.getName();
					if (name.equals("age")) {
						Comparable<?> cv = state.getValues().get(property);
						int value = Integer.parseUnsignedInt(cv.toString());
						int max = Collections.max(prop.getPossibleValues());
						if (value == max) {
							return false;
						}

						while (value < max) {
							world.setBlockAndUpdate(pos, world.getBlockState(pos).cycle(property));
							if (!player.isCreative()) {
								hand.shrink(1);
								if (hand.getCount() == 0) {
									break;
								}
							}
							value += 1;

							if (!player.isShiftKeyDown()) {
								break;
							}
						}
					}
				}
			}
		}
		
		world.levelEvent(2005, pos, 0);
		return true;
	}
	
	public static boolean growCactus(World world, BlockPos pos) {
		int height = world.getHeight();
		for (int y = pos.getY(); y <= height; y++) {
			BlockPos uppos = new BlockPos(pos.getX(), y, pos.getZ());
			Block block = world.getBlockState(uppos).getBlock();
			if (block != Blocks.CACTUS) {
				if (block.equals(Blocks.AIR)) {
					world.setBlockAndUpdate(uppos, Blocks.CACTUS.defaultBlockState());
					world.levelEvent(2005, uppos, 0);
					world.levelEvent(2005, uppos.above(), 0);
					return true;
				}
				break;
			}
		}
		return false;
	}
	
	public static boolean growSugarcane(World world, BlockPos pos) {
		int height = world.getHeight();
		for (int y = pos.getY(); y <= height; y++) {
			BlockPos uppos = new BlockPos(pos.getX(), y, pos.getZ());
			Block block = world.getBlockState(uppos).getBlock();
			if (block != Blocks.SUGAR_CANE) {
				if (block.equals(Blocks.AIR)) {
					world.setBlockAndUpdate(uppos, Blocks.SUGAR_CANE.defaultBlockState());
					world.levelEvent(2005, uppos, 0);
					world.levelEvent(2005, uppos.above(), 0);
					return true;
				}
				break;
			}
		}
		return false;
	}
	
	public static boolean growVine(World world, BlockPos pos) {
		for (int y = pos.getY(); y > 0; y--) {
			BlockPos downpos = new BlockPos(pos.getX(), y, pos.getZ());
			Block block = world.getBlockState(downpos).getBlock();
			if (block != Blocks.VINE) {
				if (block.equals(Blocks.AIR)) {
					world.setBlockAndUpdate(downpos, world.getBlockState(pos));
					world.levelEvent(2005, downpos, 0);
					world.levelEvent(2005, downpos.below(), 0);
					return true;
				}
				break;
			}
		}
		return false;
	}
}
