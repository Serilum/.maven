package com.natamus.collective.functions;

import com.natamus.collective.events.CollectiveEvents;
import net.minecraft.entity.Entity;
import net.minecraft.world.server.ServerWorld;

import java.util.ArrayList;
import java.util.WeakHashMap;

public class SpawnEntityFunctions {
	public static void spawnEntityOnNextTick(ServerWorld serverworld, Entity entity) {
		if (!CollectiveEvents.entitiesToSpawn.containsKey(serverworld)) {
			CollectiveEvents.entitiesToSpawn.put(serverworld, new ArrayList<Entity>());
		}
		CollectiveEvents.entitiesToSpawn.get(serverworld).add(entity);
	}
	
	public static void startRidingEntityOnNextTick(ServerWorld serverworld, Entity ridden, Entity rider) {
		if (!CollectiveEvents.entitiesToRide.containsKey(serverworld)) {
			CollectiveEvents.entitiesToRide.put(serverworld, new WeakHashMap<Entity, Entity>());
		}
		CollectiveEvents.entitiesToRide.get(serverworld).put(ridden, rider);
	}
}
