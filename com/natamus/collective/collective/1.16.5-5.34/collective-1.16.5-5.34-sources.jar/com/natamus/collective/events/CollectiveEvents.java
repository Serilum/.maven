package com.natamus.collective.events;

import com.natamus.collective.check.RegisterMod;
import com.natamus.collective.config.ConfigHandler;
import com.natamus.collective.data.GlobalVariables;
import com.natamus.collective.functions.BlockPosFunctions;
import com.natamus.collective.functions.EntityFunctions;
import com.natamus.collective.functions.SpawnEntityFunctions;
import com.natamus.collective.functions.WorldFunctions;
import com.natamus.collective.objects.SAMObject;
import com.natamus.collective.util.Reference;
import net.minecraft.entity.AgeableEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.horse.AbstractHorseEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.WorldTickEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.LivingSpawnEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;

@EventBusSubscriber
public class CollectiveEvents {
	public static WeakHashMap<ServerWorld, List<Entity>> entitiesToSpawn = new WeakHashMap<ServerWorld, List<Entity>>();
	public static WeakHashMap<ServerWorld, WeakHashMap<Entity, Entity>> entitiesToRide = new WeakHashMap<ServerWorld, WeakHashMap<Entity, Entity>>();
	
	@SubscribeEvent
	public void onWorldLoad(WorldEvent.Load e) {
		World world = WorldFunctions.getWorldIfInstanceOfAndNotRemote(e.getWorld());
		if (world == null) {
			return;
		}

		ServerWorld serverlevel = (ServerWorld)world;
		entitiesToSpawn.put(serverlevel, new ArrayList<Entity>());
		entitiesToRide.put(serverlevel, new WeakHashMap<Entity, Entity>());
	}
	
	@SubscribeEvent
	public void onWorldTick(WorldTickEvent e) {
		World world = e.world;
		if (world.isClientSide || !e.phase.equals(Phase.END)) {
			return;
		}

		ServerWorld serverlevel = (ServerWorld)world;
		if (!entitiesToSpawn.containsKey(serverlevel)) {
			entitiesToSpawn.put(serverlevel, new ArrayList<Entity>());
		}
		else if (entitiesToSpawn.get(serverlevel).size() > 0) {
			Entity tospawn = entitiesToSpawn.get(serverlevel).get(0);

			serverlevel.addFreshEntityWithPassengers(tospawn);

			if (!entitiesToRide.containsKey(serverlevel)) {
				entitiesToRide.put(serverlevel, new WeakHashMap<Entity, Entity>());
			}
			else if (entitiesToRide.get(serverlevel).containsKey(tospawn)) {
				Entity rider = entitiesToRide.get(serverlevel).get(tospawn);

				rider.startRiding(tospawn);

				entitiesToRide.get(serverlevel).remove(tospawn);
			}

			entitiesToSpawn.get(serverlevel).remove(0);
		}
	}
	
	@SubscribeEvent
	public void onMobSpawnerSpawn(LivingSpawnEvent.SpecialSpawn e) {
		World world = WorldFunctions.getWorldIfInstanceOfAndNotRemote(e.getWorld());
		if (world == null) {
			return;
		}
		
		if (e.getSpawner() != null) {
			if (!e.isCanceled()) {
				e.getEntity().addTag(Reference.MOD_ID + ".spawner");
			}
		}
	}
	
	@SubscribeEvent
	public void onEntityJoinWorld(EntityJoinWorldEvent e) {
		World world = e.getWorld();
		if (world.isClientSide) {
			return;
		}
		
		Entity entity = e.getEntity();
		if (!(entity instanceof LivingEntity)) {
			return;
		}
		
		if (RegisterMod.shouldDoCheck) {
			if (entity instanceof PlayerEntity) {
				RegisterMod.joinWorldProcess(world, (PlayerEntity)entity);
			}
		}
		
		if (e.isCanceled()) {
			return;
		}
		
		if (GlobalVariables.samobjects.isEmpty()) {
			return;
		}
		
		Set<String> tags = entity.getTags();
		if (tags.contains(Reference.MOD_ID + ".checked")) {
			return;
		}
		entity.addTag(Reference.MOD_ID + ".checked");
		
		EntityType<?> entitytype = entity.getType();
		if (entitytype == null || !GlobalVariables.activesams.contains(entitytype)) {
			return;	
		}
		
		boolean isspawner = tags.contains(Reference.MOD_ID + ".spawner");
		
		List<SAMObject> possibles = new ArrayList<SAMObject>();
		for (SAMObject samobject : GlobalVariables.samobjects) {
			if (samobject == null) {
				continue;
			}

			if (samobject.fromtype == null) {
				continue;
			}
			if (samobject.fromtype.equals(entitytype)) {
				if ((samobject.spawner && !isspawner) || (!samobject.spawner && isspawner)) {
					continue;
				}
				possibles.add(samobject);
			}
		}
		
		int size = possibles.size();
		if (size == 0) {
			return;
		}

		boolean ageable = entity instanceof AgeableEntity;

		for (SAMObject sam : possibles) {
			double num = GlobalVariables.random.nextDouble();
			if (num > sam.chance) {
				continue;
			}
			
			Vector3d evec = entity.position();
			if (sam.surface) {
				if (!BlockPosFunctions.isOnSurface(world, evec)) {
					continue;
				}
			}
			
			Entity to = sam.totype.create(world);
			to.setLevel(world);
			to.setPos(evec.x, evec.y, evec.z);

			if (ageable && to instanceof AgeableEntity) {
				AgeableEntity am = (AgeableEntity) to;
				am.setAge(((AgeableEntity)entity).getAge());
				to = am;
			}
			
			boolean ignoremainhand = false;
			if (sam.helditem != null) {
				if (to instanceof LivingEntity) {
					LivingEntity le = (LivingEntity)to;
					if (!le.getMainHandItem().getItem().equals(sam.helditem)) {
						le.setItemInHand(Hand.MAIN_HAND, new ItemStack(sam.helditem, 1));
						ignoremainhand = true;
					}
				}
			}
			
			boolean ride = false;
			if (EntityFunctions.isHorse(to) && sam.rideable) {
				AbstractHorseEntity ah = (AbstractHorseEntity)to;
				ah.setTamed(true);
				to = ah;
				
				ride = true;
			}
			else {
				if (ConfigHandler.COLLECTIVE.transferItemsBetweenReplacedEntities.get()) {
					EntityFunctions.transferItemsBetweenEntities(entity, to, ignoremainhand);
				}
			}
			
			if (!(world instanceof ServerWorld)) {
				return;
			}
			
			ServerWorld serverworld = (ServerWorld)world;
			
			if (ride) {
				SpawnEntityFunctions.startRidingEntityOnNextTick(serverworld, to, entity); //entity.startRiding(to);
			}
			else {
				e.setCanceled(true);
			}
			
			to.addTag(Reference.MOD_ID + ".checked");
			SpawnEntityFunctions.spawnEntityOnNextTick(serverworld, to); //serverworld.addFreshEntityWithPassengers(to);

			break;
		}
	}
}