package com.natamus.collective.functions;

import net.minecraft.block.AttachedStemBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.BushBlock;
import net.minecraft.block.CropsBlock;
import net.minecraft.block.DeadBushBlock;
import net.minecraft.block.DoublePlantBlock;
import net.minecraft.block.FlowerBlock;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.NetherPortalBlock;
import net.minecraft.block.RotatedPillarBlock;
import net.minecraft.block.SaplingBlock;
import net.minecraft.block.SnowBlock;
import net.minecraft.block.StemBlock;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.block.TallGrassBlock;
import net.minecraft.tags.BlockTags;

public class CompareBlockFunctions {
	public static boolean isStoneBlock(Block block) {
        return BlockTags.BASE_STONE_OVERWORLD.contains(block);
    }
	
	public static boolean isNetherStoneBlock(Block block) {
        return BlockTags.BASE_STONE_NETHER.contains(block);
    }
	
	public static boolean isTreeLeaf(Block block, boolean withNetherVariants) {
		if (BlockTags.LEAVES.contains(block) || block instanceof LeavesBlock) {
			return true;
		}
		if (withNetherVariants) {
			if (block.equals(Blocks.NETHER_WART_BLOCK) || block.equals(Blocks.WARPED_WART_BLOCK) || block.equals(Blocks.SHROOMLIGHT)) {
				return true;
			}
		}
		if (block instanceof BushBlock) {
            return !(block instanceof CropsBlock) && !(block instanceof DeadBushBlock) && !(block instanceof DoublePlantBlock) && !(block instanceof FlowerBlock) && !(block instanceof SaplingBlock) && !(block instanceof StemBlock) && !(block instanceof AttachedStemBlock) && !(block instanceof SweetBerryBushBlock) && !(block instanceof TallGrassBlock);
		}
		return false;
	}
	public static boolean isTreeLeaf(Block block) {
		return isTreeLeaf(block, true);
	}
	
	public static boolean isTreeLog(Block block) {
        return BlockTags.LOGS.contains(block) || block instanceof RotatedPillarBlock;
    }
	
	public static boolean isSapling(Block block) {
        return BlockTags.SAPLINGS.contains(block) || block instanceof SaplingBlock;
    }
	
	public static boolean isDirtBlock(Block block) {
        return block.equals(Blocks.GRASS_BLOCK) || block.equals(Blocks.DIRT) || block.equals(Blocks.COARSE_DIRT) || block.equals(Blocks.PODZOL);
    }
	
	public static boolean isPortalBlock(Block block) {
        return block instanceof NetherPortalBlock || BlockFunctions.blockToReadableString(block).equals("portal placeholder");
    }
	
	public static boolean isAirOrOverwritableBlock(Block block) {
        return block.equals(Blocks.AIR) || (block instanceof BushBlock) || (block instanceof SnowBlock);
    }
}
