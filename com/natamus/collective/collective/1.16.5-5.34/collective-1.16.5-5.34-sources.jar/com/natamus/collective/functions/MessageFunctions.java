package com.natamus.collective.functions;

import net.minecraft.command.CommandSource;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.event.ClickEvent;
import net.minecraft.world.World;

public class MessageFunctions {
    public static void sendMessage(CommandSource source, StringTextComponent message) {
        sendMessage(source, message, false);
    }
    public static void sendMessage(PlayerEntity player, StringTextComponent message) {
        sendMessage(player, message, false);
    }

    public static void sendMessage(CommandSource source, String m, TextFormatting colour) {
        sendMessage(source, m, colour, false);
    }
    public static void sendMessage(PlayerEntity player, String m, TextFormatting colour) {
        sendMessage(player, m, colour, false);
    }

    public static void sendMessage(CommandSource source, String m, TextFormatting colour, boolean emptyline) {
        sendMessage(source, m, colour, emptyline, "");
    }
    public static void sendMessage(PlayerEntity player, String m, TextFormatting colour, boolean emptyline) {
        sendMessage(player, m, colour, emptyline, "");
    }

    public static void sendMessage(CommandSource source, String m, TextFormatting colour, String url) {
        sendMessage(source, m, colour, false, url);
    }
    public static void sendMessage(PlayerEntity player, String m, TextFormatting colour, String url) {
        sendMessage(player, m, colour, false, url);
    }

    public static void sendMessage(CommandSource source, String m, TextFormatting colour, boolean emptyline, String url) {
        if (m.isEmpty()) {
            return;
        }

        StringTextComponent message = new StringTextComponent(m);
        message.withStyle(colour);
        if (m.contains("http") || !url.isEmpty()) {
            if (url.isEmpty()) {
                for (String word : m.split(" ")) {
                    if (word.contains("http")) {
                        url = word;
                        break;
                    }
                }
            }

            if (!url.isEmpty()) {
                Style clickstyle = message.getStyle().withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, url));
                message.withStyle(clickstyle);
            }
        }
        sendMessage(source, message, emptyline);
    }
    public static void sendMessage(CommandSource source, StringTextComponent message, boolean emptyline) {
        if (emptyline) {
            source.sendSuccess(new StringTextComponent(""), false);
        }

        source.sendSuccess(message, false);
    }

    public static void sendMessage(PlayerEntity player, String m, TextFormatting colour, boolean emptyline, String url) {
        if (m.isEmpty()) {
            return;
        }

        StringTextComponent message = new StringTextComponent(m);
        message.withStyle(colour);
        if (m.contains("http") || !url.isEmpty()) {
            if (url.isEmpty()) {
                for (String word : m.split(" ")) {
                    if (word.contains("http")) {
                        url = word;
                        break;
                    }
                }
            }

            if (!url.isEmpty()) {
                Style clickstyle = message.getStyle().withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, url));
                message.withStyle(clickstyle);
            }
        }

        sendMessage(player, message, emptyline);
    }
    public static void sendMessage(PlayerEntity player, StringTextComponent message, boolean emptyline) {
        if (emptyline) {
            player.sendMessage(new StringTextComponent(""), player.getUUID());
        }

        player.sendMessage(message, player.getUUID());
    }

    public static void broadcastMessage(World world, String m, TextFormatting colour) {
        if (m.isEmpty()) {
            return;
        }

        StringTextComponent message = new StringTextComponent(m);
        message.withStyle(colour);
        broadcastMessage(world, message);
    }
    public static void broadcastMessage(World world, StringTextComponent message) {
        MinecraftServer server = world.getServer();
        if (server == null) {
            return;
        }

        for (PlayerEntity player : server.getPlayerList().getPlayers()) {
            sendMessage(player, message);
        }
    }

    public static void sendMessageToPlayersAround(World world, BlockPos p, int radius, String message, TextFormatting colour) {
        if (message.isEmpty()) {
            return;
        }

        for (Entity around : world.getEntities(null, new AxisAlignedBB(p.getX() - radius, p.getY() - radius, p.getZ() - radius, p.getX() + radius, p.getY() + radius, p.getZ() + radius))) {
            if (around instanceof PlayerEntity) {
                sendMessage((PlayerEntity) around, message, colour);
            }
        }
    }
    public static void sendMessageToPlayersAround(World world, BlockPos p, int radius, StringTextComponent message) {
        for (Entity around : world.getEntities(null, new AxisAlignedBB(p.getX() - radius, p.getY() - radius, p.getZ() - radius, p.getX() + radius, p.getY() + radius, p.getZ() + radius))) {
            if (around instanceof PlayerEntity) {
                sendMessage((PlayerEntity) around, message);
            }
        }
    }
}
