package com.natamus.collective.functions;

import net.minecraft.tileentity.SignTileEntity;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;

import java.util.ArrayList;
import java.util.List;

public class SignFunctions {
    public static List<String> getSignText(SignTileEntity signentity) {
        List<String> lines = new ArrayList<String>();

        for (ITextComponent line : signentity.messages) {
            if (line.equals(StringTextComponent.EMPTY)) {
                lines.add("");
                continue;
            }

            lines.add(line.getString());
        }

        return lines;
    }
}
