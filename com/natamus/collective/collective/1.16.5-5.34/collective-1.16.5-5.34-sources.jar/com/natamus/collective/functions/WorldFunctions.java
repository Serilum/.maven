package com.natamus.collective.functions;

import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.storage.FolderName;

public class WorldFunctions {
	public static void setWorldTime(ServerWorld serverworld, Integer time) {
		if (time < 0 || time > 24000) {
			return;
		}

		int days = getTotalDaysPassed(serverworld);
		serverworld.setDayTime(time + (days*24000)); // setDayTime
	}
	
	public static int getTotalTimePassed(ServerWorld serverworld) {
		return (int)serverworld.getDayTime();
	}
	public static int getTotalDaysPassed(ServerWorld serverworld) {
		int currenttime = getTotalTimePassed(serverworld);
		return (int)Math.floor((double)currenttime/24000);
	}
	public static int getWorldTime(ServerWorld serverworld) {
		return getTotalTimePassed(serverworld) - (getTotalDaysPassed(serverworld)*24000);
	}
	
	// Dimension functions
	public static String getWorldDimensionName(World world) {
		return world.dimension().location().toString();
	}
	public static boolean isOverworld(World world) {
		return getWorldDimensionName(world).toLowerCase().endsWith("overworld");
	}
	public static boolean isNether(World world) {
		return getWorldDimensionName(world).toLowerCase().endsWith("nether");
	}
	public static boolean isEnd(World world) {
		return getWorldDimensionName(world).toLowerCase().endsWith("end");
	}
	
	// IWorld functions
	public static World getWorldIfInstanceOfAndNotRemote(IWorld iworld) {
		if (iworld.isClientSide()) {
			return null;
		}
		if (iworld instanceof World) {
			return ((World)iworld);
		}
		return null;
	}
	
	// Path
	public static String getWorldPath(ServerWorld serverworld) {
		String worldpath = serverworld.getServer().getWorldPath(FolderName.ROOT).toString();
		return worldpath.substring(0, worldpath.length() - 2);
	}
}
