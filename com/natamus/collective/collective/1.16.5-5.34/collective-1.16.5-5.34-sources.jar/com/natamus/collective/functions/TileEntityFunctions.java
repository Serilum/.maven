package com.natamus.collective.functions;

import com.natamus.collective.data.GlobalVariables;
import net.minecraft.block.BlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.spawner.AbstractSpawner;

public class TileEntityFunctions {
	public static void updateTileEntity(World world, BlockPos pos) {
		TileEntity tileentity = world.getBlockEntity(pos); // CHECK FOR NULL
		updateTileEntity(world, pos, tileentity);
	}
	public static void updateTileEntity(World world, BlockPos pos, TileEntity tileentity) {
		BlockState state = world.getBlockState(pos);
		updateTileEntity(world, pos, state, tileentity);
	}
	public static void updateTileEntity(World world, BlockPos pos, BlockState state, TileEntity tileentity) {
		world.setBlocksDirty(pos, state, state);
		world.sendBlockUpdated(pos, state, state, 3);
		tileentity.setChanged();
	}

	public static void setMobSpawnerDelay(AbstractSpawner spawner, int delay) {
		spawner.spawnDelay = delay;
	}
	public static void resetMobSpawnerDelay(AbstractSpawner spawner, int min, int max) {
		setMobSpawnerDelay(spawner, min + GlobalVariables.random.nextInt(max - min));
	}
	public static void resetMobSpawnerDelay(AbstractSpawner spawner) {
		resetMobSpawnerDelay(spawner, 200, 800);
	}
}
