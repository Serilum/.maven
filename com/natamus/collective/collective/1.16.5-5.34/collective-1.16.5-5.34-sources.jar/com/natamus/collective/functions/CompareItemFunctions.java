package com.natamus.collective.functions;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.SaplingBlock;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tags.ItemTags;

public class CompareItemFunctions {
	public static boolean isSapling(Item item) {
        return ItemTags.SAPLINGS.contains(item) || Block.byItem(item) instanceof SaplingBlock;
    }
	public static boolean isSapling(ItemStack itemstack) {
		return isSapling(itemstack.getItem());
	}
	
	public static boolean isLog(Item item) {
        return ItemTags.LOGS.contains(item);
    }
	public static boolean isLog(ItemStack itemstack) {
		return isLog(itemstack.getItem());
	}
	
	public static boolean isPlank(Item item) {
        return ItemTags.PLANKS.contains(item);
    }
	public static boolean isPlank(ItemStack itemstack) {
		return isPlank(itemstack.getItem());
	}
	
	public static boolean isChest(Item item) {
		Block block = Block.byItem(item);
        return block.equals(Blocks.CHEST) || block.equals(Blocks.TRAPPED_CHEST);
    }
	public static boolean isChest(ItemStack itemstack) {
		return isChest(itemstack.getItem());
	}
	
	public static boolean isStone(Item item) {
        return ItemTags.STONE_CRAFTING_MATERIALS.contains(item);
    }
	public static boolean isStone(ItemStack itemstack) {
		return isStone(itemstack.getItem());
	}
	
	public static boolean isSlab(Item item) {
        return ItemTags.SLABS.contains(item);
    }
	public static boolean isSlab(ItemStack itemstack) {
		return isSlab(itemstack.getItem());
	}
}
