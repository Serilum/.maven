package com.natamus.collective.functions;

import net.minecraft.item.*;
import net.minecraftforge.common.ToolType;

public class ToolFunctions {
	public static Boolean isTool(ItemStack itemStack) {
		if (itemStack == null) {
			return false;
		}
		
		Item item = itemStack.getItem();
		if (item instanceof ShovelItem || item instanceof AxeItem || item instanceof PickaxeItem || item instanceof SwordItem || item instanceof HoeItem) {
			return true;
		}
		
		String itemname = item.toString().toLowerCase();
        return itemname.contains("_sword") || itemname.contains("_pickaxe") || itemname.contains("_axe") || itemname.contains("_shovel") || itemname.contains("_hoe");
    }
	
	public static Boolean isSword(ItemStack itemStack) {
        return itemStack.getItem() instanceof SwordItem;
    }
	
	public static Boolean isBow(ItemStack itemStack) {
        return itemStack.getItem() instanceof BowItem;
    }
	
	public static Boolean isPickaxe(ItemStack itemStack) {
        return itemStack.getItem() instanceof PickaxeItem || itemStack.getToolTypes().contains(ToolType.PICKAXE);
    }
	
	public static Boolean isAxe(ItemStack itemStack) {
        return itemStack.getItem() instanceof AxeItem || itemStack.getToolTypes().contains(ToolType.AXE);
    }
	
	public static Boolean isShovel(ItemStack itemStack) {
        return itemStack.getItem() instanceof ShovelItem || itemStack.getToolTypes().contains(ToolType.SHOVEL);
    }
	
	public static Boolean isHoe(ItemStack itemStack) {
        return itemStack.getItem() instanceof HoeItem || itemStack.getToolTypes().contains(ToolType.HOE);
    }

	public static Boolean isShears(ItemStack itemStack) {
		return itemStack.getItem() instanceof ShearsItem;
	}
}
