package com.natamus.collective.functions;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.BlockDeadBush;
import net.minecraft.block.BlockDoublePlant;
import net.minecraft.block.BlockFlower;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.BlockLog;
import net.minecraft.block.BlockSapling;
import net.minecraft.block.BlockStem;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.init.Blocks;

public class CompareBlockFunctions {
	public static boolean isTreeLeaf(Block block) {
		if (block instanceof BlockLeaves) {
			return true;
		}
		if (block instanceof BlockBush) {
			if (block instanceof BlockCrops == false && block instanceof BlockDeadBush == false && block instanceof BlockDoublePlant == false && block instanceof BlockFlower == false && block instanceof BlockSapling == false && block instanceof BlockStem == false && block instanceof BlockTallGrass == false) {
				return true;
			}
		}
		return false;
	}
	
	public static boolean isTreeLog(Block block) {
		if (block instanceof BlockLog) {
			return true;
		}
		return false;
	}
	
	public static boolean isSapling(Block block) {
		if (block instanceof BlockSapling) {
			return true;
		}
		return false;
	}
	
	public static boolean isDirtBlock(Block block) {
		if (block.equals(Blocks.GRASS) || block.equals(Blocks.DIRT)) {
			return true;
		}
		return false;
	}
}
