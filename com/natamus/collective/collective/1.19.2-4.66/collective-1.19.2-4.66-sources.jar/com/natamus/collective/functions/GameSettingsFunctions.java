package com.natamus.collective.functions;

import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraft.network.chat.Component;

import static net.minecraft.client.Options.genericValueLabel;

public class GameSettingsFunctions {
    private static boolean setGammaOnce = false;

    public static void setGamma(Options options, double gamma) {
        if (!setGammaOnce) {
            setGammaOnce = true;

            options.gamma = new OptionInstance<>("options.gamma", OptionInstance.noTooltip(), (p_231913_, p_231914_) -> {
                return genericValueLabel(p_231913_, Component.translatable("options.gamma.default"));
            }, OptionInstance.UnitDouble.INSTANCE, 0.5D, (p_231877_) -> { });
        }
        options.gamma.set(gamma);
    }
    public static double getGamma(Options options) {
        return options.gamma.get();
    }
}
