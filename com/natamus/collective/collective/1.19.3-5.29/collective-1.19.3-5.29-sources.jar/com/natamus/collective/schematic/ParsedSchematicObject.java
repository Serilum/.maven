package com.natamus.collective.schematic;

import com.mojang.datafixers.util.Pair;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

public class ParsedSchematicObject {
    public Schematic schematic;
    public List<Pair<BlockPos, BlockState>> blocks;
    public List<BlockPos> blockEntityPositions;
    public String parseMessageString;
    public boolean parsedCorrectly;

    public int offsetX;
    public int offsetY;
    public int offsetZ;

    public ParsedSchematicObject(Schematic s, List<Pair<BlockPos, BlockState>> b, List<BlockPos> bEP, String pMS, boolean pC) {
        schematic = s;
        blocks = b;
        blockEntityPositions = bEP;
        parseMessageString = pMS;
        parsedCorrectly = pC;

        offsetX = s.getOffsetX();
        offsetY = s.getOffsetY();
        offsetZ = s.getOffsetZ();
    }

    public void placeBlockEntitiesInWorld(Level level) {
        for (Pair<BlockPos, BlockEntity> pair : getBlockEntities(level)) {
            BlockPos pos = pair.getFirst();
            for (CompoundTag compoundTag : schematic.getBlockEntities()) {
                if (pos.equals(schematic.getBlockPosFromCompoundTag(compoundTag))) {
                    BlockEntity blockEntity = level.getBlockEntity(pos);
                    blockEntity.load(compoundTag);
                }
            }
        }
    }

    public List<Pair<BlockPos, BlockEntity>> getBlockEntities(Level level) {
        List<Pair<BlockPos, BlockEntity>> blockEntities = new ArrayList<Pair<BlockPos, BlockEntity>>();
        for (BlockPos pos : blockEntityPositions) {
            blockEntities.add(new Pair<BlockPos, BlockEntity>(pos, level.getBlockEntity(pos)));
        }
        return blockEntities;
    }
}