package com.natamus.collective.schematic;

import com.mojang.datafixers.util.Pair;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

public class ParsedSchematicObject {
    public List<Pair<BlockPos, BlockState>> blocks;
    public List<Pair<BlockPos, BlockEntity>> blockEntities;
    public String parseMessageString;

    public ParsedSchematicObject(List<Pair<BlockPos, BlockState>> b, List<Pair<BlockPos, BlockEntity>> bE, String pMS) {
        blocks = b;
        blockEntities = bE;
        parseMessageString = pMS;
    }
}