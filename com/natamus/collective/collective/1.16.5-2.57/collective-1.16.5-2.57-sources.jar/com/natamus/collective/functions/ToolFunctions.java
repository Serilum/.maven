package com.natamus.collective.functions;

import net.minecraft.item.AxeItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SwordItem;
import net.minecraftforge.common.ToolType;

public class ToolFunctions {
	public static Boolean isTool(ItemStack itemstack) {
		if (itemstack == null) {
			return false;
		}
		
		Item item = itemstack.getItem();
		if (item instanceof ShovelItem || item instanceof AxeItem || item instanceof PickaxeItem || item instanceof SwordItem || item instanceof HoeItem) {
			return true;
		}
		
		String itemname = item.toString().toLowerCase();
		if (itemname.contains("_sword") || itemname.contains("_pickaxe") || itemname.contains("_axe") || itemname.contains("_shovel") || itemname.contains("_hoe")) {
			return true;
		}
		return false;
	}
	
	public static Boolean isSword(ItemStack itemstack) {
		if (itemstack.getItem() instanceof SwordItem) {
			return true;
		}
		return false;
	}
	
	public static Boolean isPickaxe(ItemStack itemstack) {
		if (itemstack.getItem() instanceof PickaxeItem || itemstack.getToolTypes().contains(ToolType.PICKAXE)) {
			return true;
		}
		return false;
	}
	
	public static Boolean isAxe(ItemStack itemstack) {
		if (itemstack.getItem() instanceof AxeItem || itemstack.getToolTypes().contains(ToolType.AXE)) {
			return true;
		}
		return false;
	}
	
	public static Boolean isShovel(ItemStack itemstack) {
		if (itemstack.getItem() instanceof ShovelItem || itemstack.getToolTypes().contains(ToolType.SHOVEL)) {
			return true;
		}
		return false;
	}
	
	public static Boolean isHoe(ItemStack itemstack) {
		if (itemstack.getItem() instanceof HoeItem || itemstack.getToolTypes().contains(ToolType.HOE)) {
			return true;
		}
		return false;
	}
}
