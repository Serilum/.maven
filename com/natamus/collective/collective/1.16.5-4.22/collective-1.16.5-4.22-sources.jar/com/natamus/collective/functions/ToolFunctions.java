package com.natamus.collective.functions;

import net.minecraft.item.AxeItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SwordItem;
import net.minecraftforge.common.ToolType;

public class ToolFunctions {
	public static Boolean isTool(ItemStack itemstack) {
		if (itemstack == null) {
			return false;
		}
		
		Item item = itemstack.getItem();
		if (item instanceof ShovelItem || item instanceof AxeItem || item instanceof PickaxeItem || item instanceof SwordItem || item instanceof HoeItem) {
			return true;
		}
		
		String itemname = item.toString().toLowerCase();
        return itemname.contains("_sword") || itemname.contains("_pickaxe") || itemname.contains("_axe") || itemname.contains("_shovel") || itemname.contains("_hoe");
    }
	
	public static Boolean isSword(ItemStack itemstack) {
        return itemstack.getItem() instanceof SwordItem;
    }
	
	public static Boolean isPickaxe(ItemStack itemstack) {
        return itemstack.getItem() instanceof PickaxeItem || itemstack.getToolTypes().contains(ToolType.PICKAXE);
    }
	
	public static Boolean isAxe(ItemStack itemstack) {
        return itemstack.getItem() instanceof AxeItem || itemstack.getToolTypes().contains(ToolType.AXE);
    }
	
	public static Boolean isShovel(ItemStack itemstack) {
        return itemstack.getItem() instanceof ShovelItem || itemstack.getToolTypes().contains(ToolType.SHOVEL);
    }
	
	public static Boolean isHoe(ItemStack itemstack) {
        return itemstack.getItem() instanceof HoeItem || itemstack.getToolTypes().contains(ToolType.HOE);
    }
}
