package com.natamus.collective.functions;

import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SaplingBlock;

public class CompareItemFunctions {
	public static boolean isSapling(Item item) {
		if (ItemTags.SAPLINGS.contains(item) || Block.byItem(item) instanceof SaplingBlock) {
			return true;
		}
		return false;
	}
	public static boolean isSapling(ItemStack itemstack) {
		return isSapling(itemstack.getItem());
	}
}
