package com.natamus.collective.functions;

import net.minecraft.client.Options;

public class GameSettingsFunctions {
    public static void setGamma(Options options, double gamma) {
        options.gamma.set(gamma);
    }
}
