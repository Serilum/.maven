package com.natamus.collective.functions;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.natamus.collective.data.GlobalVariables;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.loot.LootTables;
import net.minecraft.tileentity.LockableLootTileEntity;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.World;
import net.minecraft.world.gen.Heightmap;

public class FeatureFunctions {
	public boolean placeBonusChest(World world, BlockPos blockposIn) {
		ChunkPos chunkpos = new ChunkPos(blockposIn);
		List<Integer> list = IntStream.rangeClosed(chunkpos.getMinBlockX(), chunkpos.getMaxBlockX()).boxed().collect(Collectors.toList());
		Collections.shuffle(list, GlobalVariables.random);
		List<Integer> list1 = IntStream.rangeClosed(chunkpos.getMinBlockZ(), chunkpos.getMaxBlockZ()).boxed().collect(Collectors.toList());
		Collections.shuffle(list1, GlobalVariables.random);
		BlockPos.Mutable blockpos$mutable = new BlockPos.Mutable();
		
		for(Integer integer : list) {
			for(Integer integer1 : list1) {
				blockpos$mutable.set(integer, 0, integer1);
				BlockPos blockpos = world.getHeightmapPos(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, blockpos$mutable);
				if (world.isEmptyBlock(blockpos) || world.getBlockState(blockpos).getCollisionShape(world, blockpos).isEmpty()) {
					world.setBlock(blockpos, Blocks.CHEST.defaultBlockState(), 2);
					LockableLootTileEntity.setLootTable(world, GlobalVariables.random, blockpos, LootTables.SPAWN_BONUS_CHEST);
					BlockState blockstate = Blocks.TORCH.defaultBlockState();
					
					for(Direction direction : Direction.Plane.HORIZONTAL) {
						BlockPos blockpos1 = blockpos.relative(direction);
						if (blockstate.canSurvive(world, blockpos1)) {
							world.setBlock(blockpos1, blockstate, 2);
						}
					}
					
					return true;
				}
			}
		}
		
		return false;
	}
}
