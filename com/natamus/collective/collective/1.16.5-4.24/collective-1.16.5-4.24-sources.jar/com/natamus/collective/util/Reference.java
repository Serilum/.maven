package com.natamus.collective.util;

public class Reference {
	public static final String MOD_ID = "collective";
	public static final String NAME = "Collective";
	public static final String VERSION = "4.24";
	public static final String ACCEPTED_VERSIONS = "[1.16.5]";
}
