package com.natamus.collective.functions;

import net.minecraft.block.Block;
import net.minecraft.block.BlockSapling;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class CompareItemFunctions {
	public static boolean isSapling(Item item) {
		if (Block.getBlockFromItem(item) instanceof BlockSapling) {
			return true;
		}
		return false;
	}
	public static boolean isSapling(ItemStack itemstack) {
		return isSapling(itemstack.getItem());
	}
}
