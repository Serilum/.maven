package com.natamus.collective.schematic;

import com.mojang.datafixers.util.Pair;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

public class ParsedSchematicObject {
    public List<Pair<BlockPos, BlockState>> blocks;
    public List<BlockPos> blockEntityPositions;
    public String parseMessageString;
    public boolean parsedCorrectly;

    public int offsetX;
    public int offsetY;
    public int offsetZ;

    public ParsedSchematicObject(Schematic schematic, List<Pair<BlockPos, BlockState>> b, List<BlockPos> bEP, String pMS, boolean pC) {
        blocks = b;
        blockEntityPositions = bEP;
        parseMessageString = pMS;
        parsedCorrectly = pC;

        offsetX = schematic.getOffsetX();
        offsetY = schematic.getOffsetY();
        offsetZ = schematic.getOffsetZ();
    }

    public List<Pair<BlockPos, BlockEntity>> getBlockEntities(Level level) {
        List<Pair<BlockPos, BlockEntity>> blockEntities = new ArrayList<Pair<BlockPos, BlockEntity>>();
        for (BlockPos pos : blockEntityPositions) {
            blockEntities.add(new Pair<BlockPos, BlockEntity>(pos, level.getBlockEntity(pos)));
        }
        return blockEntities;
    }
}