package com.natamus.collective.functions;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.DimensionType;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public class BlockPosFunctions {
	// START: GET functions
	public static List<BlockPos> getBlocksAround(BlockPos pos, boolean down) {
		List<BlockPos> around = new ArrayList<BlockPos>();
		around.add(pos.north());
		around.add(pos.east());
		around.add(pos.south());
		around.add(pos.west());
		around.add(pos.up());
		if (down) {
			around.add(pos.down());
		}
		return around;
	}
	
	// START: RECURSIVE GET BLOCKS
	public static List<BlockPos> getBlocksNextToEachOther(World world, BlockPos startpos, List<Block> possibleblocks) {
		List<BlockPos> checkedblocks = new ArrayList<BlockPos>();
		List<BlockPos> theblocksaround = new ArrayList<BlockPos>();
		if (possibleblocks.contains(world.getBlockState(startpos).getBlock())) {
			theblocksaround.add(startpos);
			checkedblocks.add(startpos);
		}
		
		recursiveGetNextBlocks(world, startpos, possibleblocks, theblocksaround, checkedblocks);
		return theblocksaround;
	}
	private static void recursiveGetNextBlocks(World world, BlockPos pos, List<Block> possibleblocks, List<BlockPos> theblocksaround, List<BlockPos> checkedblocks) {
		List<BlockPos> possibleblocksaround = getBlocksAround(pos, true);
		for (BlockPos pba : possibleblocksaround) {
			if (checkedblocks.contains(pba)) {
				continue;
			}
			checkedblocks.add(pba);
			
			if (possibleblocks.contains(world.getBlockState(pba).getBlock())) {
				if (!theblocksaround.contains(pba)) {
					theblocksaround.add(pba);
					recursiveGetNextBlocks(world, pba, possibleblocks, theblocksaround, checkedblocks);
				}
			}
		}
	}
	public static List<BlockPos> getBlocksNextToEachOtherMaterial(World world, BlockPos startpos, List<Material> possiblematerials) {
		List<BlockPos> checkedblocks = new ArrayList<BlockPos>();
		List<BlockPos> theblocksaround = new ArrayList<BlockPos>();
		if (possiblematerials.contains(world.getBlockState(startpos).getMaterial())) {
			theblocksaround.add(startpos);
			checkedblocks.add(startpos);
		}
		
		recursiveGetNextBlocksMaterial(world, startpos, possiblematerials, theblocksaround, checkedblocks);
		return theblocksaround;
	}
	private static void recursiveGetNextBlocksMaterial(World world, BlockPos pos, List<Material> possiblematerials, List<BlockPos> theblocksaround, List<BlockPos> checkedblocks) {
		List<BlockPos> possibleblocksaround = getBlocksAround(pos, true);
		for (BlockPos pba : possibleblocksaround) {
			if (checkedblocks.contains(pba)) {
				continue;
			}
			checkedblocks.add(pba);
			
			if (possiblematerials.contains(world.getBlockState(pba).getMaterial())) {
				if (!theblocksaround.contains(pba)) {
					theblocksaround.add(pba);
					recursiveGetNextBlocksMaterial(world, pba, possiblematerials, theblocksaround, checkedblocks);
				}
			}
		}
	}
	// END RECURSIVE GET BLOCKS
	
	public static BlockPos getSurfaceBlockPos(World world, int x, int z, DimensionType dtype) {
		BlockPos returnpos = new BlockPos(x, 255, z);
		if (!dtype.equals(DimensionType.NETHER)) {
			int maxheight = 256;
			BlockPos pos = new BlockPos(x, maxheight, z);
			for (int y = maxheight; y > 0; y--) {
				IBlockState blockstate = world.getBlockState(pos);
				Material material = blockstate.getMaterial();
				if (blockstate.getLightOpacity(world, pos) >= 15 || material.equals(Material.ICE) || material.equals(Material.PACKED_ICE)) {
					returnpos = pos.up().toImmutable();
					break;
				}
				
				pos = pos.down();
			}
		}
		else {
			int maxheight = 128;
			BlockPos pos = new BlockPos(x, 0, z);
			for (int y = 0; y < maxheight; y++) {
				IBlockState blockstate = world.getBlockState(pos);
				if (blockstate.getBlock().equals(Blocks.AIR)) {
					IBlockState upstate = world.getBlockState(pos.up());
					if (upstate.getBlock().equals(Blocks.AIR)) {
						returnpos = pos.toImmutable();
						break;
					}
				}
				
				pos = pos.up();
			}
		}
		
		return returnpos;
	}
	public static BlockPos getSurfaceBlockPos(World world, int x, int z) {
		return getSurfaceBlockPos(world, x, z, DimensionType.OVERWORLD);
	}
	
	public static BlockPos getCenterNearbyVillage(WorldServer serverworld) {
		return getNearbyVillage(serverworld, new BlockPos(0, 0, 0));
	}
	public static BlockPos getNearbyVillage(WorldServer serverworld, BlockPos nearpos) {
		return getNearbyStructure(serverworld, "Village", nearpos, 9999);
	}
	
	public static BlockPos getCenterNearbyStructure(WorldServer serverworld, String structure) {
		return getNearbyStructure(serverworld, structure, new BlockPos(0, 0, 0));
	}
	public static BlockPos getNearbyStructure(WorldServer serverworld, String structure, BlockPos nearpos) {
		return getNearbyStructure(serverworld, structure, nearpos, 9999);
	}	
	public static BlockPos getNearbyStructure(WorldServer serverworld, String structure, BlockPos nearpos, int radius) {
		BlockPos villagepos = serverworld.findNearestStructure(structure, nearpos, false);
		if (villagepos == null) {
			return null;
		}
		
		BlockPos spawnpos = null;
		for (int y = 255; y > 0; y--) {
			BlockPos checkpos = new BlockPos(villagepos.getX(), y, villagepos.getZ());
			if (serverworld.getBlockState(checkpos).getBlock().equals(Blocks.AIR)) {
				continue;
			}
			spawnpos = checkpos.up().toImmutable();
			break;
		}
		
		return spawnpos;
	}
	
	public static BlockPos getBlockPlayerIsLookingAt(World world, EntityPlayer player, boolean stopOnLiquid) {
        RayTraceResult raytraceresult = RayTraceFunctions.rayTrace(world, player, stopOnLiquid);
        double posX = raytraceresult.hitVec.x;
        double posY = Math.floor(raytraceresult.hitVec.y);
        double posZ = raytraceresult.hitVec.z;

        return new BlockPos(posX, posY, posZ);
	}
	// END: GET functions
	
	
	// START: CHECK functions
	public static Boolean isOnSurface(World world, BlockPos pos) {
		return world.canSeeSky(pos);
	}
	public static Boolean isOnSurface(World world, Vec3d vecpos) {
		return isOnSurface(world, new BlockPos(vecpos.x, vecpos.y, vecpos.z));
	}
	
	public static Boolean withinDistance(BlockPos start, BlockPos end, int distance) {
		if (withinDistance(start, end, (double)distance)) {
			return true;
		}
		return false;
	}
	public static Boolean withinDistance(BlockPos start, BlockPos end, double distance) {
		if (start.getDistance(end.getX(), end.getY(), end.getZ()) <= distance) {
			return true;
		}
		return false;
	}
	// END: CHECK functions
}