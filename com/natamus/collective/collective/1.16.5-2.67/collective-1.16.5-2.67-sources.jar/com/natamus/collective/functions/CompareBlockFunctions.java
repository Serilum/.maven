package com.natamus.collective.functions;

import net.minecraft.block.AttachedStemBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.BushBlock;
import net.minecraft.block.CropsBlock;
import net.minecraft.block.DeadBushBlock;
import net.minecraft.block.DoublePlantBlock;
import net.minecraft.block.FlowerBlock;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.NetherPortalBlock;
import net.minecraft.block.RotatedPillarBlock;
import net.minecraft.block.SaplingBlock;
import net.minecraft.block.SnowBlock;
import net.minecraft.block.StemBlock;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.block.TallGrassBlock;
import net.minecraft.tags.BlockTags;

public class CompareBlockFunctions {
	public static boolean isStoneBlock(Block block) {
		if (BlockTags.BASE_STONE_OVERWORLD.contains(block)) {
			return true;
		}
		return false;
	}
	
	public static boolean isNetherStoneBlock(Block block) {
		if (BlockTags.BASE_STONE_NETHER.contains(block)) {
			return true;
		}
		return false;
	}
	
	public static boolean isTreeLeaf(Block block, boolean withNetherVariants) {
		if (BlockTags.LEAVES.contains(block) || block instanceof LeavesBlock) {
			return true;
		}
		if (withNetherVariants) {
			if (block.equals(Blocks.NETHER_WART_BLOCK) || block.equals(Blocks.WARPED_WART_BLOCK) || block.equals(Blocks.SHROOMLIGHT)) {
				return true;
			}
		}
		if (block instanceof BushBlock) {
			if (block instanceof CropsBlock == false && block instanceof DeadBushBlock == false && block instanceof DoublePlantBlock == false && block instanceof FlowerBlock == false && block instanceof SaplingBlock == false && block instanceof StemBlock == false && block instanceof AttachedStemBlock == false && block instanceof SweetBerryBushBlock == false && block instanceof TallGrassBlock == false) {
				return true;
			}
		}
		return false;
	}
	public static boolean isTreeLeaf(Block block) {
		return isTreeLeaf(block, true);
	}
	
	public static boolean isTreeLog(Block block) {
		if (BlockTags.LOGS.contains(block) || block instanceof RotatedPillarBlock) {
			return true;
		}
		return false;
	}
	
	public static boolean isSapling(Block block) {
		if (BlockTags.SAPLINGS.contains(block) || block instanceof SaplingBlock) {
			return true;
		}
		return false;
	}
	
	public static boolean isDirtBlock(Block block) {
		if (block.equals(Blocks.GRASS_BLOCK) || block.equals(Blocks.DIRT) || block.equals(Blocks.COARSE_DIRT) || block.equals(Blocks.PODZOL)) {
			return true;
		}
		return false;
	}
	
	public static boolean isPortalBlock(Block block) {
		if (block instanceof NetherPortalBlock || BlockFunctions.blockToReadableString(block).equals("portal placeholder")) {
			return true;
		}

		return false;
	}
	
	public static boolean isAirOrOverwritableBlock(Block block) {
		if (!block.equals(Blocks.AIR) && (block instanceof BushBlock == false) && (block instanceof SnowBlock == false)) {
			return false;
		}
		return true;
	}
}
