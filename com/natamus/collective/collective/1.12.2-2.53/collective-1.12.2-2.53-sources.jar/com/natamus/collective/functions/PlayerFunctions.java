package com.natamus.collective.functions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.natamus.collective.util.Reference;

import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBed;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.JsonToNBT;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.DimensionType;
import net.minecraft.world.World;

public class PlayerFunctions {
	public static boolean respawnPlayer(World world, EntityPlayer player) {
		if (player instanceof EntityPlayerMP == false) {
			return false;
		}
		
		MinecraftServer server = world.getMinecraftServer();
		EntityPlayerMP serverplayer = (EntityPlayerMP)player;
		
	    if (serverplayer.queuedEndExit) {
	    	serverplayer.queuedEndExit = false;
	    	serverplayer = server.getPlayerList().recreatePlayerEntity(serverplayer, 0, true);
	        CriteriaTriggers.CHANGED_DIMENSION.trigger(serverplayer, DimensionType.THE_END, DimensionType.OVERWORLD);
	    }
	    else {
	        if (serverplayer.getHealth() <= 0.0F) {
	        	serverplayer = server.getPlayerList().recreatePlayerEntity(serverplayer, player.dimension, false);
	        }
	    }
	    
	    return true;
	}
	
	public static EntityPlayer matchPlayer(EntityPlayer player, String other) {
		return matchPlayer(player.getEntityWorld(), other);
	}
	public static EntityPlayer matchPlayer(World world, String other) {
		List<? extends EntityPlayer> players = world.playerEntities;

		for (EntityPlayer onlineplayer : players) {
			if (onlineplayer.getName().toLowerCase().equals(other)) {
				return onlineplayer;
			}
		}
		return null;
	}
	
	public static boolean isHoldingWater(EntityPlayer player) {
		if (player.getHeldItem(EnumHand.OFF_HAND).getItem().equals(Items.WATER_BUCKET) || player.getHeldItem(EnumHand.MAIN_HAND).getItem().equals(Items.WATER_BUCKET)) {
			return true;
		}
		return false;
	}
	
	public static boolean isJoiningWorldForTheFirstTime(EntityPlayer player, String modid) {
		String firstjointag = Reference.MOD_ID + ".firstJoin." + modid;
		
		Set<String> tags = player.getTags();
		if (tags.contains(firstjointag)) {
			return false;
		}
		
		player.addTag(firstjointag);
		
		InventoryPlayer inv = player.inventory;
		boolean isempty = true;
		for (int i=0; i < 36; i++) {
			if (!inv.getStackInSlot(i).isEmpty()) {
				isempty = false;
				break;
			}
		}
		
		if (!isempty) {
			return false;
		}
		
		World world = player.getEntityWorld();
		BlockPos wspos = world.getSpawnPoint();
		BlockPos ppos = player.getPosition();
		BlockPos cpos = new BlockPos(ppos.getX(), wspos.getY(), ppos.getZ());
		
		if (cpos.getDistance(wspos.getX(), wspos.getY(), wspos.getZ()) <= 50) {
			return true;
		}
		return false;
	}
	
	public static BlockPos getSpawnPoint(World world, EntityPlayer player) {
		Vec3d spawnvec = getSpawnVec(world, player);
		return new BlockPos(spawnvec.x, spawnvec.y, spawnvec.z);
	}
	public static Vec3d getSpawnVec(World world, EntityPlayer player) {
		BlockPos respawnlocation = world.getSpawnPoint(); // get spawn point
		Vec3d respawnvec = new Vec3d(respawnlocation.getX(), respawnlocation.getY(), respawnlocation.getZ());
		
		BlockPos bedpos = player.getBedLocation(player.dimension);
		if (bedpos != null) {
			Iterator<BlockPos> it = BlockPos.getAllInBox(bedpos.getX()-1, bedpos.getY()-1, bedpos.getZ()-1, bedpos.getX()+1, bedpos.getY()+1, bedpos.getZ()+1).iterator();
			while (it.hasNext()) {
				BlockPos np = it.next();
				IBlockState state = world.getBlockState(np);
				Block block = state.getBlock();
				if (block instanceof BlockBed) { // Found bed
					respawnvec = new Vec3d(bedpos.getX(), bedpos.getY(), bedpos.getZ());
					break;
				}
			}
		}
		
		return respawnvec;
	}
	
	// Player Gear Functions
	public static String getPlayerGearString(EntityPlayer player) {
		String skconfig = "";
		
		ItemStack offhand = player.getItemStackFromSlot(EntityEquipmentSlot.OFFHAND);
		if (!offhand.isEmpty()) {
			NBTTagCompound nbt = new NBTTagCompound();
			nbt = offhand.writeToNBT(nbt);
			String nbtstring = nbt.toString();
			skconfig += "'offhand'" + " : " + "'" + nbtstring + "',";
		}
		else {
			skconfig += "'offhand'" + " : " + "'',";
		}
		
		ItemStack head = player.getItemStackFromSlot(EntityEquipmentSlot.HEAD);
		if (!head.isEmpty()) {
			NBTTagCompound nbt = new NBTTagCompound();
			nbt = head.writeToNBT(nbt);
			String nbtstring = nbt.toString();
			skconfig += "\n" + "'head'" + " : " + "'" + nbtstring + "',";
		}
		else {
			skconfig += "\n" + "'head'" + " : " + "'',";
		}
		
		ItemStack chest = player.getItemStackFromSlot(EntityEquipmentSlot.CHEST);
		if (!chest.isEmpty()) {
			NBTTagCompound nbt = new NBTTagCompound();
			nbt = chest.writeToNBT(nbt);
			String nbtstring = nbt.toString();
			skconfig += "\n" + "'chest'" + " : " + "'" + nbtstring + "',";
		}
		else {
			skconfig += "\n" + "'chest'" + " : " + "'',";
		}
		
		ItemStack legs = player.getItemStackFromSlot(EntityEquipmentSlot.LEGS);
		if (!legs.isEmpty()) {
			NBTTagCompound nbt = new NBTTagCompound();
			nbt = legs.writeToNBT(nbt);
			String nbtstring = nbt.toString();
			skconfig += "\n" + "'legs'" + " : " + "'" + nbtstring + "',";
		}
		else {
			skconfig += "\n" + "'legs'" + " : " + "'',";
		}
		
		ItemStack feet = player.getItemStackFromSlot(EntityEquipmentSlot.FEET);
		if (!feet.isEmpty()) {
			NBTTagCompound nbt = new NBTTagCompound();
			nbt = feet.writeToNBT(nbt);
			String nbtstring = nbt.toString();
			skconfig += "\n" + "'feet'" + " : " + "'" + nbtstring + "',";
		}
		else {
			skconfig += "\n" + "'feet'" + " : " + "'',";
		}
		
		InventoryPlayer inv = player.inventory;
		for (int i=0; i < 36; i++) {
			ItemStack slot = inv.getStackInSlot(i);
			if (!slot.isEmpty()) {
				NBTTagCompound nbt = new NBTTagCompound();
				nbt = slot.writeToNBT(nbt);
				String nbtstring = nbt.toString();
				skconfig += "\n" + i + " : " + "'" + nbtstring + "',";
			}
			else {
				skconfig += "\n" + i + " : '',";
			}
		}
		
		return skconfig;
	}
	
	public static String getPlayerGearStringFromHashMap(HashMap<String, ItemStack> gear) {
		String gearstring = "";
		
		List<String> specialslots = new ArrayList<String>(Arrays.asList("offhand", "head", "chest", "legs", "feet"));
		for (String specialslot : specialslots) {
			String specialslotstring = "";
			if (gear.containsKey(specialslot)) {
				NBTTagCompound nbt = new NBTTagCompound();
				nbt = gear.get(specialslot).writeToNBT(nbt);
				specialslotstring = nbt.toString();
			}
			if (gearstring != "") {
				gearstring += "\n";
			}
			gearstring += "'" + specialslot + "'" + " : " + "'" + specialslotstring + "',";
		}
		
		List<ItemStack> emptyinventory = NonNullList.withSize(36, ItemStack.EMPTY);
		for (int i = 0; i < emptyinventory.size(); i++) {
			String itemstring = "";
			if (gear.containsKey("" + i)) {
				NBTTagCompound nbt = new NBTTagCompound();
				nbt = gear.get("" + i).writeToNBT(nbt);
				itemstring = nbt.toString();
			}
			gearstring += "\n" + i + " : '" + itemstring + "',";
		}
		
		return gearstring;
	}
	
	public static void setPlayerGearFromString(EntityPlayer player, String gearconfig) {
		String[] gearspl = gearconfig.split("\n");
		int newlinecount = gearspl.length;
		if (newlinecount < 40) {
			System.out.println("[Error] setPlayerGearFromString: The gear config does not contain 40 lines and is invalid.");
			return;
		}
		
		boolean cleared = false;
		for (String line : gearspl) {
			line = line.trim().replaceAll("\n", "");
			if (line.endsWith(",")) {
				line = line.substring(0, line.length() - 1);
			}
			
			String[] lspl = line.split(" : ");
			if (lspl.length != 2) {
				System.out.println("[Error] setPlayerGearFromString: The line '" + line + "' is invalid.");
				return;
			}
			
			String slotstring = lspl[0].replace("'", "");
			String data = lspl[1];
			data = data.substring(1, data.length() - 1);
			if (data.length() < 2) {
				continue;
			}
			
			ItemStack itemstack = null;
			try {
				NBTTagCompound newnbt = JsonToNBT.getTagFromJson(data);
				itemstack = new ItemStack(newnbt);
			} catch (Exception ex) {}
			
			if (itemstack == null) {
				System.out.println("[Error] setPlayerGearFromString: Unable to get the correct itemstack data from '" + line + "'.");
				return;				
			}
			
			if (!cleared) {
				cleared = true;
				player.inventory.clear();
			}
			
			if (NumberFunctions.isNumeric(slotstring)) {
				int slot = Integer.parseInt(slotstring);
				player.inventory.setInventorySlotContents(slot, itemstack);
				continue;
			}
			
			EntityEquipmentSlot type = null;
			if (slotstring.equals("offhand")) {
				type = EntityEquipmentSlot.OFFHAND;
			}
			else if (slotstring.equals("head")) {
				type = EntityEquipmentSlot.HEAD;
			}
			else if (slotstring.equals("chest")) {
				type = EntityEquipmentSlot.CHEST;
			}
			else if (slotstring.equals("legs")) {
				type = EntityEquipmentSlot.LEGS;
			}
			else if (slotstring.equals("feet")) {
				type = EntityEquipmentSlot.FEET;
			}
			else {
				continue;
			}

			if (type == null) {
				continue;
			}
			
			player.setItemStackToSlot(type, itemstack);
		}
	}
}
