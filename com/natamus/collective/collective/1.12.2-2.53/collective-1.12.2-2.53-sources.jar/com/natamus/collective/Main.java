package com.natamus.collective;

import com.natamus.collective.check.RegisterMod;
import com.natamus.collective.data.GlobalVariables;
import com.natamus.collective.events.EntityEvents;
import com.natamus.collective.util.Reference;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = Reference.MOD_ID, name = Reference.NAME, version = Reference.VERSION)
public class Main {
	@Instance
	public static Main instance;

	@EventHandler
	public static void PreInit(FMLPreInitializationEvent e) {
		MinecraftForge.EVENT_BUS.register(new EntityEvents());
		
		RegisterMod.register(Reference.NAME, Reference.MOD_ID, Reference.VERSION, Reference.ACCEPTED_VERSIONS);
	}
	@EventHandler
	public static void Init(FMLInitializationEvent e) {
		
	}
	@EventHandler
	public static void PostInit(FMLPostInitializationEvent e) {
		GlobalVariables.generateHashMaps();
	}
}