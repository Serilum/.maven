package com.natamus.collective.functions;

import net.minecraft.command.CommandSource;
import net.minecraft.tileentity.CommandBlockLogic;
import net.minecraft.util.math.vector.Vector2f;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.server.ServerWorld;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class CommandFunctions {
    public static String getRawCommandOutput(ServerWorld serverLevel, @Nullable Vector3d vec, String command) {
        CommandBlockLogic bcb = new CommandBlockLogic() {
            @Override @Nonnull
            public ServerWorld getLevel() {
                return serverLevel;
            }

            @Override
            public void onUpdated() { }

            @Override @Nonnull
            public Vector3d getPosition() {
                if (vec == null) {
                    return new Vector3d(0, 0, 0);
                }
                return vec;
            }

            @Override @Nonnull
            public CommandSource createCommandSourceStack() {
                return new CommandSource(this, getPosition(), Vector2f.ZERO, serverLevel, 2, "dev", new StringTextComponent("dev"), serverLevel.getServer(), null);
            }
        };

        bcb.setCommand(command);
        bcb.setTrackOutput(true);
        bcb.performCommand(serverLevel);

        return bcb.getLastOutput().getString();
    }
}
