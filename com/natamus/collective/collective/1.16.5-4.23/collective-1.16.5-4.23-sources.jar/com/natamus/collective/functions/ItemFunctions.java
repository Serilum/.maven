package com.natamus.collective.functions;

import com.natamus.collective.config.ConfigHandler;
import com.natamus.collective.data.GlobalVariables;
import net.minecraft.block.Block;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.loot.LootContext;
import net.minecraft.loot.LootParameterSets;
import net.minecraft.loot.LootParameters;
import net.minecraft.loot.LootTable;
import net.minecraft.server.MinecraftServer;
import net.minecraft.stats.Stats;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Hand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

public class ItemFunctions {
	public static void generateEntityDropsFromLootTable(World world) {
		MinecraftServer server = world.getServer();
		if (server == null) {
			return;
		}
		
		GlobalVariables.entitydrops = new HashMap<EntityType<?>, List<Item>>();
		
		FakePlayer fakeplayer = FakePlayerFactory.getMinecraft((ServerWorld)world);
		Vector3d vec = new Vector3d(0, 0, 0);
		
		ItemStack lootingsword = new ItemStack(Items.DIAMOND_SWORD, 1);
		lootingsword.enchant(Enchantments.MOB_LOOTING, 10);
		fakeplayer.setItemSlot(EquipmentSlotType.MAINHAND, lootingsword);
		
		Collection<EntityType<?>> entitytypes = ForgeRegistries.ENTITIES.getValues();
		for (EntityType<?> type : entitytypes) {
			if (type == null) {
				continue;
			}
			Entity entity = type.create(world);
			if (!(entity instanceof LivingEntity)) {
				continue;
			}
			
			LivingEntity le = (LivingEntity)entity;
			ResourceLocation lootlocation = le.getType().getDefaultLootTable();
			
			LootTable loottable = server.getLootTables().get(lootlocation);
			LootContext context = new LootContext.Builder((ServerWorld) world)
	                .withRandom(world.getRandom())
	                .withLuck(1000000F)
	                .withParameter(LootParameters.THIS_ENTITY, entity)
	                .withParameter(LootParameters.ORIGIN, vec)
	                .withParameter(LootParameters.KILLER_ENTITY, fakeplayer)
	                .withParameter(LootParameters.DAMAGE_SOURCE, DamageSource.playerAttack(fakeplayer))
	                .create(LootParameterSets.ENTITY);
			
			List<Item> alldrops = new ArrayList<Item>();
			for (int n = 0; n < ConfigHandler.COLLECTIVE.loopsAmountUsedToGetAllEntityDrops.get(); n++) {
				List<ItemStack> newdrops = loottable.getRandomItems(context);
				for (ItemStack newdrop : newdrops) {
					Item newitem = newdrop.getItem();
					if (!alldrops.contains(newitem) && !newitem.equals(Items.AIR)) {
						alldrops.add(newitem);
					}
				}
			}
			
			GlobalVariables.entitydrops.put(type, alldrops);
		}
	}
	
	public static Boolean isTool(ItemStack itemstack) {
		return ToolFunctions.isTool(itemstack);
	}
	
	public static void shrinkGiveOrDropItemStack(PlayerEntity player, Hand hand, ItemStack used, ItemStack give) {
		used.shrink(1);
		
		if (used.isEmpty()) {
			Item giveitem = give.getItem();
			int maxstacksize = give.getMaxStackSize();
			List<ItemStack> inventory = player.inventory.items;
			
			boolean increased = false;
			for (ItemStack slot : inventory) {
				if (slot.getItem().equals(giveitem)) {
					int slotcount = slot.getCount();
					if (slotcount < maxstacksize) {
						slot.setCount(slotcount + 1);
						increased = true;
						break;
					}
				}
			}
			
			if (!increased) {
				player.setItemInHand(hand, give);
			}
		}
		else if (!player.inventory.add(give)) {
			player.drop(give, false);
		}
	}
	
	public static void giveOrDropItemStack(PlayerEntity player, ItemStack give) {
		if (!player.inventory.add(give)) {
			player.drop(give, false);
		}
	}

	public void itemHurtBreakAndEvent(ItemStack itemStack, ServerPlayerEntity player, Hand hand, int damage) {
		if (!(player.abilities.instabuild)) {
			if (itemStack.isDamageableItem()) {
				damage = itemStack.getItem().damageItem(itemStack, damage, player, (player1 -> player1.broadcastBreakEvent(hand)));
				if (itemStack.hurt(damage, player.getRandom(), player)) {
					ForgeEventFactory.onPlayerDestroyItem(player, itemStack, hand);

					Item item = itemStack.getItem();
					itemStack.shrink(1);
					itemStack.setDamageValue(0);

					player.awardStat(Stats.ITEM_BROKEN.get(item));
				}
			}
		}
	}
	
	public static boolean isStoneTypeItem(Item item) {
		return GlobalVariables.stoneblockitems.contains(item);
	}
	
	public static String itemToReadableString(Item item, int amount) {
		String itemstring;
		String translationkey = item.getDescriptionId();
		if (translationkey.contains("block.")) {
			return BlockFunctions.blockToReadableString(Block.byItem(item), amount);
		}
		
		String[] itemspl = translationkey.replace("item.", "").split("\\.");
		if (itemspl.length > 1) {
			itemstring = itemspl[1];
		}
		else {
			itemstring = itemspl[0];
		}
		
		itemstring = itemstring.replace("_", " ");
		if (amount > 1) {
			itemstring = itemstring + "s";
		}
		
		return itemstring;
	}
	public static String itemToReadableString(Item item) {
		return itemToReadableString(item, 1);
	}
}