package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import com.natamus.collective_fabric.util.Reference;
import net.minecraft.class_1297;
import net.minecraft.class_1917;

@Mixin(class_1917.class)
public class BaseSpawnerMixin {
	@ModifyVariable(method = "serverTick(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;)V", at = @At(value= "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;tryAddFreshEntityWithPassengers(Lnet/minecraft/world/entity/Entity;)Z"))
	private class_1297 BaseSpawner_tick(class_1297 entity) {
		entity.method_5780(Reference.MOD_ID + ".fromspawner");
		return entity;
	}
}
