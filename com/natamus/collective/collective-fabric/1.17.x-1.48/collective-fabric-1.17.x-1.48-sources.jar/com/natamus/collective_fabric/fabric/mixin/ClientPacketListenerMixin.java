package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveChatEvents;
import net.minecraft.class_2561;
import net.minecraft.class_2635;
import net.minecraft.class_310;
import net.minecraft.class_634;

@Mixin(class_634.class)
public class ClientPacketListenerMixin {
	@Shadow private class_310 minecraft;
	
	@Inject(method = "handleChat(Lnet/minecraft/network/protocol/game/ClientboundChatPacket;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;handleChat(Lnet/minecraft/network/chat/ChatType;Lnet/minecraft/network/chat/Component;Ljava/util/UUID;)V"), cancellable = true)
	public void ClientPacketListener_handleChat(class_2635 clientboundChatPacket, CallbackInfo ci) {
		class_2561 message = clientboundChatPacket.method_11388();
		class_2561 newMessage = CollectiveChatEvents.CLIENT_CHAT_RECEIVED.invoker().onClientChat(clientboundChatPacket.method_11389(), message, clientboundChatPacket.method_29175());
		if (message != newMessage) {
			minecraft.field_1705.method_1755(clientboundChatPacket.method_11389(), newMessage, clientboundChatPacket.method_29175());
			ci.cancel();
		}
	}
}
