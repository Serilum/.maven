package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective_fabric.fabric.callbacks.CollectiveChatEvents;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_5513;

@Mixin(value = class_3244.class, priority = 900)
public abstract class ServerGamePacketListenerImplMixin {
	@Shadow public class_3222 player;
	
	@ModifyVariable(method = "handleChat(Lnet/minecraft/server/network/TextFilter$FilteredText;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayer;getDisplayName()Lnet/minecraft/network/chat/Component;", ordinal = 1), ordinal = 0)
	public class_2561 ServerGamePacketListenerImpl_handleChat(class_2561 component, class_5513.class_5837 filteredText) {
		Pair<Boolean, class_2561> pair = CollectiveChatEvents.SERVER_CHAT_RECEIVED.invoker().onServerChat(player, component, player.method_5667());
		if (pair != null) {
			component = pair.getSecond();
		}

		return component;
	}
}
