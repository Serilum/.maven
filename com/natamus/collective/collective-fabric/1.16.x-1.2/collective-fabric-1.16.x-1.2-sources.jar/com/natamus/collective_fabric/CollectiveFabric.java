package com.natamus.collective_fabric;

import java.util.ArrayList;
import java.util.HashMap;

import com.natamus.collective_fabric.check.RegisterMod;
import com.natamus.collective_fabric.config.CollectiveConfigHandler;
import com.natamus.collective_fabric.events.CollectiveEvents;
import com.natamus.collective_fabric.util.Reference;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_3218;

public class CollectiveFabric implements ModInitializer {
	@Override
	public void onInitialize() {
		System.out.println("Loading Collective Fabric.");
		
		CollectiveConfigHandler.setup();
		
		ServerTickEvents.START_WORLD_TICK.register((class_3218 world) -> {
			CollectiveEvents.entitiesToSpawn.put(world, new ArrayList<class_1297>());
			CollectiveEvents.entitiesToRide.put(world, new HashMap<class_1297, class_1297>());
			
			CollectiveEvents.onWorldTick(world);
		});
		
		ServerEntityEvents.ENTITY_LOAD.register((class_1297 entity, class_3218 world) -> {
			CollectiveEvents.onEntityJoinLevel(world, entity);
		});
		
		RegisterMod.register(Reference.NAME, Reference.MOD_ID, Reference.VERSION, Reference.ACCEPTED_VERSIONS);
	}
}
