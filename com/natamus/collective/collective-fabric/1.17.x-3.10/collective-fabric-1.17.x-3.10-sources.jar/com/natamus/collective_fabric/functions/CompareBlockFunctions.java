package com.natamus.collective_fabric.functions;

import net.minecraft.class_2195;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2302;
import net.minecraft.class_2311;
import net.minecraft.class_2320;
import net.minecraft.class_2356;
import net.minecraft.class_2397;
import net.minecraft.class_2423;
import net.minecraft.class_2465;
import net.minecraft.class_2473;
import net.minecraft.class_2488;
import net.minecraft.class_2513;
import net.minecraft.class_2526;
import net.minecraft.class_3481;
import net.minecraft.class_3830;

public class CompareBlockFunctions {
	public static boolean isStoneBlock(class_2248 block) {
		if (class_3481.field_25806.method_15141(block)) {
			return true;
		}
		return false;
	}
	
	public static boolean isNetherStoneBlock(class_2248 block) {
		if (class_3481.field_25807.method_15141(block)) {
			return true;
		}
		return false;
	}
	
	public static boolean isTreeLeaf(class_2248 block, boolean withNetherVariants) {
		if (class_3481.field_15503.method_15141(block) || block instanceof class_2397) {
			return true;
		}
		if (withNetherVariants) {
			if (block.equals(class_2246.field_10541) || block.equals(class_2246.field_22115) || block.equals(class_2246.field_22122)) {
				return true;
			}
		}
		if (block instanceof class_2261) {
			if (block instanceof class_2302 == false && block instanceof class_2311 == false && block instanceof class_2320 == false && block instanceof class_2356 == false && block instanceof class_2473 == false && block instanceof class_2513 == false && block instanceof class_2195 == false && block instanceof class_3830 == false && block instanceof class_2526 == false) {
				return true;
			}
		}
		return false;
	}
	public static boolean isTreeLeaf(class_2248 block) {
		return isTreeLeaf(block, true);
	}
	
	public static boolean isTreeLog(class_2248 block) {
		if (class_3481.field_15475.method_15141(block) || block instanceof class_2465) {
			return true;
		}
		return false;
	}
	
	public static boolean isSapling(class_2248 block) {
		if (class_3481.field_15462.method_15141(block) || block instanceof class_2473) {
			return true;
		}
		return false;
	}
	
	public static boolean isDirtBlock(class_2248 block) {
		if (block.equals(class_2246.field_10219) || block.equals(class_2246.field_10566) || block.equals(class_2246.field_10253) || block.equals(class_2246.field_10520)) {
			return true;
		}
		return false;
	}
	
	public static boolean isPortalBlock(class_2248 block) {
		if (block instanceof class_2423 || BlockFunctions.blockToReadableString(block).equals("portal placeholder")) {
			return true;
		}

		return false;
	}
	
	public static boolean isAirOrOverwritableBlock(class_2248 block) {
		if (!block.equals(class_2246.field_10124) && (block instanceof class_2261 == false) && (block instanceof class_2488 == false)) {
			return false;
		}
		return true;
	}
}
