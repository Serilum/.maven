package com.natamus.collective_fabric.fabric.callbacks;

import com.mojang.brigadier.ParseResults;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_2168;

public class CollectiveCommandEvents {
	private CollectiveCommandEvents() { }
	 
    public static final Event<CollectiveCommandEvents.On_Command_Parse> ON_COMMAND_PARSE = EventFactory.createArrayBacked(CollectiveCommandEvents.On_Command_Parse.class, callbacks -> (string, parse) -> {
        for (CollectiveCommandEvents.On_Command_Parse callback : callbacks) {
        	callback.onCommandParse(string, parse);
        }
        
        return;
    });
	
	@FunctionalInterface
	public interface On_Command_Parse {
		 void onCommandParse(String string, ParseResults<class_2168> parse);
	}
}
