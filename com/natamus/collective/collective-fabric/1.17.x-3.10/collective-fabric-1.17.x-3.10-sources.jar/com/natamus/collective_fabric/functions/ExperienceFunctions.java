package com.natamus.collective_fabric.functions;

import net.minecraft.class_1657;
import net.minecraft.class_2663;
import net.minecraft.class_3222;

public class ExperienceFunctions {
	public static boolean canConsumeXp(final class_1657 ep, final int xp) {
		if (ep.method_7337()) {
			return true;
		}
		return xp <= 0 || getPlayerXP(ep) >= xp;
	}

	public static void consumeXp(final class_1657 ep, final int xp) {
		if (xp <= 0) {
			return;
		}

		final int playerXP = getPlayerXP(ep);
		if (playerXP >= xp) {
			addPlayerXP(ep, -xp);
		}

		if (ep instanceof class_3222) {
			((class_3222) ep).field_13987.method_14364(new class_2663(ep, (byte) 9));
		}
	}

	public static int getPlayerXP(final class_1657 player) {
		return (int) (getExperienceForLevel(player.field_7520) + player.field_7510 * player.method_7349());
	}

	public static void addPlayerXP(final class_1657 player, final int amount) {
		final int experience = getPlayerXP(player) + amount;
		player.field_7495 = experience;
		player.field_7520 = getLevelForExperience(experience);
		final int expForLevel = getExperienceForLevel(player.field_7520);
		player.field_7510 = (float) (experience - expForLevel) / (float) player.method_7349();
	}

	private static int sum(final int n, final int a0, final int d) {
		return n * (2 * a0 + (n - 1) * d) / 2;
	}

	public static int getLevelForExperience(int targetXp) {
		int level = 0;
		while (true) {
			final int xpToNextLevel = xpBarCap(level);
			if (targetXp < xpToNextLevel) {
				return level;
			}
			level++;
			targetXp -= xpToNextLevel;
		}
	}

	public static int xpBarCap(final int level) {
		if (level >= 30) {
			return 112 + (level - 30) * 9;
		}

		if (level >= 15) {
			return 37 + (level - 15) * 5;
		}

		return 7 + level * 2;
	}

	public static int getExperienceForLevel(final int level) {
		if (level == 0) {
			return 0;
		}
		if (level <= 15) {
			return sum(level, 7, 2);
		}
		if (level <= 30) {
			return 315 + sum(level - 15, 37, 5);
		}
		return 1395 + sum(level - 30, 112, 9);
	}
}