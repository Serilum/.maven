package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveBlockEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_746;

@Mixin(value = class_636.class, priority = 1001)
public class MultiPlayerGameModeMixin {
	@Inject(method = "useItemOn", at = @At(value = "HEAD"), cancellable = true)
	public void MultiPlayerGameMode_useItemOn(class_746 player, class_638 level, class_1268 interactionHand, class_3965 blockHitResult, CallbackInfoReturnable<class_1269> ci) {
		if (!CollectiveBlockEvents.BLOCK_RIGHT_CLICK.invoker().onBlockRightClick(level, player, interactionHand, blockHitResult.method_17777(), blockHitResult)) {
			ci.setReturnValue(class_1269.field_5814);
		}
	}
}
