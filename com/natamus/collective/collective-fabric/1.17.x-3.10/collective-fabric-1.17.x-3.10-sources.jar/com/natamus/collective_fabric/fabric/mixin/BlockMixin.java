package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveBlockEvents;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

@Mixin(value = class_2248.class, priority = 1001)
public class BlockMixin {
	@Inject(method = "setPlacedBy", at = @At(value = "HEAD"), cancellable = true) 
	public void Block_setPlacedBy(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1309 livingEntity, class_1799 itemStack, CallbackInfo ci) {
		if (!CollectiveBlockEvents.BLOCK_PLACE.invoker().onBlockPlace(level, blockPos, blockState, livingEntity, itemStack)) {
			ci.cancel();
		}
	}
	
	@Inject(method = "playerDestroy", at = @At(value = "HEAD"), cancellable = true) 
	public void Block_playerDestroy(class_1937 level, class_1657 player, class_2338 blockPos, class_2680 blockState, class_2586 blockEntity, class_1799 itemStack, CallbackInfo ci) {
		if (!CollectiveBlockEvents.BLOCK_DESTROY.invoker().onBlockDestroy(level, player, blockPos, blockState, blockEntity, itemStack)) {
			ci.cancel();
		}
	}
}
