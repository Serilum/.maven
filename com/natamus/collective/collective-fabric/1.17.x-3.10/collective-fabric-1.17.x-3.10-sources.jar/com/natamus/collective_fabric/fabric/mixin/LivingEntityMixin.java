package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveEntityEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3532;

@Mixin(value = class_1309.class, priority = 1001)
public class LivingEntityMixin {
	@Inject(method = "tick()V", at = @At(value = "HEAD")) 
	public void LivingEntity_tick(CallbackInfo ci) {
		class_1297 entity = (class_1297)(Object)this;
		class_1937 world = (class_1937)entity.method_5770();
		
		CollectiveEntityEvents.LIVING_TICK.invoker().onTick(world, entity);
	}
	
	@Inject(method = "die(Lnet/minecraft/world/damagesource/DamageSource;)V", at = @At(value = "HEAD")) 
	public void LivingEntity_die(class_1282 damageSource, CallbackInfo ci) {
		class_1297 entity = (class_1297)(Object)this;
		class_1937 world = (class_1937)entity.method_5770();
		
		CollectiveEntityEvents.LIVING_ENTITY_DEATH.invoker().onDeath(world, entity, damageSource);
	}
	
	@Inject(method = "calculateFallDamage(FF)I", at = @At(value = "RETURN"))
	protected int LivingEntity_calculateFallDamage(float f, float g, CallbackInfoReturnable<Boolean> ci) {
		class_1309 livingEntity = (class_1309)(Object)this;
		class_1937 world = livingEntity.method_5770();
		
		if (CollectiveEntityEvents.ON_FALL_DAMAGE_CALC.invoker().onFallDamageCalc(world, livingEntity, f, g) == 0) {
			return 0;
		}
		
		class_1293 mobEffectInstance = livingEntity.method_6112(class_1294.field_5913);
		float h = mobEffectInstance == null ? 0.0F : (float)(mobEffectInstance.method_5578() + 1);
		return class_3532.method_15386((f - 3.0F - h) * g);
	}
	
	@ModifyVariable(method = "actuallyHurt(Lnet/minecraft/world/damagesource/DamageSource;F)V", at = @At(value= "INVOKE_ASSIGN", target = "Ljava/lang/Math;max(FF)F", ordinal = 0), ordinal = 0)
	private float LivingEntity_actuallyHurt(float f, class_1282 damageSource, float damage) {
		class_1309 livingEntity = (class_1309)(Object)this;
		class_1937 world = livingEntity.method_5770();

		float newDamage = CollectiveEntityEvents.ON_LIVING_DAMAGE_CALC.invoker().onLivingDamageCalc(world, livingEntity, damageSource, f);
		if (newDamage != -1 && newDamage != f) {
			return newDamage;
		}
		
		return f;
	}
	
	@Inject(method = "hurt(Lnet/minecraft/world/damagesource/DamageSource;F)Z", at = @At(value = "HEAD"), cancellable = true)
	public boolean LivingEntity_hurt(class_1282 damageSource, float f, CallbackInfoReturnable<Boolean> ci) {
		class_1309 livingEntity = (class_1309)(Object)this;
		class_1937 world = livingEntity.method_5770();

		if (!CollectiveEntityEvents.ON_LIVING_ATTACK.invoker().onLivingAttack(world, livingEntity, damageSource, f)) {
			ci.cancel();
		}

		return true;
	}
	
	@Inject(method = "dropAllDeathLoot(Lnet/minecraft/world/damagesource/DamageSource;)V", at = @At(value = "TAIL"))
	protected void dropAllDeathLoot(class_1282 damageSource, CallbackInfo ci) {
		class_1309 livingEntity = (class_1309)(Object)this;
		class_1937 world = livingEntity.method_5770();
		
		CollectiveEntityEvents.ON_ENTITY_IS_DROPPING_LOOT.invoker().onDroppingLoot(world, livingEntity, damageSource);
	}
	
	@Inject(method = "jumpFromGround", at = @At(value = "TAIL"))
	protected void LivingEntity_jumpFromGround(CallbackInfo ci) {
		class_1309 livingEntity = (class_1309)(Object)this;
		class_1937 world = livingEntity.method_5770();
		
		CollectiveEntityEvents.ON_ENTITY_IS_JUMPING.invoker().onLivingJump(world, livingEntity);
	}
}
