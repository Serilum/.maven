package com.natamus.collective_fabric.objects;

import com.natamus.collective_fabric.data.GlobalVariables;
import net.minecraft.class_1299;
import net.minecraft.class_1792;

public class SAMObject {
	public class_1299<?> fromtype;
	public class_1299<?> totype;
	public class_1792 helditem;
	
	public double chance;
	public boolean spawner;
	public boolean rideable;
	public boolean surface;
	
	public SAMObject(class_1299<?> fromentitytype, class_1299<?> toentitytype, class_1792 itemtohold, double changechance, boolean mustbespawner, boolean ridenotreplace, boolean onlyonsurface) {
		fromtype = fromentitytype;
		totype = toentitytype;
		helditem = itemtohold;
		
		chance = changechance;
		spawner = mustbespawner;
		rideable = ridenotreplace;
		surface = onlyonsurface;
		
		GlobalVariables.samobjects.add(this);
		if (!GlobalVariables.activesams.contains(fromtype)) {
			GlobalVariables.activesams.add(fromtype);
		}
	}
}
