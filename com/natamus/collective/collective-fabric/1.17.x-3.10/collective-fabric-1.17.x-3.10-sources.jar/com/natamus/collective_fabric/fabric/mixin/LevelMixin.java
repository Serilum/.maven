package com.natamus.collective_fabric.fabric.mixin;

import java.util.EnumSet;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveBlockEvents;

@Mixin(value = class_1937.class, priority = 1001)
public class LevelMixin {
	@Inject(method = "updateNeighborsAt", at = @At(value = "HEAD"), cancellable = true) 
	public void Level_updateNeighborsAt(class_2338 blockPos, class_2248 block, CallbackInfo ci) {
		class_1937 level = (class_1937)(Object)this;
		if (!CollectiveBlockEvents.NEIGHBOUR_NOTIFY.invoker().onNeighbourNotify(level, blockPos, level.method_8320(blockPos), EnumSet.allOf(class_2350.class), false)) {
			ci.cancel();
		}
	}
	
	@Inject(method = "updateNeighborsAtExceptFromFacing", at = @At(value = "HEAD"), cancellable = true) 
	public void Level_updateNeighborsAtExceptFromFacing(class_2338 blockPos, class_2248 block, class_2350 direction, CallbackInfo ci) {
		class_1937 level = (class_1937)(Object)this;
		EnumSet<class_2350> directions = EnumSet.allOf(class_2350.class);
		directions.remove(direction);
		if (!CollectiveBlockEvents.NEIGHBOUR_NOTIFY.invoker().onNeighbourNotify(level, blockPos, level.method_8320(blockPos), directions, false)) {
			ci.cancel();
		}
	}
}
