package com.natamus.collective_fabric.functions;

import com.natamus.collective_fabric.events.CollectiveEvents;
import net.minecraft.class_1297;
import net.minecraft.class_3218;

public class SpawnEntityFunctions {
	public static void spawnEntityOnNextTick(class_3218 serverworld, class_1297 entity) {
		CollectiveEvents.entitiesToSpawn.get(serverworld).add(entity);
	}
	
	public static void startRidingEntityOnNextTick(class_3218 serverworld, class_1297 ridden, class_1297 rider) {
		CollectiveEvents.entitiesToRide.get(serverworld).put(ridden, rider);
	}
}
