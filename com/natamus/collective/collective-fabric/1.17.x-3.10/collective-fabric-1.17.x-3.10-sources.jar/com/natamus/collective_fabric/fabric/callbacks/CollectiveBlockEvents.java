package com.natamus.collective_fabric.fabric.callbacks;

import java.util.EnumSet;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2424;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public class CollectiveBlockEvents {
	private CollectiveBlockEvents() { }
	 
    public static final Event<CollectiveBlockEvents.On_Block_Place> BLOCK_PLACE = EventFactory.createArrayBacked(CollectiveBlockEvents.On_Block_Place.class, callbacks -> (level, blockPos, blockState, livingEntity, itemStack) -> {
        for (CollectiveBlockEvents.On_Block_Place callback : callbacks) {
        	if (!callback.onBlockPlace(level, blockPos, blockState, livingEntity, itemStack)) {
        		return false;
        	}
        }
        
        return true;
    });
    
    public static final Event<CollectiveBlockEvents.On_Block_Destroy> BLOCK_DESTROY = EventFactory.createArrayBacked(CollectiveBlockEvents.On_Block_Destroy.class, callbacks -> (level, player, blockPos, blockState, blockEntity, itemStack) -> {
        for (CollectiveBlockEvents.On_Block_Destroy callback : callbacks) {
        	if (!callback.onBlockDestroy(level, player, blockPos, blockState, blockEntity, itemStack)) {
        		return false;
        	}
        }
        
        return true;
    });
    
    public static final Event<CollectiveBlockEvents.On_Neighbour_Notify> NEIGHBOUR_NOTIFY = EventFactory.createArrayBacked(CollectiveBlockEvents.On_Neighbour_Notify.class, callbacks -> (world, pos, state, notifiedSides, forceRedstoneUpdate) -> {
        for (CollectiveBlockEvents.On_Neighbour_Notify callback : callbacks) {
        	if (!callback.onNeighbourNotify(world, pos, state, notifiedSides, forceRedstoneUpdate)) {
        		return false;
        	}
        }
        
        return true;
    });
	
    public static final Event<CollectiveBlockEvents.Possible_Portal_Spawn> ON_NETHER_PORTAL_SPAWN = EventFactory.createArrayBacked(CollectiveBlockEvents.Possible_Portal_Spawn.class, callbacks -> (world, pos, shape) -> {
        for (CollectiveBlockEvents.Possible_Portal_Spawn callback : callbacks) {
        	callback.onPossiblePortal(world, pos, shape);
        }
    });
    
    public static final Event<CollectiveBlockEvents.Block_Right_Click> BLOCK_RIGHT_CLICK = EventFactory.createArrayBacked(CollectiveBlockEvents.Block_Right_Click.class, callbacks -> (world, player, hand, pos, hitVec) -> {
        for (CollectiveBlockEvents.Block_Right_Click callback : callbacks) {
        	if (!callback.onBlockRightClick(world, player, hand, pos, hitVec)) {
        		return false;
        	}
        }
        
        return true;
    });
    
	@FunctionalInterface
	public interface On_Block_Place {
		 boolean onBlockPlace(class_1937 level, class_2338 blockPos, class_2680 blockState, class_1309 livingEntity, class_1799 itemStack);
	}
	
	@FunctionalInterface
	public interface On_Block_Destroy {
		 boolean onBlockDestroy(class_1937 level, class_1657 player, class_2338 blockPos, class_2680 blockState, class_2586 blockEntity, class_1799 itemStack);
	}
	
	@FunctionalInterface
	public interface On_Neighbour_Notify {
		 boolean onNeighbourNotify(class_1937 world, class_2338 pos, class_2680 state, EnumSet<class_2350> notifiedSides, boolean forceRedstoneUpdate);
	}
    
	@FunctionalInterface
	public interface Possible_Portal_Spawn {
		 void onPossiblePortal(class_1937 world, class_2338 pos, class_2424 shape);
	}
	
	@FunctionalInterface
	public interface Block_Right_Click {
		 boolean onBlockRightClick(class_1937 world, class_1657 player, class_1268 hand, class_2338 pos, class_3965 hitVec);
	}
}
