package com.natamus.collective_fabric.functions;

import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3738;
import net.minecraft.server.MinecraftServer;

public class TaskFunctions {
	public static void enqueueImmediateTask(class_1937 world, Runnable task, boolean allowClient) {
		if (world.field_9236 && allowClient) {
			task.run();
		}
		else {
			enqueueTask(world, task, 0);
		}
	}

	public static void enqueueTask(class_1937 world, Runnable task, int delay) {
    	if (!(world instanceof class_3218)) {
    		return;
    	}

    	MinecraftServer server = ((class_3218)world).method_8503();
    	server.method_20493(new class_3738(server.method_3780() + delay, task));
	}
}
