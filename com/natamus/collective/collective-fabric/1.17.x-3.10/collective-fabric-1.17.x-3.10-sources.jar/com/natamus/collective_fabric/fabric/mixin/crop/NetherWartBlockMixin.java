package com.natamus.collective_fabric.fabric.mixin.crop;

import java.util.Random;
import net.minecraft.class_2338;
import net.minecraft.class_2421;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveCropEvents;

@Mixin(value = class_2421.class, priority = 1001)
public class NetherWartBlockMixin {
	@Inject(method = "randomTick", at = @At(value = "INVOKE_ASSIGN", target = "Ljava/util/Random;nextInt(I)I"), cancellable = true)
	public void NetherWartBlock_randomTick(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, Random random, CallbackInfo ci) {
		if (!CollectiveCropEvents.PRE_CROP_GROW.invoker().onPreCropGrow(serverLevel, blockPos, blockState)) {
			ci.cancel();
		}
	}
}
