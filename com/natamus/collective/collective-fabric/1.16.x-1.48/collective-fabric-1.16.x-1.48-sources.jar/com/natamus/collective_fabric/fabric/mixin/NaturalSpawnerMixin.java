package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveSpawnEvents;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_1948;
import net.minecraft.class_2338;
import net.minecraft.class_2791;
import net.minecraft.class_3218;
import net.minecraft.class_3730;

@Mixin(class_1948.class)
public class NaturalSpawnerMixin {
	@ModifyVariable(method = "spawnCategoryForPosition", at = @At(value= "INVOKE_ASSIGN", target = "Lnet/minecraft/world/level/NaturalSpawner;getMobForSpawn(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/EntityType;)Lnet/minecraft/world/entity/Mob;", ordinal = 0))
	private static class_1308 NaturalSpawner_spawnCategoryForPosition(class_1308 mob, class_1311 mobCategory, class_3218 serverLevel, class_2791 chunkAccess, class_2338 blockPos, class_1948.class_5261 spawnPredicate, class_1948.class_5259 afterSpawnCallback) {
		if (mob != null) {
			mob.method_5814(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260());
		}
		
		if (!CollectiveSpawnEvents.MOB_CHECK_SPAWN.invoker().onMobCheckSpawn(mob, serverLevel, blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260(), null, class_3730.field_16459)) {
			mob = null;
		}
		
		return mob;
	}
	
/*	@ModifyVariable(method = "Lnet/minecraft/world/level/NaturalSpawner;spawnMobsForChunkGeneration(Lnet/minecraft/world/level/ServerLevelAccessor;Lnet/minecraft/world/level/biome/Biome;IILjava/util/Random;)V", at = @At(value= "INVOKE_ASSIGN", target = "Lnet/minecraft/world/entity/Entity;moveTo(DDDFF)V", ordinal = 0))
	private static Entity NaturalSpawner_spawnMobsForChunkGeneration(Entity entity2, ServerLevelAccessor serverLevelAccessor, Biome biome, int i, int j, Random random) {
		if (entity2 instanceof Mob == false) {
			return entity2;
		}
		
		Mob mob = (Mob)entity2;
		Vec3 vec = mob.position();
		if (!CollectiveSpawnEvents.MOB_CHECK_SPAWN.invoker().onMobCheckSpawn(mob, (ServerLevel)WorldFunctions.getWorldIfInstanceOfAndNotRemote(serverLevelAccessor), vec.x, vec.y, vec.z, null, MobSpawnType.CHUNK_GENERATION)) {
			return null;
		}
		
		return entity2;
	}*/
}
