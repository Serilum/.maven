package com.natamus.collective_fabric.config;

import com.natamus.collective_fabric.util.Reference;
import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.ConfigData;
import me.shedaniel.autoconfig.annotation.Config;
import me.shedaniel.autoconfig.serializer.JanksonConfigSerializer;
import me.shedaniel.cloth.clothconfig.shadowed.blue.endless.jankson.Comment;

@Config(name = Reference.MOD_ID)
public class CollectiveConfigHandler implements ConfigData {
    public static class General {
        public static CollectiveConfigHandler config;
        public static void initConfig() {
            config = AutoConfig.register(CollectiveConfigHandler.class, JanksonConfigSerializer::new).getConfig();
        }
    }

    @Comment("When enabled, transfer the held items and armour from replaced entities by any of the Entity Spawn mods which depend on Collective.")
    public boolean transferItemsBetweenReplacedEntities = true;

    @Comment("The amount of times Collective loops through possible mob drops to get them all procedurally. Drops are only generated when a dependent mod uses them. Lowering this can increase world load time but decrease accuracy.")
    public int loopsAmountUsedToGetAllEntityDrops = 100;

    @Comment("The delay of the is-there-a-block-around-check around entities in ms. Used in mods which depends on a specific blockstate in the world. Increasing this number can increase TPS if needed.")
    public int findABlockcheckAroundEntitiesDelayMs = 30000;

    @Comment("Please check out https://stopmodreposts.org/ for more information on why this feature exists.")
    public boolean enableAntiRepostingCheck = true;

    @Comment("Enables pets for Patrons. Will be added in a future release.")
    public boolean enablePatronPets = true;
}