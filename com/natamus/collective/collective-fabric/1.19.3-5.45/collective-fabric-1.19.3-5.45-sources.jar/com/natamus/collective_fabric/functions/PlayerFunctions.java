package com.natamus.collective_fabric.functions;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.natamus.collective_fabric.util.Reference;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_174;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2522;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class PlayerFunctions {
	public static boolean respawnPlayer(class_1937 world, class_1657 player) {
		if (!(player instanceof class_3222)) {
			return false;
		}
		
		MinecraftServer server = world.method_8503();
		class_3222 serverplayer = (class_3222)player;
		
		if (serverplayer.field_13989) {
			serverplayer.field_13989 = false;
			serverplayer = server.method_3760().method_14556(serverplayer, true);
			class_174.field_1183.method_8794(serverplayer, class_1937.field_25181, class_1937.field_25179);
		}
		else if (serverplayer.method_6032() <= 0.0F) {
			server.method_3760().method_14556(serverplayer, false);
		}
		
		return true;
	}
	
	public static class_1657 matchPlayer(class_1657 player, String other) {
		return matchPlayer(player.method_5770(), other);
	}
	public static class_1657 matchPlayer(class_1937 world, String other) {
		List<? extends class_1657> players = world.method_18456();

		for (class_1657 onlineplayer : players) {
			if (onlineplayer.method_5477().getString().toLowerCase().equals(other)) {
				return onlineplayer;
			}
		}
		return null;
	}
	
	public static boolean isHoldingWater(class_1657 player) {
		return player.method_5998(class_1268.field_5810).method_7909().equals(class_1802.field_8705) || player.method_5998(class_1268.field_5808).method_7909().equals(class_1802.field_8705);
	}
	
	public static boolean isJoiningWorldForTheFirstTime(class_1657 player, String modid) {
		return isJoiningWorldForTheFirstTime(player, modid, true);
	}
	public static boolean isJoiningWorldForTheFirstTime(class_1657 player, String modid, boolean mustHaveEmptyInventory) {
		String firstjointag = Reference.MOD_ID + ".firstJoin." + modid;
		
		Set<String> tags = player.method_5752();
		if (tags.contains(firstjointag)) {
			return false;
		}
		
		player.method_5780(firstjointag);

		if (mustHaveEmptyInventory) {
			class_1661 inv = player.method_31548();
			boolean isempty = true;
			for (int i = 0; i < 36; i++) {
				if (!inv.method_5438(i).method_7960()) {
					isempty = false;
					break;
				}
			}

			if (!isempty) {
				return false;
			}
		}
		
		class_1937 world = player.method_5770();
		class_3218 ServerLevel = (class_3218)world;
		class_2338 wspos = ServerLevel.method_43126();
		class_2338 ppos = player.method_24515();
		class_2338 cpos = new class_2338(ppos.method_10263(), wspos.method_10264(), ppos.method_10260());

		return cpos.method_19771(wspos, 50);
	}
	
	public static class_2338 getSpawnPoint(class_1937 world, class_1657 player) {
		class_243 spawnvec = getSpawnVec(world, player);
		return new class_2338(spawnvec.field_1352, spawnvec.field_1351, spawnvec.field_1350);
	}
	public static class_243 getSpawnVec(class_1937 world, class_1657 player) {
		class_3222 serverplayer = (class_3222)player;
		class_3218 ServerLevel = (class_3218)world;
		
		class_2338 respawnlocation = ServerLevel.method_43126(); // get spawn point
		class_243 respawnvec = new class_243(respawnlocation.method_10263(), respawnlocation.method_10264(), respawnlocation.method_10260());
		
		class_2338 bedpos = serverplayer.method_26280();
		if (bedpos != null) {
			Optional<class_243> optionalbed = class_1657.method_26091(ServerLevel, bedpos, 1.0f, false, false);
			if (optionalbed.isPresent()) {
				class_243 bedvec = optionalbed.get();
				class_2338 bp = new class_2338(bedvec);
				Iterator<class_2338> it = class_2338.method_17962(bp.method_10263()-1, bp.method_10264()-1, bp.method_10260()-1, bp.method_10263()+1, bp.method_10264()+1, bp.method_10260()+1).iterator();
				while (it.hasNext()) {
					class_2338 np = it.next();
					class_2680 state = world.method_8320(np);
					class_2248 block = state.method_26204();
					if (block instanceof class_2244) { // Found bed
						respawnvec = bedvec;
						break;
					}
				}
			}
		}
		
		return respawnvec;
	}
	
	public static class_1268 getOtherHand(class_1268 hand) {
		if (hand.equals(class_1268.field_5808)) {
			return class_1268.field_5810;
		}
		return class_1268.field_5808;
	}
	
	// Player Gear Functions
	public static String getPlayerGearString(class_1657 player) {
		StringBuilder skconfig = new StringBuilder();
		
		class_1799 offhand = player.method_6118(class_1304.field_6171);
		if (!offhand.method_7960()) {
			String nbtstring = ItemFunctions.getNBTStringFromItemStack(offhand);
			skconfig.append("'offhand'" + " : " + "'").append(nbtstring).append("',");
		}
		else {
			skconfig.append("'offhand'" + " : " + "'',");
		}

		class_1799 head = player.method_6118(class_1304.field_6169);
		if (!head.method_7960()) {
			String nbtstring = ItemFunctions.getNBTStringFromItemStack(head);
			skconfig.append("\n" + "'head'" + " : " + "'").append(nbtstring).append("',");
		}
		else {
			skconfig.append("\n" + "'head'" + " : " + "'',");
		}

		class_1799 chest = player.method_6118(class_1304.field_6174);
		if (!chest.method_7960()) {
			String nbtstring = ItemFunctions.getNBTStringFromItemStack(chest);
			skconfig.append("\n" + "'chest'" + " : " + "'").append(nbtstring).append("',");
		}
		else {
			skconfig.append("\n" + "'chest'" + " : " + "'',");
		}

		class_1799 legs = player.method_6118(class_1304.field_6172);
		if (!legs.method_7960()) {
			String nbtstring = ItemFunctions.getNBTStringFromItemStack(legs);
			skconfig.append("\n" + "'legs'" + " : " + "'").append(nbtstring).append("',");
		}
		else {
			skconfig.append("\n" + "'legs'" + " : " + "'',");
		}

		class_1799 feet = player.method_6118(class_1304.field_6166);
		if (!feet.method_7960()) {
			String nbtstring = ItemFunctions.getNBTStringFromItemStack(feet);
			skconfig.append("\n" + "'feet'" + " : " + "'").append(nbtstring).append("',");
		}
		else {
			skconfig.append("\n" + "'feet'" + " : " + "'',");
		}

		class_1661 inv = player.method_31548();
		for (int i=0; i < 36; i++) {
			class_1799 slot = inv.method_5438(i);
			if (!slot.method_7960()) {
				String nbtstring = ItemFunctions.getNBTStringFromItemStack(slot);
				skconfig.append("\n").append(i).append(" : ").append("'").append(nbtstring).append("',");
			}
			else {
				skconfig.append("\n").append(i).append(" : '',");
			}
		}

		return skconfig.toString();
	}

	public static String getPlayerGearStringFromHashMap(HashMap<String, class_1799> gear) {
		StringBuilder gearstring = new StringBuilder();

		List<String> specialslots = new ArrayList<String>(Arrays.asList("offhand", "head", "chest", "legs", "feet"));
		for (String specialslot : specialslots) {
			String specialslotstring = "";
			if (gear.containsKey(specialslot)) {
				specialslotstring = ItemFunctions.getNBTStringFromItemStack(gear.get(specialslot));
			}
			if (!gearstring.toString().equals("")) {
				gearstring.append("\n");
			}
			gearstring.append("'").append(specialslot).append("'").append(" : ").append("'").append(specialslotstring).append("',");
		}

		List<class_1799> emptyinventory = class_2371.method_10213(36, class_1799.field_8037);
		for (int i = 0; i < emptyinventory.size(); i++) {
			String itemstring = "";
			if (gear.containsKey("" + i)) {
				itemstring = ItemFunctions.getNBTStringFromItemStack(gear.get("" + i));
			}
			gearstring.append("\n").append(i).append(" : '").append(itemstring).append("',");
		}
		
		return gearstring.toString();
	}
	
	public static void setPlayerGearFromString(class_1657 player, String gearconfig) {
		String[] gearspl = gearconfig.split("',[\\r\\n]+");
		int newlinecount = gearspl.length;
		
		if (newlinecount < 40) {
			System.out.println("[Error] (Collective) setPlayerGearFromString: The gear config does not contain 40 lines and is invalid.");
			return;
		}
		
		boolean cleared = false;
		for (String line : gearspl) {
			line = line.trim();
			if (line.endsWith(",")) {
				line = line.substring(0, line.length() - 1);
			}
			if (!line.endsWith("'")) {
				line = line + "'";
			}
			
			String[] lspl = line.split(" : ");
			if (lspl.length != 2) {
				System.out.println("[Error] (Collective) setPlayerGearFromString: The line " + line + " is invalid.");
				return;
			}
			
			String slotstring = lspl[0].replace("'", "");
			String data = lspl[1];
			if (data.startsWith("'")) {
				data = data.substring(1);
			}
			if (data.endsWith("'")) {
				data = data.substring(0, data.length() - 1);
			}
			
			if (data.length() < 2) {
				continue;
			}
			
			data = data.replaceAll("\r", "");
			
			class_1799 itemstack = null;
			try {
				class_2487 newnbt = class_2522.method_10718(data);
				itemstack = class_1799.method_7915(newnbt);
			} catch (CommandSyntaxException e0) {
				try {
					data = data.replace("\",\"", "|||,|||").replace(" \"", " '").replace("\" ", "' ").replace("|||,|||", "\",\"");
					class_2487 newnbt = class_2522.method_10718(data);
					itemstack = class_1799.method_7915(newnbt);
				} catch (CommandSyntaxException e1) {
					e1.printStackTrace();
				}
			}
			
			if (itemstack == null) {
				System.out.println("[Error] (Collective) setPlayerGearFromString: Unable to get the correct itemstack data from data " + data);
				return;				
			}
			
			if (!cleared) {
				cleared = true;
				player.method_31548().method_5448();
			}
			
			if (NumberFunctions.isNumeric(slotstring)) {
				int slot = Integer.parseInt(slotstring);
				player.method_31548().method_5447(slot, itemstack);
				continue;
			}
			
			class_1304 type;
			switch (slotstring) {
				case "offhand" -> type = class_1304.field_6171;
				case "head" -> type = class_1304.field_6169;
				case "chest" -> type = class_1304.field_6174;
				case "legs" -> type = class_1304.field_6172;
				case "feet" -> type = class_1304.field_6166;
				default -> {
					continue;
				}
			}

			player.method_5673(type, itemstack);
		}
	}
}
