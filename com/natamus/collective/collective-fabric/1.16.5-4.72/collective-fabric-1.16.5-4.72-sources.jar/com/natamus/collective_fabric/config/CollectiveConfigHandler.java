package com.natamus.collective_fabric.config;

public class CollectiveConfigHandler extends MidnightConfig {
    @Comment public static Comment DESC_transferItemsBetweenReplacedEntities;
    @Entry public static boolean transferItemsBetweenReplacedEntities = true;

    @Comment public static Comment DESC_loopsAmountUsedToGetAllEntityDrops;
    @Entry public static int loopsAmountUsedToGetAllEntityDrops = 100;

    @Comment public static Comment DESC_findABlockcheckAroundEntitiesDelayMs;
    @Entry public static int findABlockcheckAroundEntitiesDelayMs = 30000;

    @Comment public static Comment DESC_enableAntiRepostingCheck;
    @Entry public static boolean enableAntiRepostingCheck = true;

    @Comment public static Comment DESC_enablePatronPets;
    @Entry public static boolean enablePatronPets = true;
}