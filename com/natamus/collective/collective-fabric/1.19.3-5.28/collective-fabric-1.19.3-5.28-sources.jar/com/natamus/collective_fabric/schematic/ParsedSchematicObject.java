package com.natamus.collective_fabric.schematic;

import com.mojang.datafixers.util.Pair;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class ParsedSchematicObject {
    public List<Pair<class_2338, class_2680>> blocks;
    public List<class_2338> blockEntityPositions;
    public String parseMessageString;
    public boolean parsedCorrectly;

    public int offsetX;
    public int offsetY;
    public int offsetZ;

    public ParsedSchematicObject(Schematic schematic, List<Pair<class_2338, class_2680>> b, List<class_2338> bEP, String pMS, boolean pC) {
        blocks = b;
        blockEntityPositions = bEP;
        parseMessageString = pMS;
        parsedCorrectly = pC;

        offsetX = schematic.getOffsetX();
        offsetY = schematic.getOffsetY();
        offsetZ = schematic.getOffsetZ();
    }

    public List<Pair<class_2338, class_2586>> getBlockEntities(class_1937 level) {
        List<Pair<class_2338, class_2586>> blockEntities = new ArrayList<Pair<class_2338, class_2586>>();
        for (class_2338 pos : blockEntityPositions) {
            blockEntities.add(new Pair<class_2338, class_2586>(pos, level.method_8321(pos)));
        }
        return blockEntities;
    }
}