package com.natamus.collective_fabric.data;

import net.fabricmc.loader.api.FabricLoader;

public class GlobalObjects {
    public static final FabricLoader fabricLoader = FabricLoader.getInstance();
}
