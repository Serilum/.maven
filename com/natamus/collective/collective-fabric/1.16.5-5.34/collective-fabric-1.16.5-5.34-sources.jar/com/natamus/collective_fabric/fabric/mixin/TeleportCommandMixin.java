package com.natamus.collective_fabric.fabric.mixin;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveEntityEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2708;
import net.minecraft.class_3143;
import net.minecraft.class_3218;

@Mixin(value = class_3143.class, priority = 1001)
public abstract class TeleportCommandMixin {
	@Inject(method = "performTeleport(Lnet/minecraft/commands/CommandSourceStack;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/server/level/ServerLevel;DDDLjava/util/Set;FFLnet/minecraft/server/commands/TeleportCommand$LookAt;)V", at = @At(value = "HEAD"), cancellable = true)
	private static void performTeleport(class_2168 commandSourceStack, class_1297 entity, class_3218 serverLevel, double d, double e, double f, Set<class_2708.class_2709> set, float g, float h, class_3143.class_3144 lookAt, CallbackInfo ci) {
		if (!CollectiveEntityEvents.ON_ENTITY_TELEPORT_COMMAND.invoker().onTeleportCommand(serverLevel, entity, d, e, f)) {
			ci.cancel();
		}
	}
}
