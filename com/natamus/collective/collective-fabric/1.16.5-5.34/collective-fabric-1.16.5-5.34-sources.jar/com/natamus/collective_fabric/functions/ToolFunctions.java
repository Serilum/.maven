package com.natamus.collective_fabric.functions;

import net.fabricmc.fabric.api.tool.attribute.v1.FabricToolTags;
import net.minecraft.class_1743;
import net.minecraft.class_1753;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1820;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.world.item.*;

public class ToolFunctions {
	public static Boolean isTool(class_1799 itemStack) {
		if (itemStack == null) {
			return false;
		}
		
		class_1792 item = itemStack.method_7909();
		if (item instanceof class_1821 || item instanceof class_1743 || item instanceof class_1810 || item instanceof class_1829 || item instanceof class_1794) {
			return true;
		}
		
		String itemname = item.toString().toLowerCase();
        return itemname.contains("_sword") || itemname.contains("_pickaxe") || itemname.contains("_axe") || itemname.contains("_shovel") || itemname.contains("_hoe");
    }
	
	public static Boolean isSword(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1829;
    }

	public static Boolean isBow(class_1799 itemStack) {
		return itemStack.method_7909() instanceof class_1753;
	}

	public static Boolean isPickaxe(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1810 || FabricToolTags.PICKAXES.method_15141(itemStack.method_7909());
    }

	public static Boolean isAxe(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1743 || FabricToolTags.AXES.method_15141(itemStack.method_7909());
    }

	public static Boolean isShovel(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1821 || FabricToolTags.SHOVELS.method_15141(itemStack.method_7909());
    }

	public static Boolean isHoe(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1794 || FabricToolTags.HOES.method_15141(itemStack.method_7909());
    }

	public static Boolean isShears(class_1799 itemStack) {
		return itemStack.method_7909() instanceof class_1820 || FabricToolTags.SHEARS.method_15141(itemStack.method_7909());
	}
}
