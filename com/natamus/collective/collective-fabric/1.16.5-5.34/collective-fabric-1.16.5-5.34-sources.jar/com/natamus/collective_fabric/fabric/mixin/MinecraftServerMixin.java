package com.natamus.collective_fabric.fabric.mixin;

import com.mojang.authlib.GameProfileRepository;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.datafixers.DataFixer;
import com.natamus.collective_fabric.fabric.callbacks.CollectiveLifecycleEvents;
import com.natamus.collective_fabric.fabric.callbacks.CollectiveMinecraftServerEvents;
import com.natamus.collective_fabric.fabric.callbacks.CollectiveWorldEvents;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_3283;
import net.minecraft.class_3312;
import net.minecraft.class_3950;
import net.minecraft.class_5219;
import net.minecraft.class_5268;
import net.minecraft.class_5350;
import net.minecraft.class_5455;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.net.Proxy;

@Mixin(value = MinecraftServer.class, priority = 1001)
public class MinecraftServerMixin {
	@Inject(method = "<init>(Ljava/lang/Thread;Lnet/minecraft/core/RegistryAccess$RegistryHolder;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/world/level/storage/WorldData;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/net/Proxy;Lcom/mojang/datafixers/DataFixer;Lnet/minecraft/server/ServerResources;Lcom/mojang/authlib/minecraft/MinecraftSessionService;Lcom/mojang/authlib/GameProfileRepository;Lnet/minecraft/server/players/GameProfileCache;Lnet/minecraft/server/level/progress/ChunkProgressListenerFactory;)V", at = @At(value = "TAIL"))
	public void MinecraftServer_init(Thread thread, class_5455.class_5457 registryHolder, class_32.class_5143 levelStorageAccess, class_5219 worldData, class_3283 packRepository, Proxy proxy, DataFixer dataFixer, class_5350 serverResources, MinecraftSessionService minecraftSessionService, GameProfileRepository gameProfileRepository, class_3312 gameProfileCache, class_3950 chunkProgressListenerFactory, CallbackInfo ci) {
		((MinecraftServer)(Object)this).execute(() -> {
			CollectiveLifecycleEvents.MINECRAFT_LOADED.invoker().onMinecraftLoad(false);
		});
	}

	@Inject(method = "setInitialSpawn", at = @At(value = "RETURN"))
	private static void MinecraftServer_setInitialSpawn(class_3218 serverLevel, class_5268 serverLevelData, boolean bl, boolean bl2, boolean bl3, CallbackInfo ci) {
		CollectiveMinecraftServerEvents.WORLD_SET_SPAWN.invoker().onSetSpawn(serverLevel, serverLevelData);
	}
	
	@ModifyVariable(method = "stopServer", at = @At(value= "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;close()V", ordinal = 0))
	public class_3218 MinecraftServer_stopServer(class_3218 serverlevel1) {
		CollectiveWorldEvents.WORLD_UNLOAD.invoker().onWorldUnload(serverlevel1);
		return serverlevel1;
	}
}
