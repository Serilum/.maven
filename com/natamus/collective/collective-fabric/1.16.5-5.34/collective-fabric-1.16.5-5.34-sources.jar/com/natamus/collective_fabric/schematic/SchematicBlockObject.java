package com.natamus.collective_fabric.schematic;

import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class SchematicBlockObject {

	private class_2338 position;
	private class_2680 state;
	
	public SchematicBlockObject(class_2338 position, class_2680 state) {
		this.position = position;
		this.state = state;
	}
	
	public class_2338 getPosition() {
		return position;
	}
	
	public class_2680 getState() {
		return state;
	}
	
	public class_2338 getPositionWithOfsset(int x, int y, int z) {
		return new class_2338(x + position.method_10263(), y + position.method_10264(), z + position.method_10260());
	}
}
