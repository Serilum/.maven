package com.natamus.collective_fabric.functions;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import com.natamus.collective_fabric.config.CollectiveConfigHandler;
import com.natamus.collective_fabric.data.GlobalVariables;
import com.natamus.collective_fabric.fabric.callbacks.CollectiveItemEvents;
import com.natamus.collective_fabric.fakeplayer.FakePlayer;
import com.natamus.collective_fabric.fakeplayer.FakePlayerFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_173;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_181;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3468;
import net.minecraft.class_47;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;

public class ItemFunctions {
	public static void generateEntityDropsFromLootTable(class_1937 world) {
		MinecraftServer server = world.method_8503();
		if (server == null) {
			return;
		}
		
		GlobalVariables.entitydrops = new HashMap<class_1299<?>, List<class_1792>>();
		
		FakePlayer fakeplayer = FakePlayerFactory.getMinecraft((class_3218)world);
		class_243 vec = new class_243(0, 0, 0);
		
		class_1799 lootingsword = new class_1799(class_1802.field_8802, 1);
		lootingsword.method_7978(class_1893.field_9110, 10);
		fakeplayer.method_5673(class_1304.field_6173, lootingsword);
		
		Collection<Entry<class_5321<class_1299<?>>, class_1299<?>>> entitytypes = class_2378.field_11145.method_29722();
		for (Entry<class_5321<class_1299<?>>, class_1299<?>> entry : entitytypes) {
			class_1299<?> type = entry.getValue();
			if (type == null) {
				continue;
			}
			class_1297 entity = type.method_5883(world);
			if (!(entity instanceof class_1309)) {
				continue;
			}
			
			class_1309 le = (class_1309)entity;
			class_2960 lootlocation = le.method_5864().method_16351();
			
			class_52 loottable = server.method_3857().method_367(lootlocation);
			class_47 context = new class_47.class_48((class_3218) world)
	                .method_311(world.method_8409())
	                .method_303(1000000F)
	                .method_312(class_181.field_1226, entity)
	                .method_312(class_181.field_24424, vec)
	                .method_312(class_181.field_1230, fakeplayer)
	                .method_312(class_181.field_1231, class_1282.method_5532(fakeplayer))
	                .method_309(class_173.field_1173);
			
			List<class_1792> alldrops = new ArrayList<class_1792>();
			for (int n = 0; n < CollectiveConfigHandler.loopsAmountUsedToGetAllEntityDrops.getValue(); n++) {
				List<class_1799> newdrops = loottable.method_319(context);
				for (class_1799 newdrop : newdrops) {
					class_1792 newitem = newdrop.method_7909();
					if (!alldrops.contains(newitem) && !newitem.equals(class_1802.field_8162)) {
						alldrops.add(newitem);
					}
				}
			}
			
			GlobalVariables.entitydrops.put(type, alldrops);
		}
	}
	
	public static Boolean isTool(class_1799 itemstack) {
		return ToolFunctions.isTool(itemstack);
	}
	
	public static void shrinkGiveOrDropItemStack(class_1657 player, class_1268 hand, class_1799 used, class_1799 give) {
		used.method_7934(1);
		
		if (used.method_7960()) {
			class_1792 giveitem = give.method_7909();
			int maxstacksize = give.method_7914();
			List<class_1799> inventory = player.field_7514.field_7547;
			
			boolean increased = false;
			for (class_1799 slot : inventory) {
				if (slot.method_7909().equals(giveitem)) {
					int slotcount = slot.method_7947();
					if (slotcount < maxstacksize) {
						slot.method_7939(slotcount + 1);
						increased = true;
						break;
					}
				}
			}
			
			if (!increased) {
				player.method_6122(hand, give);
			}
		}
		else if (!player.field_7514.method_7394(give)) {
			player.method_7328(give, false);
		}
	}
	
	public static void giveOrDropItemStack(class_1657 player, class_1799 give) {
		if (!player.field_7514.method_7394(give)) {
			player.method_7328(give, false);
		}
	}

	public void itemHurtBreakAndEvent(class_1799 itemStack, class_3222 player, class_1268 hand, int damage) {
		if (!(player.field_7503.field_7477)) {
			if (itemStack.method_7963()) {
				if (itemStack.method_7970(damage, player.method_6051(), player)) {
					CollectiveItemEvents.ON_ITEM_DESTROYED.invoker().onItemDestroyed(player, itemStack, hand);

					class_1792 item = itemStack.method_7909();
					itemStack.method_7934(1);
					itemStack.method_7974(0);

					player.method_7259(class_3468.field_15383.method_14956(item));
				}
			}
		}
	}
	
	public static boolean isStoneTypeItem(class_1792 item) {
		return GlobalVariables.stoneblockitems.contains(item);
	}
	
	public static String itemToReadableString(class_1792 item, int amount) {
		String itemstring;
		String translationkey = item.method_7876();
		if (translationkey.contains("block.")) {
			return BlockFunctions.blockToReadableString(class_2248.method_9503(item), amount);
		}
		
		String[] itemspl = translationkey.replace("item.", "").split("\\.");
		if (itemspl.length > 1) {
			itemstring = itemspl[1];
		}
		else {
			itemstring = itemspl[0];
		}
		
		itemstring = itemstring.replace("_", " ");
		if (amount > 1) {
			itemstring = itemstring + "s";
		}
		
		return itemstring;
	}
	public static String itemToReadableString(class_1792 item) {
		return itemToReadableString(item, 1);
	}
}