package com.natamus.collective_fabric.util;

public class Reference {
	public static final String MOD_ID = "collective-fabric";
	public static final String NAME = "Collective (Fabric)";
	public static final String VERSION = "5.49";
	public static final String ACCEPTED_VERSIONS = "[1.16.5]";
}
