package com.natamus.collective_fabric.functions;

import java.util.Base64;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2585;
import com.natamus.collective_fabric.data.GlobalVariables;

public class HeadFunctions {
	public static class_1799 getPlayerHead(String playername, Integer amount) {
		// Head Data
		String data1 = DataFunctions.readStringFromURL(GlobalVariables.playerdataurl + playername.toLowerCase());
		if (data1.equals("")) {
			return null;
		}

		String[] sdata1 = data1.split("\":\"");
		String pname = sdata1[1].split("\"")[0];
		String pid = sdata1[2].split("\"")[0];
		
		String data2 = DataFunctions.readStringFromURL(GlobalVariables.skindataurl + pid);
		if (data2.equals("")) {
			return null;
		}
		
		String[] sdata2 = data2.replaceAll(" ", "").split("value\":\"");
		
		String tvalue = sdata2[1].split("\"")[0];
		String d = new String(Base64.getDecoder().decode((tvalue.getBytes())));
		
		String texture = Base64.getEncoder().encodeToString((("{\"textures\"" + d.split("\"textures\"")[1]).getBytes()));
		String oldid = new UUID(texture.hashCode(), texture.hashCode()).toString();

		return getTexturedHead(pname + "'s Head", texture, oldid, 1);
	}
	
	public static class_1799 getTexturedHead(String headname, String texture, String oldid, Integer amount) {
		class_1799 texturedhead = new class_1799(class_1802.field_8575, amount);
		
		List<Integer> intarray = UUIDFunctions.oldIdToIntArray(oldid);
		
		class_2487 skullOwner = new class_2487();
		skullOwner.method_10572("Id", intarray);
		
		class_2487 properties = new class_2487();
		class_2499 textures = new class_2499();
		class_2487 tex = new class_2487();
		tex.method_10582("Value", texture);
		textures.add(tex);

		properties.method_10566("textures", textures);
		skullOwner.method_10566("Properties", properties);
		texturedhead.method_7959("SkullOwner", skullOwner);
		
		class_2585 tcname = new class_2585(headname);
		texturedhead.method_7977(tcname);		
		return texturedhead;
	}
	
	public static boolean hasStandardHead(String mobname) {
        return mobname.equals("creeper") || mobname.equals("zombie") || mobname.equals("skeleton");
    }
}
