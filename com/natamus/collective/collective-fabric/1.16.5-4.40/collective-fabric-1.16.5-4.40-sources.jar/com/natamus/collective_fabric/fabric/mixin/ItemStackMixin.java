package com.natamus.collective_fabric.fabric.mixin;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveItemEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_1799.class, priority = 999)
public abstract class ItemStackMixin {
	@Inject(method = "finishUsingItem(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack;", at = @At(value = "HEAD"), cancellable = true)
	public void finishUsingItem(class_1937 level, class_1309 livingEntity, CallbackInfoReturnable<class_1799> cir) {
		if (livingEntity instanceof class_1657) {
			class_1799 itemStack = (class_1799) (Object) this;
			class_1799 copyStack = itemStack.method_7972();
			class_1799 newStack = itemStack.method_7909().method_7861(itemStack, level, livingEntity);

			class_1268 hand = livingEntity.method_6058();
			CollectiveItemEvents.ON_ITEM_USE_FINISHED.invoker().onItemUsedFinished((class_1657) livingEntity, copyStack, newStack, hand);

			cir.setReturnValue(newStack);
		}
	}
}
