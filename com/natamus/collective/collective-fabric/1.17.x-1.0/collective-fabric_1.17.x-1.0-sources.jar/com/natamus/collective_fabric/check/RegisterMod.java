package com.natamus.collective_fabric.check;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import com.natamus.collective_fabric.config.ConfigHandler;
import com.natamus.collective_fabric.functions.DataFunctions;
import com.natamus.collective_fabric.functions.StringFunctions;
import com.natamus.collective_fabric.functions.WorldFunctions;

public class RegisterMod {
	private static CopyOnWriteArrayList<String> jarlist = new CopyOnWriteArrayList<String>();
	private static HashMap<String, String> jartoname = new HashMap<String, String>();
	public static boolean shouldDoCheck = true;
	
	public static void register(String modname, String modid, String modversion, String forgeversion) {
		String jarname = modid + "_" + forgeversion.replaceAll("\\[", "").replaceAll("\\]","") + "-" + modversion + ".jar";
		if (modid.equalsIgnoreCase("collective")) {
			jarname = jarname.replaceAll("_", "-");
		}
		
		jarlist.add(jarname);
		jartoname.put(jarname, modname);
	}
	
	public static void initialProcess() {
		if (!ConfigHandler.enableAntiRepostingCheck.getValue()) {
			shouldDoCheck = false;
		}
		else if (!checkAlternative()) {
			shouldDoCheck = false;
		}
	}
	
	public static void joinWorldProcess(class_1937 world, class_1657 player) {
		if (world instanceof class_3218 == false) {
			return;
		}
		
		List<String> wrongmodnames = checkIfAllJarsExist();
		if (wrongmodnames.size() > 0) {
			if (processPreJoinWorldCheck(world)) {
				String s = "";
				if (wrongmodnames.size() > 1) {
					s = "s";
				}
				
				String projecturl = "https://curseforge.com/members/serilum/projects";
				StringFunctions.sendMessage(player, "Mod" + s + " from incorrect sources:", class_124.field_1061, projecturl);
				for (String wrongmodname : wrongmodnames) {
					StringFunctions.sendMessage(player, " " + wrongmodname, class_124.field_1054, projecturl);
				}
				
				StringFunctions.sendMessage(player, "You are receiving this message because you are using some of Serilum's mods, but probably haven't downloaded them from the original source. Unofficial sources can contain malicious software, supply no income for developers and host outdated versions.", class_124.field_1061, projecturl);
				StringFunctions.sendMessage(player, "Serilum's mod downloads are only officially available at:", class_124.field_1077, projecturl);
				StringFunctions.sendMessage(player, " https://curseforge.com/members/serilum/projects (click)", class_124.field_1054, projecturl);
				StringFunctions.sendMessage(player, "You won't see this message again in this instance. Thank you for reading.", class_124.field_1077, projecturl);
				StringFunctions.sendMessage(player, "-Rick (Serilum)", class_124.field_1054, projecturl);
				
				processPostJoinWorldCheck(world);
			}
		}
		
		shouldDoCheck = false;
	}
	
	private static boolean processPreJoinWorldCheck(class_1937 world) {
		String checkfilepath = WorldFunctions.getWorldPath((class_3218)world) + File.separator + "data" + File.separator + "collective" + File.separator + "checked.txt";
		File checkfile = new File(checkfilepath);
		if (checkfile.exists()) {
			shouldDoCheck = false;
		}
		else if (!checkAlternative()) {
			shouldDoCheck = false;
		}
		
		return shouldDoCheck;
	}
	
	private static void processPostJoinWorldCheck(class_1937 world) {
		shouldDoCheck = false;

		String worlddatapath = WorldFunctions.getWorldPath((class_3218)world) + File.separator + "data" + File.separator + "collective";
		File dir = new File(worlddatapath);
		dir.mkdirs();
		
		try {
			PrintWriter writer = new PrintWriter(worlddatapath + File.separator + "checked.txt", "UTF-8");
			writer.println("# Please check out https://stopmodreposts.org/ for more information on why this feature exists.");
			writer.println("checked=true");
			writer.close();
		} catch (Exception e) { }
		
		String alternativecheckpath = System.getProperty("user.dir") + File.separator + "data" + File.separator + "collective";
		File alternativedir = new File(alternativecheckpath);
		alternativedir.mkdirs();
		
		try {
			PrintWriter writer = new PrintWriter(alternativecheckpath + File.separator + "checked.txt", "UTF-8");
			writer.println("# Please check out https://stopmodreposts.org/ for more information on why this feature exists.");
			writer.println("checked=true");
			writer.close();
		} catch (Exception e) { }
	}
	
	private static List<String> checkIfAllJarsExist() {
		List<String> installedmods = DataFunctions.getInstalledModJars();
		
		List<String> wrongmodnames = new ArrayList<String>();
		for (String jarname : jarlist) {
			if (!installedmods.contains(jarname) && jartoname.containsKey(jarname)) {
				wrongmodnames.add(jartoname.get(jarname));
			}
		}
		
		if (wrongmodnames.size() > 0) {
			Collections.sort(wrongmodnames);
		}
		return wrongmodnames;
	}
	
	private static boolean checkAlternative() {
		String alternativecheckfilepath = System.getProperty("user.dir") + File.separator + "data" + File.separator + "collective" + File.separator + "checked.txt";
		File alternativecheckfile = new File(alternativecheckfilepath);
		if (alternativecheckfile.exists()) {
			return false;
		}
		return true;
	}
}
