package com.natamus.collective_fabric.fabric.callbacks;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2424;

public class CollectiveBlockEvents {
	private CollectiveBlockEvents() { }
	 
    public static final Event<CollectiveBlockEvents.Possible_Portal_Spawn> ON_NETHER_PORTAL_SPAWN = EventFactory.createArrayBacked(CollectiveBlockEvents.Possible_Portal_Spawn.class, callbacks -> (world, pos, shape) -> {
        for (CollectiveBlockEvents.Possible_Portal_Spawn callback : callbacks) {
        	callback.onPossiblePortal(world, pos, shape); 
        }
    });
    
	@FunctionalInterface
	public interface Possible_Portal_Spawn {
		 void onPossiblePortal(class_1937 world, class_2338 pos, class_2424 shape);
	}
}
