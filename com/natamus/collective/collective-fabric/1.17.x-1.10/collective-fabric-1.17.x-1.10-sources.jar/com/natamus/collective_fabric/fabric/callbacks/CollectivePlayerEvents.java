package com.natamus.collective_fabric.fabric.callbacks;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class CollectivePlayerEvents {
	private CollectivePlayerEvents() { }
		 
    public static final Event<CollectivePlayerEvents.Death> PLAYER_DEATH = EventFactory.createArrayBacked(CollectivePlayerEvents.Death.class, callbacks -> (world, player) -> {
        for (CollectivePlayerEvents.Death callback : callbacks) {
        	callback.onDeath(world, player);
        }
    });
    
	@FunctionalInterface
	public interface Death {
		 void onDeath(class_3218 world, class_3222 player);
	}
}
