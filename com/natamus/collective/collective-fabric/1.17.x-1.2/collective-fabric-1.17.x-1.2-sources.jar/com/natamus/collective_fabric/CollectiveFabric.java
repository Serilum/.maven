package com.natamus.collective_fabric;

import java.util.ArrayList;
import java.util.HashMap;

import com.natamus.collective_fabric.config.CollectiveConfigHandler;
import com.natamus.collective_fabric.events.CollectiveEvents;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_3218;

public class CollectiveFabric implements ModInitializer {
	@Override
	public void onInitialize() {
		System.out.println("Loading Collective Fabric.");
		
		CollectiveConfigHandler.setup();
		
		ServerTickEvents.START_WORLD_TICK.register((class_3218 world) -> {
			CollectiveEvents.entitiesToSpawn.put(world, new ArrayList<class_1297>());
			CollectiveEvents.entitiesToRide.put(world, new HashMap<class_1297, class_1297>());
			
			CollectiveEvents.onWorldTick(world);
		});
		
		ServerEntityWorldChangeEvents.AFTER_ENTITY_CHANGE_WORLD.register((class_1297 originalEntity, class_1297 newEntity, class_3218 origin, class_3218 destination) -> {
			CollectiveEvents.onEntityJoinLevel(originalEntity, newEntity, origin, destination);
		});
	}
}
