package com.natamus.collective_fabric.fabric.callbacks;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1937;

public final class CollectiveEntityEvents {
	private CollectiveEntityEvents() { }

    public static final Event<CollectiveEntityEvents.Living_Tick> LIVING_TICK = EventFactory.createArrayBacked(CollectiveEntityEvents.Living_Tick.class, callbacks -> (world, entity) -> {
        for (CollectiveEntityEvents.Living_Tick callback : callbacks) {
        	callback.onTick(world, entity);
        }
    }); 
	
    public static final Event<CollectiveEntityEvents.Living_Entity_Death> LIVING_ENTITY_DEATH = EventFactory.createArrayBacked(CollectiveEntityEvents.Living_Entity_Death.class, callbacks -> (world, entity, source) -> {
        for (CollectiveEntityEvents.Living_Entity_Death callback : callbacks) {
        	callback.onDeath(world, entity, source);
        }
    });
    
    public static final Event<CollectiveEntityEvents.Pre_Entity_Join_World> PRE_ENTITY_JOIN_WORLD = EventFactory.createArrayBacked(CollectiveEntityEvents.Pre_Entity_Join_World.class, callbacks -> (world, entity) -> {
        for (CollectiveEntityEvents.Pre_Entity_Join_World callback : callbacks) {
        	if (!callback.onPreSpawn(world, entity)) {
        		return false;
        	}
        }
		return true;
    });
    
    public static final Event<CollectiveEntityEvents.Entity_Fall_Damage_Calc> ON_FALL_DAMAGE_CALC = EventFactory.createArrayBacked(CollectiveEntityEvents.Entity_Fall_Damage_Calc.class, callbacks -> (world, entity, f, g) -> {
        for (CollectiveEntityEvents.Entity_Fall_Damage_Calc callback : callbacks) {
        	if (callback.onFallDamageCalc(world, entity, f, g) == 0) {
        		return 0;
        	}
        }
		return 1;
    });
    
    public static final Event<CollectiveEntityEvents.Entity_Living_Damage> ON_LIVING_DAMAGE_CALC = EventFactory.createArrayBacked(CollectiveEntityEvents.Entity_Living_Damage.class, callbacks -> (world, entity, damageSource, damageAmount) -> {
        for (CollectiveEntityEvents.Entity_Living_Damage callback : callbacks) {
        	float newDamage = callback.onLivingDamageCalc(world, entity, damageSource, damageAmount);
        	if (newDamage != damageAmount) {
        		return newDamage;
        	}
        }
        
		return -1;
    });
    
    public static final Event<CollectiveEntityEvents.Entity_Living_Attack> ON_LIVING_ATTACK = EventFactory.createArrayBacked(CollectiveEntityEvents.Entity_Living_Attack.class, callbacks -> (world, entity, damageSource, damageAmount) -> {
        for (CollectiveEntityEvents.Entity_Living_Attack callback : callbacks) {
        	if (!callback.onLivingAttack(world, entity, damageSource, damageAmount)) {
        		return false;
        	}
        }
        
		return true;
    });
    
	@FunctionalInterface
	public interface Living_Tick {
		 void onTick(class_1937 world, class_1297 entity);
	}
    
	@FunctionalInterface
	public interface Living_Entity_Death {
		 void onDeath(class_1937 world, class_1297 entity, class_1282 source);
	}
	
	@FunctionalInterface
	public interface Pre_Entity_Join_World {
		 boolean onPreSpawn(class_1937 world, class_1297 entity);
	}
	
	@FunctionalInterface
	public interface Entity_Fall_Damage_Calc {
		 int onFallDamageCalc(class_1937 world, class_1297 entity, float f, float g);
	}
	
	@FunctionalInterface
	public interface Entity_Living_Damage {
		 float onLivingDamageCalc(class_1937 world, class_1297 entity, class_1282 damageSource, float damageAmount);
	}
	
	@FunctionalInterface
	public interface Entity_Living_Attack {
		 boolean onLivingAttack(class_1937 world, class_1297 entity, class_1282 damageSource, float damageAmount);
	}
}
