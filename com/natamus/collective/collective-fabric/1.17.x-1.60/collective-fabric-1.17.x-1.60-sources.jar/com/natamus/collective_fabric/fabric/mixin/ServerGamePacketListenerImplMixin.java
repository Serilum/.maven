package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveChatEvents;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_5513;

@Mixin(value = class_3244.class, priority = 1001)
public class ServerGamePacketListenerImplMixin {
	@ModifyVariable(method = "handleChat(Lnet/minecraft/server/network/TextFilter$FilteredText;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/MinecraftServer;getPlayerList()Lnet/minecraft/server/players/PlayerList;", ordinal = 0), ordinal = 0)
	public class_2561 ServerGamePacketListenerImpl_handleChat(class_2561 component2, class_5513.class_5837 filteredText) {
		class_3244 listener = (class_3244)(Object)this;
		class_3222 serverPlayer = listener.field_14140;
		
		class_2561 newMessage = CollectiveChatEvents.SERVER_CHAT_RECEIVED.invoker().onServerChat(serverPlayer, component2, serverPlayer.method_5667());
		if (component2 != newMessage) {
			component2 = newMessage;
		}
		
		return component2;
	}
}
