package com.natamus.collective_fabric.fabric.mixin;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective_fabric.fabric.callbacks.CollectiveChatEvents;
import com.natamus.collective_fabric.functions.MessageFunctions;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_5250;
import net.minecraft.class_5837;
import net.minecraft.class_7471;
import net.minecraft.class_7649;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.CompletableFuture;

@Mixin(value = class_3244.class, priority = 1001, remap = false)
public abstract class ServerGamePacketListenerImplMixin {
	@Shadow private @Final MinecraftServer server;
	@Shadow public class_3222 player;
	@Shadow private int chatSpamTickCount;
	@Shadow public void disconnect(class_2561 component) { }

    @Inject(method = "method_45064(Ljava/util/concurrent/CompletableFuture;Ljava/util/concurrent/CompletableFuture;Ljava/lang/Void;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/chat/PlayerChatMessage;filter(Lnet/minecraft/network/chat/FilterMask;)Lnet/minecraft/network/chat/PlayerChatMessage;"), cancellable = true)
    public void handleChat(CompletableFuture completableFuture, CompletableFuture completableFuture2, Void void_, CallbackInfo ci) {
        class_7649 filterMask = ((class_5837)completableFuture.join()).comp_978();
        class_7471 playerChatMessage = ((class_7471)completableFuture2.join()).method_45097(filterMask);
        class_2561 message = class_2561.method_43470("<" + this.player.method_5477().getString() + "> " + playerChatMessage.method_44125().getString());

        Pair<Boolean, class_2561> pair = CollectiveChatEvents.SERVER_CHAT_RECEIVED.invoker().onServerChat(this.player, message, player.method_5667());
        if (pair != null) {
            class_2561 newMessage = pair.getSecond();

            MessageFunctions.broadcastMessage(this.player.method_5770(), (class_5250) newMessage);

            this.chatSpamTickCount += 20;
            if (this.chatSpamTickCount > 200 && !this.server.method_3760().method_14569(this.player.method_7334())) {
                this.disconnect(class_2561.method_43471("disconnect.spam"));
            }
            ci.cancel();
        }
    }
}
