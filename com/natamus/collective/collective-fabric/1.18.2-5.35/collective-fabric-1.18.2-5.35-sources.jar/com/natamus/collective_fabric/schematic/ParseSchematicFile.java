package com.natamus.collective_fabric.schematic;

import com.mojang.datafixers.util.Pair;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;

public class ParseSchematicFile {
    public static ParsedSchematicObject getParsedSchematicObject(InputStream schematicInputStream, class_1937 level, class_2338 centerPos, int extraYOffset, boolean skipAir) {
        return getParsedSchematicObject(schematicInputStream, level, centerPos, extraYOffset, skipAir, true);
    }
    public static ParsedSchematicObject getParsedSchematicObject(InputStream schematicInputStream, class_1937 level, class_2338 centerPos, int extraYOffset, boolean skipAir, boolean automaticCenter) {
        Schematic schematic = new Schematic(schematicInputStream);

        int maxBuildHeight = level.method_31600();
        int length = schematic.getLength();
        int width = schematic.getWidth();
        int height = schematic.getHeight();

        int xoffset = schematic.getOffsetX();
        int yoffset = centerPos.method_10264() + extraYOffset;
        int zoffset = schematic.getOffsetZ();
        if (automaticCenter) {
            xoffset = -(width/2);

            if (yoffset + height > maxBuildHeight) {
                yoffset = maxBuildHeight - height;
            }

            zoffset = -(length/2);
        }
        else {
            yoffset += schematic.getOffsetY();
        }

        List<Pair<class_2338, class_2680>> blocks = new ArrayList<Pair<class_2338, class_2680>>();
        for (SchematicBlockObject blockObject : schematic.getBlocks()) {
            class_2680 blockState = blockObject.getState();
            if (skipAir && blockState.method_26204().equals(class_2246.field_10124)) {
                continue;
            }

            blocks.add(new Pair<class_2338, class_2680>(blockObject.getPosition().method_10069(centerPos.method_10263() + xoffset, yoffset, centerPos.method_10260() + zoffset).method_10062(), blockState));
        }

        List<class_2338> blockEntityPositions = new ArrayList<class_2338>();
        for (class_2487 blockEntityCompoundTag : schematic.getBlockEntities()) {
            blockEntityPositions.add(schematic.getBlockPosFromCompoundTag(blockEntityCompoundTag).method_10069(centerPos.method_10263() + xoffset, yoffset, centerPos.method_10260() + zoffset));
        }

        return new ParsedSchematicObject(schematic, blocks, blockEntityPositions, "Parsed successfully.", true);
    }
}
