package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveBlockEvents;
import com.natamus.collective_fabric.functions.WorldFunctions;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2424;

@Mixin(class_2424.class)
public class PortalShapeMixin {
	@Shadow private class_1936 level;
	@Shadow private class_2338 bottomLeft;
	
	@Inject(method = "createPortalBlocks()V", at = @At(value= "HEAD"))
	public void createPortalBlocks(CallbackInfo ci) {
		class_2424 portalshape = (class_2424)(Object)this;
		CollectiveBlockEvents.ON_NETHER_PORTAL_SPAWN.invoker().onPossiblePortal(WorldFunctions.getWorldIfInstanceOfAndNotRemote(level), bottomLeft, portalshape);
	}
}
