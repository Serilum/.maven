package com.natamus.collective_fabric.fabric.mixin;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1917;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveSpawnEvents;
import com.natamus.collective_fabric.util.Reference;

@Mixin(value = class_1917.class, priority = 1001)
public class BaseSpawnerMixin {
	@Inject(method = "tick()V", at = @At(value= "INVOKE", target = "Lnet/minecraft/world/entity/Mob;checkSpawnObstruction(Lnet/minecraft/world/level/LevelReader;)Z"), cancellable = true, locals = LocalCapture.CAPTURE_FAILSOFT)
	private void BaseSpawner_tick(CallbackInfo ci, class_1937 level, class_2338 blockPos, boolean bl, int i, class_2487 compoundTag, Optional<?> optional, class_2499 listTag, int j, double g, double h, double k, class_3218 serverLevel, class_1297 entity, class_1308 mob) {
		mob.method_5780(Reference.MOD_ID + ".fromspawner");
		
		if (level instanceof class_3218) {
			class_2338 mobPos = mob.method_24515();
			if (!CollectiveSpawnEvents.MOB_CHECK_SPAWN.invoker().onMobCheckSpawn(mob, (class_3218)level, mobPos.method_10263(), mobPos.method_10264(), mobPos.method_10260(), null, class_3730.field_16459)) {
				ci.cancel();
			}
		}
	}
}
