package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveEntityEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3532;

@Mixin(class_1309.class)
public class LivingEntityMixin {
	@Inject(method = "die(Lnet/minecraft/world/damagesource/DamageSource;)V", at = @At(value = "HEAD")) 
	public void LivingEntity_die(class_1282 damageSource, CallbackInfo ci) {
		class_1297 entity = (class_1297)(Object)this;
		class_1937 world = (class_1937)entity.method_5770();
		
		CollectiveEntityEvents.LIVING_ENTITY_DEATH.invoker().onDeath(world, entity, damageSource);
	}
	
	@Inject(method = "calculateFallDamage(FF)V", at = @At(value = "RETURN"), cancellable = true)
	protected int calculateFallDamage(float f, float g, CallbackInfoReturnable<Boolean> ci) {
		class_1309 livingEntity = (class_1309)(Object)this;
		class_1937 world = livingEntity.method_5770();
		
		if (CollectiveEntityEvents.ON_FALL_DAMAGE_CALC.invoker().onFallDamageCalc(world, livingEntity, f, g) == 0) {
			return 0;
		}
		
		class_1293 mobEffectInstance = livingEntity.method_6112(class_1294.field_5913);
		float h = mobEffectInstance == null ? 0.0F : (float)(mobEffectInstance.method_5578() + 1);
		return class_3532.method_15386((f - 3.0F - h) * g);
	}
}
