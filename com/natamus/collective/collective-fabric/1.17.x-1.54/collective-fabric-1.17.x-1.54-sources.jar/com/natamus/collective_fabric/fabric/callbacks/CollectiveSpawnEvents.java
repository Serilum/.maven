package com.natamus.collective_fabric.fabric.callbacks;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1308;
import net.minecraft.class_1917;
import net.minecraft.class_3218;
import net.minecraft.class_3730;

public class CollectiveSpawnEvents {
	private CollectiveSpawnEvents() { }
	 
    public static final Event<CollectiveSpawnEvents.Mob_Check_Spawn> MOB_CHECK_SPAWN = EventFactory.createArrayBacked(CollectiveSpawnEvents.Mob_Check_Spawn.class, callbacks -> (entity, world, x, y, z, spawner, spawnReason) -> {
        for (CollectiveSpawnEvents.Mob_Check_Spawn callback : callbacks) {
        	if (!callback.onMobCheckSpawn(entity, world, x, y, z, spawner, spawnReason)) {
        		return false;
        	}
        }
        
        return true;
    });
    
	@FunctionalInterface
	public interface Mob_Check_Spawn {
		 boolean onMobCheckSpawn(class_1308 entity, class_3218 world, double x, double y, double z, class_1917 spawner, class_3730 spawnReason);
	}
}
