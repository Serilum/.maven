package com.natamus.collective_fabric.fabric.callbacks;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1657;
import net.minecraft.class_1706;
import net.minecraft.class_1799;

public class CollectiveAnvilEvents {
	private CollectiveAnvilEvents() { }
	 
    public static final Event<CollectiveAnvilEvents.Anvil_Change> ANVIL_CHANGE = EventFactory.createArrayBacked(CollectiveAnvilEvents.Anvil_Change.class, callbacks -> (anvilmenu, left, right, itemName, baseCost, player) -> {
        for (CollectiveAnvilEvents.Anvil_Change callback : callbacks) {
        	int materialCost = callback.onAnvilChange(anvilmenu, left, right, itemName, baseCost, player);
        	if (materialCost >= 0) {
        		return materialCost;
        	}
        }
        
        return -1;
    });
    
	@FunctionalInterface
	public interface Anvil_Change {
		 int onAnvilChange(class_1706 anvilmenu, class_1799 left, class_1799 right, String itemName, int baseCost, class_1657 player);
	}
}
