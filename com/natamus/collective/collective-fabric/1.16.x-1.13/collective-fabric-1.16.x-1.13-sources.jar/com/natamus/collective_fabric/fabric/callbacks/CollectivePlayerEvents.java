package com.natamus.collective_fabric.fabric.callbacks;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class CollectivePlayerEvents {
	private CollectivePlayerEvents() { }
		 
    public static final Event<CollectivePlayerEvents.Player_Death> PLAYER_DEATH = EventFactory.createArrayBacked(CollectivePlayerEvents.Player_Death.class, callbacks -> (world, player) -> {
        for (CollectivePlayerEvents.Player_Death callback : callbacks) {
        	callback.onDeath(world, player);
        }
    });
    
    public static final Event<CollectivePlayerEvents.Player_Tick> PLAYER_TICK = EventFactory.createArrayBacked(CollectivePlayerEvents.Player_Tick.class, callbacks -> (world, player) -> {
        for (CollectivePlayerEvents.Player_Tick callback : callbacks) {
        	callback.onTick(world, player);
        }
    });
    
	@FunctionalInterface
	public interface Player_Death {
		 void onDeath(class_3218 world, class_3222 player);
	}
	
	@FunctionalInterface
	public interface Player_Tick {
		 void onTick(class_3218 world, class_3222 player);
	}
}
