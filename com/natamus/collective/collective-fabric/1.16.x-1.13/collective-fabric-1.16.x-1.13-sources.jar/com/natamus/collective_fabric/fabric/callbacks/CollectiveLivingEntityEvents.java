package com.natamus.collective_fabric.fabric.callbacks;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1937;

public final class CollectiveLivingEntityEvents {
	private CollectiveLivingEntityEvents() { }
		 
    public static final Event<CollectiveLivingEntityEvents.Living_Entity_Death> LIVING_ENTITY_DEATH = EventFactory.createArrayBacked(CollectiveLivingEntityEvents.Living_Entity_Death.class, callbacks -> (world, entity, source) -> {
        for (CollectiveLivingEntityEvents.Living_Entity_Death callback : callbacks) {
        	callback.onDeath(world, entity, source);
        }
    });
    
	@FunctionalInterface
	public interface Living_Entity_Death {
		 void onDeath(class_1937 world, class_1297 entity, class_1282 source);
	}
}
