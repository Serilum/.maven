package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.natamus.collective_fabric.fabric.callbacks.CollectivePlayerEvents;
import net.minecraft.class_1282;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

@Mixin(class_3222.class)
public class ServerPlayerMixin {
	@Inject(method = "die(Lnet/minecraft/world/damagesource/DamageSource;)V", at = @At(value = "HEAD"))
	public void ServerPlayer_die(class_1282 damageSource, CallbackInfo ci) {
		class_3222 player = (class_3222)(Object)this;
		class_3218 world = (class_3218)player.method_5770();
		
		CollectivePlayerEvents.PLAYER_DEATH.invoker().onDeath(world, player);
	}
	
	@Inject(method = "tick()V", at = @At(value = "HEAD"))
	public void ServerPlayer_tick(CallbackInfo ci) {
		class_3222 player = (class_3222)(Object)this;
		class_3218 world = (class_3218)player.method_5770();
		
		CollectivePlayerEvents.PLAYER_TICK.invoker().onTick(world, player);
	}
}
