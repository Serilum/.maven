package com.natamus.collective_fabric.fabric.mixin;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective_fabric.fabric.callbacks.CollectiveChatEvents;
import net.minecraft.class_2556;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_5837;
import net.minecraft.class_7471;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_3244.class, priority = 1001)
public abstract class ServerGamePacketListenerImplMixin {
	@Shadow private @Final MinecraftServer server;
	@Shadow public class_3222 player;
	@Shadow private int chatSpamTickCount;
	@Shadow public void disconnect(class_2561 component) { }
	
	@Inject(method = "broadcastChatMessage(Lnet/minecraft/server/network/FilteredText;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/players/PlayerList;broadcastChatMessage(Lnet/minecraft/server/network/FilteredText;Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/resources/ResourceKey;)V"), cancellable = true)
	private void ServerGamePacketListenerImpl_broadcastChatMessage(class_5837<class_7471> filteredText, CallbackInfo ci) {
		Pair<Boolean, class_2561> pair = CollectiveChatEvents.SERVER_CHAT_RECEIVED.invoker().onServerChat(player, filteredText.comp_841().method_44125(), player.method_5667());
		if (pair != null) {
			class_2561 newMessage = pair.getSecond();

			server.method_3760().method_43673(new class_5837<class_7471>(new class_7471(newMessage, null, null), null), this.player, class_2556.field_11737);
			
			this.chatSpamTickCount += 20;
			if (this.chatSpamTickCount > 200 && !this.server.method_3760().method_14569(this.player.method_7334())) {
				this.disconnect(class_2561.method_43471("disconnect.spam"));
			}
			ci.cancel();
		}
	}
}
