package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveSpawnEvents;
import com.natamus.collective_fabric.util.Reference;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1917;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3730;

@Mixin(value = class_1917.class, priority = 1001)
public class BaseSpawnerMixin {
	@ModifyVariable(method = "tick()V", at = @At(value= "INVOKE_ASSIGN", target = "Ljava/util/Random;nextFloat()F"))
	private class_1297 BaseSpawner_tick(class_1297 entity) {
		if (entity instanceof class_1308) {
			entity.method_5780(Reference.MOD_ID + ".fromspawner");
			
			class_1937 level = entity.field_6002;
			if (level instanceof class_3218) {
				class_2338 blockPos = entity.method_24515();
				if (!CollectiveSpawnEvents.MOB_CHECK_SPAWN.invoker().onMobCheckSpawn((class_1308)entity, (class_3218)level, blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260(), null, class_3730.field_16459)) {
					entity = null;
				}
			}
		}
		
		return entity;
	}
}
