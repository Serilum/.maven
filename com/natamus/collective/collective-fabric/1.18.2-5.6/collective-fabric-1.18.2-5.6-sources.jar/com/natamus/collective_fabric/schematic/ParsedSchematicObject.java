package com.natamus.collective_fabric.schematic;

import com.mojang.datafixers.util.Pair;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class ParsedSchematicObject {
    public List<Pair<class_2338, class_2680>> blocks;
    public List<Pair<class_2338, class_2586>> blockEntities;
    public String parseMessageString;

    public ParsedSchematicObject(List<Pair<class_2338, class_2680>> b, List<Pair<class_2338, class_2586>> bE, String pMS) {
        blocks = b;
        blockEntities = bE;
        parseMessageString = pMS;
    }
}