package com.natamus.collective_fabric.schematic;

import com.mojang.brigadier.StringReader;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2259;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2507;
import net.minecraft.class_2680;

public class Schematic {

	private int size;
	private short width;
	private short height;
	private short length;
	private boolean oldVersion;
	private HashMap<Integer, String> palette;
	private SchematicBlockObject[] blockObjects;
	private List<class_2487> blockEntities;
	
	public Schematic(File file) {
		try {
			
			String format = file.getName().split("\\.")[file.getName().split("\\.").length - 1];
			
			InputStream is = Files.newInputStream(file.toPath());
			class_2487 nbtdata = class_2507.method_10629(is);
			is.close();
			
			if (format.equals("nbt")) {
				
				class_2499 sizetags = nbtdata.method_10554("size", 3);
				
				width = (short) sizetags.method_10600(0);
				height = (short) sizetags.method_10600(1);
				length = (short) sizetags.method_10600(2);
				size = width * height * length;
				
				this.palette = new HashMap<>();
				class_2499 paletteTags = nbtdata.method_10554("palette", 10);
				
				for (int i = 0; i < paletteTags.size(); i++) {
					
					class_2487 entrynbt = paletteTags.method_10602(i);
					
					StringBuilder state = new StringBuilder(entrynbt.method_10558("Name"));
					
					if (entrynbt.method_10545("Properties")) {
						
						state.append("[");
						
						class_2487 propertiesNbt = entrynbt.method_10562("Properties");
						
						for (String property : propertiesNbt.method_10541()) {
							state.append(property).append("=").append(propertiesNbt.method_10558(property)).append(",");
						}
						
						state = new StringBuilder(state.substring(0, state.length() - 1) + "]");
						
					}
					
					palette.put(i, state.toString());
					
				}
				
				class_2499 blockTags = nbtdata.method_10554("blocks", 10);
				blockObjects = new SchematicBlockObject[size];
				blockEntities = new ArrayList<>();
				int counter = 0;
				
				for (int i = 0; i < blockTags.size(); i++) {
					
					class_2487 blocknbt = blockTags.method_10602(i);
					
					class_2499 ipos = blocknbt.method_10554("pos", 3);
					class_2338 pos = new class_2338(ipos.method_10600(0), ipos.method_10600(1), ipos.method_10600(2));
					
					int stateId = blocknbt.method_10550("state");
					class_2680 state = getStateFromID(stateId);
					
					blockObjects[counter++] = new SchematicBlockObject(pos, state);
					
					if (blocknbt.method_10545("nbt")) {
						
						class_2487 tileentitynbt = blocknbt.method_10562("nbt");
						tileentitynbt.method_10539("Pos", new int[] {pos.method_10263(), pos.method_10264(), pos.method_10260()});
						blockEntities.add(tileentitynbt);
						
					}
					
				}
				
			} else {
				
				width = nbtdata.method_10568("Width");
				height = nbtdata.method_10568("Height");
				length = nbtdata.method_10568("Length");
				size = width * height * length;
				this.oldVersion = !nbtdata.method_10545("DataVersion");
				
				blockObjects = new SchematicBlockObject[size];
				
				if (!oldVersion) {
					byte[] blocks = nbtdata.method_10547("BlockData");
					
					class_2487 palette = nbtdata.method_10562("Palette");
					this.palette = new HashMap<Integer, String>();
					for (String k : palette.method_10541()) {
						this.palette.put(palette.method_10550(k), k);
					}
					
					int counter = 0;
					for (int i = 0; i < height; i++) {
						for (int j = 0; j < length; j++) {
							for (int k = 0; k < width; k++) {
								
								class_2338 pos = new class_2338(k, i , j);

								int id = blocks[counter];
								
								if (id < 0) id *= -1;
								
								class_2680 state = getStateFromID(id);
								
								blockObjects[counter] = new SchematicBlockObject(pos, state);
								
								counter++;
								
							}
						}
		 			}
					
					class_2499 tileentitynbtlist = nbtdata.method_10554("BlockEntities", 10);
					this.blockEntities = new ArrayList<class_2487>();
					
					for (int i = 0; i < tileentitynbtlist.size(); i++) {
						this.blockEntities.add(tileentitynbtlist.method_10602(i));
					}
					
				} else {
					
					byte[] blockIDs_byte = nbtdata.method_10547("Blocks");
					int[] blockIDs = new int[size];
					for (int x = 0; x < blockIDs_byte.length; x++) {
						blockIDs[x] = Byte.toUnsignedInt(blockIDs_byte[x]);
					}
					
					byte[] metadata = nbtdata.method_10547("Data");
					
					int counter = 0;
					for (int i = 0; i < height; i++) {
						for (int j = 0; j < length; j++) {
							for (int k = 0; k < width; k++) {
								class_2338 pos = new class_2338(k, i , j);
								class_2680 state = getStateFromOldIds(blockIDs[counter], metadata[counter]);
								blockObjects[counter] = new SchematicBlockObject(pos, state);
								counter++;
							}
						}
		 			}
					
					class_2499 tileentitynbtlist = nbtdata.method_10554("TileEntities", 10);
					this.blockEntities = new ArrayList<class_2487>();
					
					for (int i = 0; i < tileentitynbtlist.size(); i++) {
						
						class_2487 compound = tileentitynbtlist.method_10602(i);
						int i1 = compound.method_10550("x");
						int i2 = compound.method_10550("y");
						int i3 = compound.method_10550("z");
						compound.method_10539("Pos", new int[] {i1, i2, i3});
						this.blockEntities.add(compound);
						
					}
					
				}
				
			}
			
		} catch (Exception e) {
			System.err.println("ERROR Cant load as Schematic: " + file);
			e.printStackTrace();
			this.width = 0;
			this.height = 0;
			this.length = 0;
			this.size = 0;
			this.blockObjects = null;
			this.palette = null;
			this.blockEntities = null;
		}
	}
	
	public boolean isOldVersion() {
		return oldVersion;
	}
	
	private class_2680 getStateFromOldIds(int blockID, byte meta) {
		return class_2248.method_9531(blockID);
	}
	
	public class_2680 getBlockState(class_2338 pos) {
		
		for (SchematicBlockObject obj : this.blockObjects) {
			if (obj.getPosition().equals(pos)) return obj.getState();
		}
		return class_2246.field_10124.method_9564();
		
	}
	
	public int getSize() {
		return size;
	}
	
	public SchematicBlockObject[] getBlocks() {
		return blockObjects;
	}
	
	public class_2680 getStateFromID(int id) {
		String iblockstateS = this.palette.get(id);
		
		try {
			class_2259 parser = new class_2259(new StringReader(iblockstateS), true);
			parser.method_9678(false);

			return parser.method_9669();
		} catch (Exception ex) {
			return class_2246.field_10124.method_9564();
		}
	}
	
	public List<class_2487> getBlockEntities() {
		return this.blockEntities;
	}
	
	public class_2487 getTileEntity(class_2338 pos) {
		
		for (class_2487 compound : this.blockEntities) {
			
			int[] pos1 = compound.method_10561("Pos");
			
			if (pos1[0] == pos.method_10263() && pos1[1] == pos.method_10264() && pos1[2] == pos.method_10260()) {
				
				return compound;
				
			}
			
		}
		
		return null;
		
	}

	public class_2338 getBlockPosFromCompoundTag(class_2487 compoundTag) {
		int[] pos = compoundTag.method_10561("Pos");
		return new class_2338(pos[0], pos[1], pos[2]);
	}
	
	public short getWidth() {
		return width;
	}
	
	public short getHeight() {
		return height;
	}
	
	public short getLength() {
		return length;
	}
	
}
