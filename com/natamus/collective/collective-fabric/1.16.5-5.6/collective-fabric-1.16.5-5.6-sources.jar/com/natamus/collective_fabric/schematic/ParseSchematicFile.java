package com.natamus.collective_fabric.schematic;

import com.mojang.datafixers.util.Pair;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class ParseSchematicFile {
    public static ParsedSchematicObject getParsedSchematicObject(String schematicPath, class_1937 level, class_2338 centerPos, int extraYOffset, boolean skipAir) {
        File schematicFile = new File(schematicPath);
        if(!schematicFile.exists() && schematicFile.isDirectory()) {
            return new ParsedSchematicObject(null, null, "Schematic file '" + schematicPath + "' does not exist.");
        }

        Schematic schematic = new Schematic(schematicFile);

        int maxBuildHeight = level.method_8322();
        int length = schematic.getLength();
        int width = schematic.getWidth();
        int height = schematic.getHeight();

        int yoffset = centerPos.method_10264() + extraYOffset;
        if (yoffset + height > maxBuildHeight) {
            yoffset = maxBuildHeight - height;
        }

        List<Pair<class_2338, class_2680>> blocks = new ArrayList<Pair<class_2338, class_2680>>();
        for (SchematicBlockObject blockObject : schematic.getBlocks()) {
            class_2680 blockState = blockObject.getState();
            if (skipAir && blockState.method_26204().equals(class_2246.field_10124)) {
                continue;
            }

            blocks.add(new Pair<class_2338, class_2680>(blockObject.getPosition().method_10069(centerPos.method_10263() - (width/2), yoffset, centerPos.method_10260() - (length/2)).method_10062(), blockState));
        }

        List<Pair<class_2338, class_2586>> blockEntities = new ArrayList<Pair<class_2338, class_2586>>();
        for (class_2487 blockEntityCompoundTag : schematic.getBlockEntities()) {
            class_2338 blockPos = schematic.getBlockPosFromCompoundTag(blockEntityCompoundTag).method_10069(centerPos.method_10263() - (width/2), yoffset, centerPos.method_10260() - (length/2));
            blockEntities.add(new Pair<class_2338, class_2586>(blockPos.method_10062(), level.method_8321(blockPos)));
        }

        return new ParsedSchematicObject(blocks, blockEntities, "Parsed successfully.");
    }
}
