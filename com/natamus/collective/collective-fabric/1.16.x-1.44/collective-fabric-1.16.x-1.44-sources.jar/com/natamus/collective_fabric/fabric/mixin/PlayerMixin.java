package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveEntityEvents;
import com.natamus.collective_fabric.fabric.callbacks.CollectivePlayerEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2680;

@Mixin(class_1657.class)
public class PlayerMixin {
	@ModifyVariable(method = "actuallyHurt(Lnet/minecraft/world/damagesource/DamageSource;F)V", at = @At(value= "INVOKE_ASSIGN", target = "Ljava/lang/Math;max(FF)F", ordinal = 0), ordinal = 0)
	private float Player_actuallyHurt(float f, class_1282 damageSource, float damage) {
		class_1309 livingEntity = (class_1309)(Object)this;
		class_1937 world = livingEntity.method_5770();

		float newDamage = CollectiveEntityEvents.ON_LIVING_DAMAGE_CALC.invoker().onLivingDamageCalc(world, livingEntity, damageSource, f);
		if (newDamage != -1 && newDamage != f) {
			return newDamage;
		}
		
		return f;
	}
	
	@ModifyVariable(method = "getDestroySpeed", at = @At(value= "RETURN"))
	private float Player_getDestroySpeed(float f, class_2680 state) {
		class_1657 player = (class_1657)(Object)this;
		class_1937 world = player.method_5770();

		float newSpeed = CollectivePlayerEvents.ON_PLAYER_DIG_SPEED_CALC.invoker().onDigSpeedCalc(world, player, f, state);
		if (newSpeed != -1 && newSpeed != f) {
			return newSpeed;
		}
		
		return f;
	}
}
