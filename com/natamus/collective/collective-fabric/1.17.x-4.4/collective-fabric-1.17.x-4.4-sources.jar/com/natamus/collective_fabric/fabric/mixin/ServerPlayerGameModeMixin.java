package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveBlockEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import net.minecraft.class_3965;
import net.minecraft.class_4463;

@Mixin(value = class_3225.class, priority = 1001)
public class ServerPlayerGameModeMixin {
	@Shadow protected class_3218 level;
	@Shadow @Final protected class_3222 player;
	@Shadow private class_2338 destroyPos;

	@Inject(method = "useItemOn", at = @At(value = "HEAD"), cancellable = true)
	public void ServerPlayerGameMode_useItemOn(class_3222 serverPlayer, class_1937 level, class_1799 itemStack, class_1268 interactionHand, class_3965 blockHitResult, CallbackInfoReturnable<class_1269> ci) {
		if (!CollectiveBlockEvents.BLOCK_RIGHT_CLICK.invoker().onBlockRightClick(level, serverPlayer, interactionHand, blockHitResult.method_17777(), blockHitResult)) {
			ci.setReturnValue(class_1269.field_5814);
		}
	}

	@Inject(method = "handleBlockBreakAction(Lnet/minecraft/core/BlockPos;Lnet/minecraft/network/protocol/game/ServerboundPlayerActionPacket$Action;Lnet/minecraft/core/Direction;I)V", at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/core/BlockPos;getZ()I", ordinal = 0), cancellable = true)
	public void handleBlockBreakAction(class_2338 blockPos, class_2846.class_2847 action, class_2350 direction, int i, CallbackInfo ci) {
		class_1937 level = player.field_6002;
		if (!CollectiveBlockEvents.BLOCK_LEFT_CLICK.invoker().onBlockLeftClick(level, player, blockPos, direction)) {
			player.field_13987.method_14364(new class_4463(blockPos, level.method_8320(blockPos), action, false, "canceled"));
			level.method_8413(blockPos, level.method_8320(blockPos), level.method_8320(blockPos), 3);
			ci.cancel();
		}
	}

	@Inject(method = "handleBlockBreakAction(Lnet/minecraft/core/BlockPos;Lnet/minecraft/network/protocol/game/ServerboundPlayerActionPacket$Action;Lnet/minecraft/core/Direction;I)V", at = @At(value = "INVOKE_ASSIGN", target = "Ljava/util/Objects;equals(Ljava/lang/Object;Ljava/lang/Object;)Z", ordinal = 0), cancellable = true)
	public void ServerPlayerGameMode_silence_block_mismatch(class_2338 blockPos, class_2846.class_2847 action, class_2350 direction, int i, CallbackInfo ci) {
		this.level.method_8517(this.player.method_5628(), this.destroyPos, -1);
		this.player.field_13987.method_14364(new class_4463(this.destroyPos, this.level.method_8320(this.destroyPos), action, true, "aborted mismatched destroying"));
		this.level.method_8517(this.player.method_5628(), blockPos, -1);
		this.player.field_13987.method_14364(new class_4463(blockPos, this.level.method_8320(blockPos), action, true, "aborted destroying"));
		ci.cancel();
	}
}
