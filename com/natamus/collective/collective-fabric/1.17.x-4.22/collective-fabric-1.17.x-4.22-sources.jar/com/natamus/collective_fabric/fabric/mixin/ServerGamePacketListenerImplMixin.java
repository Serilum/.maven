package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective_fabric.fabric.callbacks.CollectiveChatEvents;
import net.minecraft.class_2556;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_5513;
import net.minecraft.server.MinecraftServer;

@Mixin(value = class_3244.class, priority = 1001)
public abstract class ServerGamePacketListenerImplMixin {
	@Shadow private @Final MinecraftServer server;
	@Shadow public class_3222 player;
	@Shadow private int chatSpamTickCount;
	@Shadow public void disconnect(class_2561 component) { }

	@Inject(method = "handleChat(Lnet/minecraft/server/network/TextFilter$FilteredText;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/MinecraftServer;getPlayerList()Lnet/minecraft/server/players/PlayerList;", ordinal = 0), cancellable = true, locals = LocalCapture.CAPTURE_FAILSOFT)
	private void ServerGamePacketListenerImpl_handleChat(class_5513.class_5837 filteredText, CallbackInfo ci, String string, class_2561 component, class_2561 component2) {
		Pair<Boolean, class_2561> pair = CollectiveChatEvents.SERVER_CHAT_RECEIVED.invoker().onServerChat(player, component, player.method_5667());
		if (pair != null) {
			class_2561 newMessage = pair.getSecond();

			server.method_3760().method_33810(newMessage, (player) -> {
				return this.player.method_33795(player) ? component : newMessage;
			}, class_2556.field_11737, player.method_5667());
			
			this.chatSpamTickCount += 20;
			if (this.chatSpamTickCount > 200 && !this.server.method_3760().method_14569(this.player.method_7334())) {
				this.disconnect(new class_2588("disconnect.spam"));
			}
			ci.cancel();
		}
	}
}
