package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective_fabric.fabric.callbacks.CollectiveChatEvents;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3244;

@Mixin(value = class_3244.class, priority = 900)
public class ServerGamePacketListenerImplMixin {
	@Shadow public class_3222 player;
	
	@ModifyVariable(method = "handleChat(Ljava/lang/String;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/MinecraftServer;getPlayerList()Lnet/minecraft/server/players/PlayerList;", ordinal = 0), ordinal = 0)
	public class_2561 ServerGamePacketListenerImpl_handleChat(class_2561 component, String string) {
		Pair<Boolean, class_2561> pair = CollectiveChatEvents.SERVER_CHAT_RECEIVED.invoker().onServerChat(player, component, player.method_5667());
		if (pair != null) {
			component = pair.getSecond();
		}
		
		return component;
	}
}
