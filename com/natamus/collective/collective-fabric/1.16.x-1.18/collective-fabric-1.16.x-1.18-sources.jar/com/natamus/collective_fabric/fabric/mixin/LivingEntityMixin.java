package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveLivingEntityEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;

@Mixin(class_1309.class)
public class LivingEntityMixin {
	@Inject(method = "die(Lnet/minecraft/world/damagesource/DamageSource;)V", at = @At(value = "HEAD")) 
	public void LivingEntity_die(class_1282 damageSource, CallbackInfo ci) {
		class_1297 entity = (class_1297)(Object)this;
		class_1937 world = (class_1937)entity.method_5770();
		
		CollectiveLivingEntityEvents.LIVING_ENTITY_DEATH.invoker().onDeath(world, entity, damageSource);
	}
}
