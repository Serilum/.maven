package com.natamus.collective_fabric.schematic;

import com.mojang.datafixers.util.Pair;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class ParsedSchematicObject {
    public Schematic schematic;
    public List<Pair<class_2338, class_2680>> blocks;
    public List<Pair<class_2338, class_1297>> entities;
    public List<class_2338> blockEntityPositions;
    public String parseMessageString;
    public boolean parsedCorrectly;

    public int offsetX;
    public int offsetY;
    public int offsetZ;

    public ParsedSchematicObject(Schematic _schematic, List<Pair<class_2338, class_2680>> _blocks, List<Pair<class_2338, class_1297>> _entities, List<class_2338> _blockEntityPositions, String _parseMessageString, boolean _parsedCorrectly) {
        schematic = _schematic;
        blocks = _blocks;
        entities = _entities;
        blockEntityPositions = _blockEntityPositions;
        parseMessageString = _parseMessageString;
        parsedCorrectly = _parsedCorrectly;

        offsetX = _schematic.getOffsetX();
        offsetY = _schematic.getOffsetY();
        offsetZ = _schematic.getOffsetZ();
    }

    public void placeBlockEntitiesInWorld(class_1937 level) {
        List<class_2487> compoundTags = schematic.getBlockEntities();

        int i = 0;
        for (Pair<class_2338, class_2586> pair : getBlockEntities(level)) {
            class_2338 pos = pair.getFirst();

            class_2487 compoundTag = compoundTags.get(i);
            compoundTag.method_10551("Pos");
            compoundTag.method_10582("id", compoundTag.method_10558("Id"));

            class_2586 blockEntity = class_2586.method_11005(level.method_8320(pos), compoundTag);
            level.method_8526(pos, blockEntity);
            i+=1;
        }
    }

    public List<Pair<class_2338, class_2586>> getBlockEntities(class_1937 level) {
        List<Pair<class_2338, class_2586>> blockEntities = new ArrayList<Pair<class_2338, class_2586>>();
        for (class_2338 pos : blockEntityPositions) {
            blockEntities.add(new Pair<class_2338, class_2586>(pos, level.method_8321(pos)));
        }
        return blockEntities;
    }
}