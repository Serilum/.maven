package com.natamus.collective_fabric.functions;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_3614;

public class BlockPosFunctions {
	// START: GET functions
	public static List<class_2338> getBlocksAround(class_2338 pos, boolean down) {
		List<class_2338> around = new ArrayList<class_2338>();
		around.add(pos.method_10095());
		around.add(pos.method_10078());
		around.add(pos.method_10072());
		around.add(pos.method_10067());
		around.add(pos.method_10084());
		if (down) {
			around.add(pos.method_10074());
		}
		return around;
	}
	
	// START: RECURSIVE GET BLOCKS
	public static List<class_2338> getBlocksNextToEachOther(class_1937 world, class_2338 startpos, List<class_2248> possibleblocks) {
		List<class_2338> checkedblocks = new ArrayList<class_2338>();
		List<class_2338> theblocksaround = new ArrayList<class_2338>();
		if (possibleblocks.contains(world.method_8320(startpos).method_26204())) {
			theblocksaround.add(startpos);
			checkedblocks.add(startpos);
		}
		
		recursiveGetNextBlocks(world, startpos, possibleblocks, theblocksaround, checkedblocks);
		return theblocksaround;
	}
	private static void recursiveGetNextBlocks(class_1937 world, class_2338 pos, List<class_2248> possibleblocks, List<class_2338> theblocksaround, List<class_2338> checkedblocks) {
		List<class_2338> possibleblocksaround = getBlocksAround(pos, true);
		for (class_2338 pba : possibleblocksaround) {
			if (checkedblocks.contains(pba)) {
				continue;
			}
			checkedblocks.add(pba);
			
			if (possibleblocks.contains(world.method_8320(pba).method_26204())) {
				if (!theblocksaround.contains(pba)) {
					theblocksaround.add(pba);
					recursiveGetNextBlocks(world, pba, possibleblocks, theblocksaround, checkedblocks);
				}
			}
		}
	}
	public static List<class_2338> getBlocksNextToEachOtherMaterial(class_1937 world, class_2338 startpos, List<class_3614> possiblematerials) {
		List<class_2338> checkedblocks = new ArrayList<class_2338>();
		List<class_2338> theblocksaround = new ArrayList<class_2338>();
		if (possiblematerials.contains(world.method_8320(startpos).method_26207())) {
			theblocksaround.add(startpos);
			checkedblocks.add(startpos);
		}
		
		recursiveGetNextBlocksMaterial(world, startpos, possiblematerials, theblocksaround, checkedblocks);
		return theblocksaround;
	}
	private static void recursiveGetNextBlocksMaterial(class_1937 world, class_2338 pos, List<class_3614> possiblematerials, List<class_2338> theblocksaround, List<class_2338> checkedblocks) {
		List<class_2338> possibleblocksaround = getBlocksAround(pos, true);
		for (class_2338 pba : possibleblocksaround) {
			if (checkedblocks.contains(pba)) {
				continue;
			}
			checkedblocks.add(pba);
			
			if (possiblematerials.contains(world.method_8320(pba).method_26207())) {
				if (!theblocksaround.contains(pba)) {
					theblocksaround.add(pba);
					recursiveGetNextBlocksMaterial(world, pba, possiblematerials, theblocksaround, checkedblocks);
				}
			}
		}
	}
	// END RECURSIVE GET BLOCKS
	
	public static class_2338 getSurfaceBlockPos(class_3218 serverworld, int x, int z) {
		int height = serverworld.method_24853();
		
		class_2338 returnpos = new class_2338(x, height-1, z);
		if (!WorldFunctions.isNether(serverworld)) {
			class_2338 pos = new class_2338(x, height, z);
			for (int y = height; y > 0; y--) {
				class_2680 blockstate = serverworld.method_8320(pos);
				class_3614 material = blockstate.method_26207();
				if (blockstate.method_26193(serverworld, pos) >= 15 || material.equals(class_3614.field_15958) || material.equals(class_3614.field_15928)) {
					returnpos = pos.method_10084().method_10062();
					break;
				}
				
				pos = pos.method_10074();
			}
		}
		else {
			int maxheight = 128;
			class_2338 pos = new class_2338(x, 0, z);
			for (int y = 0; y < maxheight; y++) {
				class_2680 blockstate = serverworld.method_8320(pos);
				if (blockstate.method_26204().equals(class_2246.field_10124)) {
					class_2680 upstate = serverworld.method_8320(pos.method_10084());
					if (upstate.method_26204().equals(class_2246.field_10124)) {
						returnpos = pos.method_10062();
						break;
					}
				}
				
				pos = pos.method_10084();
			}
		}
		
		return returnpos;
	}
	
	public static class_2338 getCenterNearbyVillage(class_3218 serverworld) {
		return getNearbyVillage(serverworld, new class_2338(0, 0, 0));
	}
	public static class_2338 getNearbyVillage(class_3218 serverworld, class_2338 nearpos) {
		return getNearbyStructure(serverworld, class_3195.field_24858, nearpos, 9999);
	}
	
	public static class_2338 getCenterNearbyStructure(class_3218 serverworld, class_3195<?> structure) {
		return getNearbyStructure(serverworld, structure, new class_2338(0, 0, 0));
	}
	public static class_2338 getNearbyStructure(class_3218 serverworld, class_3195<?> structure, class_2338 nearpos) {
		return getNearbyStructure(serverworld, structure, nearpos, 9999);
	}	
	public static class_2338 getNearbyStructure(class_3218 serverworld, class_3195<?> structure, class_2338 nearpos, int radius) {
		class_2338 villagepos = serverworld.method_8487(structure, nearpos, radius, false);
		if (villagepos == null) {
			return null;
		}
		
		class_2338 spawnpos = null;
		for (int y = serverworld.method_24853()-1; y > 0; y--) {
			class_2338 checkpos = new class_2338(villagepos.method_10263(), y, villagepos.method_10260());
			if (serverworld.method_8320(checkpos).method_26204().equals(class_2246.field_10124)) {
				continue;
			}
			spawnpos = checkpos.method_10084().method_10062();
			break;
		}
		
		return spawnpos;
	}
	
	public static class_2338 getCenterBiome(class_3218 serverworld, class_1959 biome) {
		class_2338 centerpos = new class_2338(0, 0, 0);
		class_2338 biomepos = serverworld.method_24500(biome, centerpos, 999999, 0);
		if (biomepos == null) {
			return null;
		}
		
		class_2338 spawnpos = null;
		for (int y = serverworld.method_24853()-1; y > 0; y--) {
			class_2338 checkpos = new class_2338(biomepos.method_10263(), y, biomepos.method_10260());
			if (serverworld.method_8320(checkpos).method_26204().equals(class_2246.field_10124)) {
				continue;
			}
			spawnpos = checkpos.method_10084().method_10062();
			break;
		}
		
		return spawnpos;
	}
	
	public static class_2338 getBlockPlayerIsLookingAt(class_1937 world, class_1657 player, boolean stopOnLiquid) {
		class_239 raytraceresult = RayTraceFunctions.rayTrace(world, player, stopOnLiquid);
        double posX = raytraceresult.method_17784().field_1352;
        double posY = Math.floor(raytraceresult.method_17784().field_1351);
        double posZ = raytraceresult.method_17784().field_1350;

        return new class_2338(posX, posY, posZ);
	}
	// END: GET functions
	
	
	// START: CHECK functions
	public static Boolean isOnSurface(class_1937 world, class_2338 pos) {
		return world.method_8311(pos);
	}
	public static Boolean isOnSurface(class_1937 world, class_243 vecpos) {
		return isOnSurface(world, new class_2338(vecpos.field_1352, vecpos.field_1351, vecpos.field_1350));
	}
	
	
	public static Boolean withinDistance(class_2338 start, class_2338 end, int distance) {
		if (withinDistance(start, end, (double)distance)) {
			return true;
		}
		return false;
	}
	public static Boolean withinDistance(class_2338 start, class_2338 end, double distance) {
		if (start.method_19771(end, distance)) {
			return true;
		}
		return false;
	}
	// END: CHECK functions
	
	// START: Fabric Specific
	public static class_2338 getBlockPosFromHitResult(class_239 hitresult) {
		class_243 vec = hitresult.method_17784();
		return new class_2338(vec.field_1352, vec.field_1351, vec.field_1350);
	}
	// END: Fabric Specific
}