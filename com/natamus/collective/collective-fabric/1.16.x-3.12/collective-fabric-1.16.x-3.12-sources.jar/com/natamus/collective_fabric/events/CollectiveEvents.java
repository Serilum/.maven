package com.natamus.collective_fabric.events;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import com.natamus.collective_fabric.check.RegisterMod;
import com.natamus.collective_fabric.config.CollectiveConfigHandler;
import com.natamus.collective_fabric.data.GlobalVariables;
import com.natamus.collective_fabric.functions.BlockPosFunctions;
import com.natamus.collective_fabric.functions.EntityFunctions;
import com.natamus.collective_fabric.functions.SpawnEntityFunctions;
import com.natamus.collective_fabric.objects.SAMObject;
import com.natamus.collective_fabric.util.Reference;

public class CollectiveEvents {
	public static HashMap<class_3218, List<class_1297>> entitiesToSpawn = new HashMap<class_3218, List<class_1297>>();
	public static HashMap<class_3218, HashMap<class_1297, class_1297>> entitiesToRide = new HashMap<class_3218, HashMap<class_1297, class_1297>>();
	
	public static void onWorldLoad(class_3218 serverworld) {
		entitiesToSpawn.put(serverworld, new ArrayList<class_1297>());
		entitiesToRide.put(serverworld, new HashMap<class_1297, class_1297>());
	}
	
	public static void onWorldTick(class_3218 world) {	
		class_3218 serverworld = (class_3218)world;
		if (entitiesToSpawn.get(serverworld).size() > 0) {
			class_1297 tospawn = entitiesToSpawn.get(serverworld).get(0);
			
			serverworld.method_30771(tospawn);
			
			if (entitiesToRide.get(world).containsKey(tospawn)) {
				class_1297 rider = entitiesToRide.get(world).get(tospawn);
				
				rider.method_5804(tospawn);
				
				entitiesToRide.get(world).remove(tospawn);
			}
			
			entitiesToSpawn.get(world).remove(0);
		}
	}
	
	public static void onEntityJoinLevel(class_1937 world, class_1297 entity) {
		if (entity instanceof class_1309 == false) {
			return;
		}
		
		if (RegisterMod.shouldDoCheck) {
			if (entity instanceof class_1657) {
				RegisterMod.joinWorldProcess(world, (class_1657)entity);
			}
		}
		
		if (entity.field_5988) {
			return;
		}
		
		if (GlobalVariables.samobjects.isEmpty()) {
			return;
		}
		
		Set<String> tags = entity.method_5752();
		if (tags.contains(Reference.MOD_ID + ".checked")) {
			return;
		}
		entity.method_5780(Reference.MOD_ID + ".checked");
		
		class_1299<?> entitytype = entity.method_5864();
		if (entitytype == null || !GlobalVariables.activesams.contains(entitytype)) {
			return;	
		}
		
		boolean isspawner = tags.contains(Reference.MOD_ID + ".fromspawner");
		
		List<SAMObject> possibles = new ArrayList<SAMObject>();
		Iterator<SAMObject> iterator = GlobalVariables.samobjects.iterator();
		while (iterator.hasNext()) {
			SAMObject samobject = iterator.next();
			if (samobject == null) {
				continue;
			}
			
			if (samobject.fromtype == null) {
				continue;
			}
			if (samobject.fromtype.equals(entitytype)) {
				if ((samobject.spawner && !isspawner) || (!samobject.spawner && isspawner)) {
					continue;
				}
				possibles.add(samobject);
			}
		}
		
		int size = possibles.size();
		if (size == 0) {
			return;
		}
		
		for (SAMObject sam : possibles) {
			double num = GlobalVariables.random.nextDouble();
			if (num > sam.chance) {
				continue;
			}
			
			class_243 evec = entity.method_19538();
			if (sam.surface) {
				if (!BlockPosFunctions.isOnSurface(world, evec)) {
					continue;
				}
			}
			
			class_1297 to = sam.totype.method_5883(world);
			//to.setWorld(Level);
			to.method_5814(evec.field_1352, evec.field_1351, evec.field_1350);
			
			boolean ignoremainhand = false;
			if (sam.helditem != null) {
				if (to instanceof class_1309) {
					class_1309 le = (class_1309)to;
					if (!le.method_6047().method_7909().equals(sam.helditem)) {
						le.method_6122(class_1268.field_5808, new class_1799(sam.helditem, 1));
						ignoremainhand = true;
					}
				}
			}
			
			boolean ride = false;
			if (EntityFunctions.isHorse(to) && sam.rideable) {
				class_1496 ah = (class_1496)to;
				ah.method_6766(true);
				to = ah;
				
				ride = true;
			}
			else {
				if (CollectiveConfigHandler.transferItemsBetweenReplacedEntities.getValue()) {
					EntityFunctions.transferItemsBetweenEntities(entity, to, ignoremainhand);
				}
			}
			
			if (world instanceof class_3218 == false) {
				return;
			}
			
			class_3218 serverworld = (class_3218)world;
			
			if (ride) {
				SpawnEntityFunctions.startRidingEntityOnNextTick(serverworld, to, entity); //entity.startRiding(to);
			}
			else {
				entity.method_5650();
			}
			
			to.method_5780(Reference.MOD_ID + ".checked");
			SpawnEntityFunctions.spawnEntityOnNextTick(serverworld, to); //serverworld.addFreshEntityWithPassengers(to);

			break;
		}
	}
}