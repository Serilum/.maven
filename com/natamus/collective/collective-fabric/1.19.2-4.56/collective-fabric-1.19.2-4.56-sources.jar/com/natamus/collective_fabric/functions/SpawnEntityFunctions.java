package com.natamus.collective_fabric.functions;

import com.natamus.collective_fabric.events.CollectiveEvents;
import java.util.ArrayList;
import java.util.HashMap;
import net.minecraft.class_1297;
import net.minecraft.class_3218;

public class SpawnEntityFunctions {
	public static void spawnEntityOnNextTick(class_3218 serverlevel, class_1297 entity) {
		if (!CollectiveEvents.entitiesToSpawn.containsKey(serverlevel)) {
			CollectiveEvents.entitiesToSpawn.put(serverlevel, new ArrayList<class_1297>());
		}
		CollectiveEvents.entitiesToSpawn.get(serverlevel).add(entity);
	}

	public static void startRidingEntityOnNextTick(class_3218 serverlevel, class_1297 ridden, class_1297 rider) {
		if (!CollectiveEvents.entitiesToRide.containsKey(serverlevel)) {
			CollectiveEvents.entitiesToRide.put(serverlevel, new HashMap<class_1297, class_1297>());
		}
		CollectiveEvents.entitiesToRide.get(serverlevel).put(ridden, rider);
	}
}
