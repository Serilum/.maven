package com.natamus.collective_fabric.schematic;

import com.mojang.brigadier.StringReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2259;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2507;
import net.minecraft.class_2680;

public class Schematic {

	private int size;
	private short width;
	private short height;
	private short length;
	private boolean oldVersion;
	private HashMap<Integer, String> palette;
	private SchematicBlockObject[] blockObjects;
	private List<class_2487> blockEntities;

	public Schematic(InputStream inputStream) {
		try {
			class_2487 nbtdata = class_2507.method_10629(inputStream);
			inputStream.close();

			width = nbtdata.method_10568("Width");
			height = nbtdata.method_10568("Height");
			length = nbtdata.method_10568("Length");
			size = width * height * length;
			this.oldVersion = !nbtdata.method_10545("DataVersion");

			blockObjects = new SchematicBlockObject[size];

			if (!oldVersion) {
				byte[] blocks = nbtdata.method_10547("BlockData");

				class_2487 palette = nbtdata.method_10562("Palette");
				this.palette = new HashMap<Integer, String>();
				for (String k : palette.method_10541()) {
					this.palette.put(palette.method_10550(k), k);
				}

				int counter = 0;
				for (int i = 0; i < height; i++) {
					for (int j = 0; j < length; j++) {
						for (int k = 0; k < width; k++) {

							class_2338 pos = new class_2338(k, i , j);

							int id = blocks[counter];

							if (id < 0) id *= -1;

							class_2680 state = getStateFromID(id);

							blockObjects[counter] = new SchematicBlockObject(pos, state);

							counter++;

						}
					}
				}

				class_2499 tileentitynbtlist = nbtdata.method_10554("BlockEntities", 10);
				this.blockEntities = new ArrayList<class_2487>();

				for (int i = 0; i < tileentitynbtlist.size(); i++) {
					this.blockEntities.add(tileentitynbtlist.method_10602(i));
				}

			} else {

				byte[] blockIDs_byte = nbtdata.method_10547("Blocks");
				int[] blockIDs = new int[size];
				for (int x = 0; x < blockIDs_byte.length; x++) {
					blockIDs[x] = Byte.toUnsignedInt(blockIDs_byte[x]);
				}

				byte[] metadata = nbtdata.method_10547("Data");

				int counter = 0;
				for (int i = 0; i < height; i++) {
					for (int j = 0; j < length; j++) {
						for (int k = 0; k < width; k++) {
							class_2338 pos = new class_2338(k, i , j);
							class_2680 state = getStateFromOldIds(blockIDs[counter], metadata[counter]);
							blockObjects[counter] = new SchematicBlockObject(pos, state);
							counter++;
						}
					}
				}

				class_2499 tileentitynbtlist = nbtdata.method_10554("TileEntities", 10);
				this.blockEntities = new ArrayList<class_2487>();

				for (int i = 0; i < tileentitynbtlist.size(); i++) {

					class_2487 compound = tileentitynbtlist.method_10602(i);
					int i1 = compound.method_10550("x");
					int i2 = compound.method_10550("y");
					int i3 = compound.method_10550("z");
					compound.method_10539("Pos", new int[] {i1, i2, i3});
					this.blockEntities.add(compound);

				}
			}
		} catch (Exception e) {
			System.err.println("ERROR Cant load Schematic");
			e.printStackTrace();
			this.width = 0;
			this.height = 0;
			this.length = 0;
			this.size = 0;
			this.blockObjects = null;
			this.palette = null;
			this.blockEntities = null;
		}
	}
	
	public boolean isOldVersion() {
		return oldVersion;
	}
	
	private class_2680 getStateFromOldIds(int blockID, byte meta) {
		return class_2248.method_9531(blockID);
	}
	
	public class_2680 getBlockState(class_2338 pos) {
		
		for (SchematicBlockObject obj : this.blockObjects) {
			if (obj.getPosition().equals(pos)) return obj.getState();
		}
		return class_2246.field_10124.method_9564();
		
	}
	
	public int getSize() {
		return size;
	}
	
	public SchematicBlockObject[] getBlocks() {
		return blockObjects;
	}

	public class_2680 getStateFromID(int id) {
		String iblockstateS = this.palette.get(id);
		
		try {
			class_2259 parser = new class_2259(new StringReader(iblockstateS), true);
			parser.method_9678(false);

			return parser.method_9669();
		} catch (Exception ex) {
			return class_2246.field_10124.method_9564();
		}
	}
	
	public List<class_2487> getBlockEntities() {
		return this.blockEntities;
	}
	
	public class_2487 getTileEntity(class_2338 pos) {
		
		for (class_2487 compound : this.blockEntities) {
			
			int[] pos1 = compound.method_10561("Pos");
			
			if (pos1[0] == pos.method_10263() && pos1[1] == pos.method_10264() && pos1[2] == pos.method_10260()) {
				
				return compound;
				
			}
			
		}
		
		return null;
		
	}

	public class_2338 getBlockPosFromCompoundTag(class_2487 compoundTag) {
		int[] pos = compoundTag.method_10561("Pos");
		return new class_2338(pos[0], pos[1], pos[2]);
	}
	
	public short getWidth() {
		return width;
	}
	
	public short getHeight() {
		return height;
	}
	
	public short getLength() {
		return length;
	}
	
}
