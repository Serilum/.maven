package com.natamus.collective_fabric.events;

import com.natamus.collective_fabric.check.RegisterMod;
import com.natamus.collective_fabric.config.CollectiveConfigHandler;
import com.natamus.collective_fabric.data.GlobalVariables;
import com.natamus.collective_fabric.functions.BlockPosFunctions;
import com.natamus.collective_fabric.functions.EntityFunctions;
import com.natamus.collective_fabric.functions.SpawnEntityFunctions;
import com.natamus.collective_fabric.objects.SAMObject;
import com.natamus.collective_fabric.util.Reference;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.class_1268;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1297.class_5529;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3218;

public class CollectiveEvents {
	public static WeakHashMap<class_3218, List<class_1297>> entitiesToSpawn = new WeakHashMap<class_3218, List<class_1297>>();
	public static WeakHashMap<class_3218, WeakHashMap<class_1297, class_1297>> entitiesToRide = new WeakHashMap<class_3218, WeakHashMap<class_1297, class_1297>>();

	public static void onWorldLoad(class_3218 serverlevel) {
		entitiesToSpawn.put(serverlevel, new ArrayList<class_1297>());
		entitiesToRide.put(serverlevel, new WeakHashMap<class_1297, class_1297>());
	}

	public static void onWorldTick(class_3218 serverlevel) {
		if (!entitiesToSpawn.containsKey(serverlevel)) {
			entitiesToSpawn.put(serverlevel, new ArrayList<class_1297>());
		}
		else if (entitiesToSpawn.get(serverlevel).size() > 0) {
			class_1297 tospawn = entitiesToSpawn.get(serverlevel).get(0);

			serverlevel.method_30771(tospawn);

			if (!entitiesToRide.containsKey(serverlevel)) {
				entitiesToRide.put(serverlevel, new WeakHashMap<class_1297, class_1297>());
			}
			else if (entitiesToRide.get(serverlevel).containsKey(tospawn)) {
				class_1297 rider = entitiesToRide.get(serverlevel).get(tospawn);

				rider.method_5804(tospawn);

				entitiesToRide.get(serverlevel).remove(tospawn);
			}

			entitiesToSpawn.get(serverlevel).remove(0);
		}
	}
	
	public static void onEntityJoinLevel(class_1937 world, class_1297 entity) {
		if (!(entity instanceof class_1309)) {
			return;
		}
		
		if (RegisterMod.shouldDoCheck) {
			if (entity instanceof class_1657) {
				RegisterMod.joinWorldProcess(world, (class_1657)entity);
			}
		}
		
		if (entity.method_31481()) {
			return;
		}
		
		if (GlobalVariables.samobjects.isEmpty()) {
			return;
		}
		
		Set<String> tags = entity.method_5752();
		if (tags.contains(Reference.MOD_ID + ".checked")) {
			return;
		}
		entity.method_5780(Reference.MOD_ID + ".checked");
		
		class_1299<?> entitytype = entity.method_5864();
		if (entitytype == null || !GlobalVariables.activesams.contains(entitytype)) {
			return;	
		}
		
		boolean isspawner = tags.contains(Reference.MOD_ID + ".fromspawner");
		
		List<SAMObject> possibles = new ArrayList<SAMObject>();
		for (SAMObject samobject : GlobalVariables.samobjects) {
			if (samobject == null) {
				continue;
			}

			if (samobject.fromtype == null) {
				continue;
			}
			if (samobject.fromtype.equals(entitytype)) {
				if ((samobject.spawner && !isspawner) || (!samobject.spawner && isspawner)) {
					continue;
				}
				possibles.add(samobject);
			}
		}
		
		int size = possibles.size();
		if (size == 0) {
			return;
		}

		boolean ageable = entity instanceof class_1296;

		for (SAMObject sam : possibles) {
			double num = GlobalVariables.random.nextDouble();
			if (num > sam.chance) {
				continue;
			}
			
			class_243 evec = entity.method_19538();
			if (sam.surface) {
				if (!BlockPosFunctions.isOnSurface(world, evec)) {
					continue;
				}
			}
			
			class_1297 to = sam.totype.method_5883(world);
			if (to == null) {
				return;
			}

			//to.setWorld(Level);
			to.method_5814(evec.field_1352, evec.field_1351, evec.field_1350);

			if (ageable && to instanceof class_1296) {
				class_1296 am = (class_1296)to;
				am.method_5614(((class_1296)entity).method_5618());
				to = am;
			}

			boolean ignoremainhand = false;
			if (sam.helditem != null) {
				if (to instanceof class_1309) {
					class_1309 le = (class_1309)to;
					if (!le.method_6047().method_7909().equals(sam.helditem)) {
						le.method_6122(class_1268.field_5808, new class_1799(sam.helditem, 1));
						ignoremainhand = true;
					}
				}
			}
			
			boolean ride = false;
			if (EntityFunctions.isHorse(to) && sam.rideable) {
				class_1496 ah = (class_1496)to;
				ah.method_6766(true);

				ride = true;
			}
			else {
				if (CollectiveConfigHandler.transferItemsBetweenReplacedEntities) {
					EntityFunctions.transferItemsBetweenEntities(entity, to, ignoremainhand);
				}
			}
			
			if (!(world instanceof class_3218)) {
				return;
			}
			
			class_3218 serverworld = (class_3218)world;
			
			if (ride) {
				SpawnEntityFunctions.startRidingEntityOnNextTick(serverworld, to, entity); //entity.startRiding(to);
			}
			else {
				entity.method_5650(class_5529.field_26999);
			}

			to.method_5780(Reference.MOD_ID + ".checked");
			SpawnEntityFunctions.spawnEntityOnNextTick(serverworld, to); //serverworld.addFreshEntityWithPassengers(to);

			break;
		}
	}
}