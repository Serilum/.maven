package com.natamus.collective_fabric.functions;

import static net.minecraft.class_315.method_41782;

import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_7172;

public class GameSettingsFunctions {
    private static boolean setGammaOnce = false;

    public static void setGamma(class_315 options, double gamma) {
        if (!setGammaOnce) {
            setGammaOnce = true;

            options.field_1840 = new class_7172<>("options.gamma", class_7172.method_42399(), (p_231913_, p_231914_) -> {
                return method_41783(p_231913_, class_2561.method_43471("options.gamma.default"));
            }, class_7172.class_7177.field_37875, 0.5D, (p_231877_) -> { });
        }
        options.field_1840.method_41748(gamma);
    }
    public static double getGamma(class_315 options) {
        return options.field_1840.method_41753();
    }
}
