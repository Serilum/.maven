package com.natamus.collective_fabric.functions;

import net.minecraft.class_315;

public class GameSettingsFunctions {
    public static void setGamma(class_315 options, double gamma) {
        options.field_1840 = gamma;
    }
}
