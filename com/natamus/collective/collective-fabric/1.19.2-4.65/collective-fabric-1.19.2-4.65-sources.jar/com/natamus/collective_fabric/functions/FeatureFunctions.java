package com.natamus.collective_fabric.functions;

import com.natamus.collective_fabric.data.GlobalVariables;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2621;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_39;

public class FeatureFunctions {
	public static boolean placeBonusChest(class_1937 world, class_2338 blockposIn) {
		class_1923 chunkpos = new class_1923(blockposIn);
		List<Integer> list = IntStream.rangeClosed(chunkpos.method_8326(), chunkpos.method_8327()).boxed().collect(Collectors.toList());
		Collections.shuffle(list, GlobalVariables.random);
		List<Integer> list1 = IntStream.rangeClosed(chunkpos.method_8328(), chunkpos.method_8329()).boxed().collect(Collectors.toList());
		Collections.shuffle(list1, GlobalVariables.random);
		class_2338.class_2339 blockpos$mutable = new class_2338.class_2339();
		
		for(Integer integer : list) {
			for(Integer integer1 : list1) {
				blockpos$mutable.method_10103(integer, 0, integer1);
				class_2338 blockpos = world.method_8598(class_2902.class_2903.field_13203, blockpos$mutable);
				if (world.method_22347(blockpos) || world.method_8320(blockpos).method_26220(world, blockpos).method_1110()) {
					world.method_8652(blockpos, class_2246.field_10034.method_9564(), 2);
					class_2621.method_11287(world, GlobalVariables.randomSource, blockpos, class_39.field_850);
					class_2680 blockstate = class_2246.field_10336.method_9564();
					
					for(class_2350 direction : class_2350.class_2353.field_11062) {
						class_2338 blockpos1 = blockpos.method_10093(direction);
						if (blockstate.method_26184(world, blockpos1)) {
							world.method_8652(blockpos1, blockstate, 2);
						}
					}
					
					return true;
				}
			}
		}
		
		return false;
	}
}
