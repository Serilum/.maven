package com.natamus.collective_fabric.util;

public class Util {
    public static void init() {

    }
}
