package com.natamus.collective_fabric.functions;

import static net.minecraft.class_315.method_41782;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_7172;

public class GameSettingsFunctions {
    public static void setGammaValue() {
        class_310.method_1551().field_1690.field_1840 = new class_7172("options.gamma", class_7172.method_42399(), (component, double_) -> {
            int i = (int)((double)double_ * 100.0);
            if (i == 0) {
                return method_41783(component, class_2561.method_43471("options.gamma.min"));
            } else if (i == 50) {
                return method_41783(component, class_2561.method_43471("options.gamma.default"));
            } else {
                return i == 100 ? method_41783(component, class_2561.method_43471("options.gamma.max")) : method_41782(component, i);
            }
        }, class_7172.class_7177.field_37875, 0.5, (double_) -> {
        });
    }

    public static void setGamma(class_315 options, double gamma) {
        options.field_1840.method_41748(gamma);
    }
    public static double getGamma(class_315 options) {
        return options.field_1840.method_41753();
    }
}
