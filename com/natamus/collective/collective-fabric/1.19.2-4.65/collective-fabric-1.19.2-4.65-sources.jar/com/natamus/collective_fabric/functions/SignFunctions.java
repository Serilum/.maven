package com.natamus.collective_fabric.functions;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2625;
import net.minecraft.class_5244;

public class SignFunctions {
    public static List<String> getSignText(class_2625 signentity) {
        List<String> lines = new ArrayList<String>();

        for (class_2561 line : signentity.method_33830(false)) {
            if (line.equals(class_5244.field_39003)) {
                lines.add("");
                continue;
            }

            lines.add(line.getString());
        }

        return lines;
    }
}
