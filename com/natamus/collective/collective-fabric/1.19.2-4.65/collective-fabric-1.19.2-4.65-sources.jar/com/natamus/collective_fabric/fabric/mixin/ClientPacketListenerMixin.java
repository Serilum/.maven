package com.natamus.collective_fabric.fabric.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveChatEvents;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_7494;

@Mixin(value = class_634.class, priority = 1001)
public class ClientPacketListenerMixin {
	@Final @Shadow private class_310 minecraft;
	
	@Inject(method = "handleChatPreview(Lnet/minecraft/network/protocol/game/ClientboundChatPreviewPacket;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/chat/ClientChatPreview;handleResponse(ILnet/minecraft/network/chat/Component;)V"), cancellable = true)
	public void ClientPacketListener_handleChatPreview(class_7494 clientboundChatPreviewPacket, CallbackInfo ci) {
		class_2561 message = clientboundChatPreviewPacket.comp_832();
		class_2561 newMessage = CollectiveChatEvents.CLIENT_CHAT_RECEIVED.invoker().onClientChat(clientboundChatPreviewPacket.comp_831(), message, null);
		if (message != newMessage) {
			minecraft.field_1705.method_1743().method_44047().method_44060().method_44032(clientboundChatPreviewPacket.comp_831(), newMessage);
			ci.cancel();
		}
	}
}
