package com.natamus.collective_fabric.fabric.mixin;

import com.mojang.authlib.minecraft.OfflineSocialInteractions;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;
import net.minecraft.class_542;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_310.class, priority = 1001)
public class MinecraftMixin {
    @Shadow @Final private static Logger LOGGER;

    @Inject(method = "createSocialInteractions", cancellable = true, at = @At(value = "HEAD"))
    public void Minecraft_createUserApiService(YggdrasilAuthenticationService yggdrasilAuthenticationService, class_542 gameConfig, CallbackInfoReturnable<OfflineSocialInteractions> cir) {
        if (FabricLoader.getInstance().isDevelopmentEnvironment()) {
            LOGGER.error("Failed to verify authentication");
            cir.setReturnValue(new OfflineSocialInteractions());
        }
    }
}
