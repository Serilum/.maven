package com.natamus.collective_fabric.fabric.mixin;

import com.natamus.collective_fabric.functions.TaskFunctions;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.natamus.collective_fabric.fabric.callbacks.CollectiveEntityEvents;
import com.natamus.collective_fabric.fabric.callbacks.CollectiveItemEvents;
import com.natamus.collective_fabric.fabric.callbacks.CollectivePlayerEvents;

@Mixin(value = class_1657.class, priority = 1001)
public class PlayerMixin {
	@ModifyVariable(method = "actuallyHurt(Lnet/minecraft/world/damagesource/DamageSource;F)V", at = @At(value= "INVOKE_ASSIGN", target = "Ljava/lang/Math;max(FF)F", ordinal = 0), ordinal = 0, argsOnly = true)
	private float Player_actuallyHurt(float f, class_1282 damageSource, float damage) {
		class_1309 livingEntity = (class_1309)(Object)this;
		class_1937 world = livingEntity.method_5770();

		float newDamage = CollectiveEntityEvents.ON_LIVING_DAMAGE_CALC.invoker().onLivingDamageCalc(world, livingEntity, damageSource, f);
		if (newDamage != -1 && newDamage != f) {
			return newDamage;
		}
		
		return f;
	}
	
	@ModifyVariable(method = "getDestroySpeed", at = @At(value= "RETURN"))
	private float Player_getDestroySpeed(float f, class_2680 state) {
		class_1657 player = (class_1657)(Object)this;
		class_1937 world = player.method_5770();

		float newSpeed = CollectivePlayerEvents.ON_PLAYER_DIG_SPEED_CALC.invoker().onDigSpeedCalc(world, player, f, state);
		if (newSpeed != -1 && newSpeed != f) {
			return newSpeed;
		}
		
		return f;
	}
	
	@Inject(method = "drop(Lnet/minecraft/world/item/ItemStack;Z)Lnet/minecraft/world/entity/item/ItemEntity;", at = @At(value = "HEAD"))
	private void Player_drop(class_1799 itemStack, boolean bl, CallbackInfoReturnable<class_1542> ci) {
		class_1657 player = (class_1657)(Object)this;
		CollectiveItemEvents.ON_ITEM_TOSSED.invoker().onItemTossed(player, itemStack);
	}

	@Inject(method = "hurtCurrentlyUsedShield(F)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;hurtAndBreak(ILnet/minecraft/world/entity/LivingEntity;Ljava/util/function/Consumer;)V"))
	protected void hurtCurrentlyUsedShield(float f, CallbackInfo ci) {
		class_1657 player = (class_1657) (Object) this;
		if ((player.method_6030().method_7936() - player.method_6030().method_7919()) < 3) {
			class_1268 interactionHand = player.method_6058();
			class_1799 copy = player.method_6030().method_7972();
			TaskFunctions.enqueueTask(player.field_6002, () -> {
				if (player.method_6030().method_7960()) {
					CollectiveItemEvents.ON_ITEM_DESTROYED.invoker().onItemDestroyed(player, copy, interactionHand);
				}
			}, 0);
		}
	}

	@ModifyVariable(method = "interactOn(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResult;", at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/world/InteractionResult;consumesAction()Z", ordinal = 0), ordinal = 1)
	public class_1799 Player_interactOn_0(class_1799 itemStack2, class_1297 entity, class_1268 interactionHand) {
		class_1657 player = (class_1657) (Object) this;
		class_1799 itemStack = player.method_5998(interactionHand);
		if (itemStack.method_7960()) {
			if (!player.method_31549().field_7477) {
				CollectiveItemEvents.ON_ITEM_DESTROYED.invoker().onItemDestroyed(player, itemStack2, interactionHand);
			}
		}
		return itemStack2;
	}

	@ModifyVariable(method = "interactOn(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResult;", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;setItemInHand(Lnet/minecraft/world/InteractionHand;Lnet/minecraft/world/item/ItemStack;)V"))
	public class_1799 Player_interactOn_1(class_1799 itemStack2, class_1297 entity, class_1268 interactionHand) {
		class_1657 player = (class_1657) (Object) this;
		class_1799 itemStack = player.method_5998(interactionHand);
		if (itemStack.method_7960()) {
			if (!player.method_31549().field_7477) {
				CollectiveItemEvents.ON_ITEM_DESTROYED.invoker().onItemDestroyed(player, itemStack2, interactionHand);
			}
		}
		return itemStack2;
	}

	@ModifyVariable(method = "attack(Lnet/minecraft/world/entity/Entity;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;hurtEnemy(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/entity/player/Player;)V"))
	public class_1799 Player_attack(class_1799 k, class_1297 entity) {
		if ((k.method_7936() - k.method_7919()) < 3) {
			class_1657 player = (class_1657) (Object) this;
			class_1799 copy = k.method_7972();
			TaskFunctions.enqueueTask(player.field_6002, () -> {
				if (k.method_7960()) {
					CollectiveItemEvents.ON_ITEM_DESTROYED.invoker().onItemDestroyed(player, copy, class_1268.field_5808);
				}
			}, 0);
		}
		return k;
	}
}
