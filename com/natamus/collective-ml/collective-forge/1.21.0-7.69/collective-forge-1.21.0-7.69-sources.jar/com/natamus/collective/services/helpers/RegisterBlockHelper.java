package com.natamus.collective.services.helpers;

import com.mojang.datafixers.util.Pair;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.level.block.Block;

import javax.annotation.Nullable;
import java.util.function.Supplier;

public interface RegisterBlockHelper {
	<T extends Block> void registerBlock(Object modEventBusObject, ResourceLocation resourceLocation, Supplier<T> blockSupplier, boolean lastBlock);
	Block getRegisteredBlock(ResourceLocation resourceLocation);

	<T extends Block> void registerBlockItem(Object modEventBusObject, ResourceLocation resourceLocation, Supplier<T> blockSupplier, @Nullable ResourceKey<CreativeModeTab> creativeModeTabResourceKey, boolean lastBlock);
	Pair<Block, BlockItem> getRegisteredBlockItemPair(ResourceLocation resourceLocation);
}