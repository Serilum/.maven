package com.natamus.collective.services.helpers;

import com.mojang.datafixers.util.Pair;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.level.block.Block;

import javax.annotation.Nullable;

public interface RegisterBlockHelper {
	Pair<Block, BlockItem> registerAndGetBlockPair(ResourceLocation resourceLocation, Block block, @Nullable ResourceKey<CreativeModeTab> creativeModeTabResourceKey);
}