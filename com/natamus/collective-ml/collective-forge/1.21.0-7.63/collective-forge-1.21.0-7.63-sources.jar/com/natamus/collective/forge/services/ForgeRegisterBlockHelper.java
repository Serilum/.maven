package com.natamus.collective.forge.services;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective.services.Services;
import com.natamus.collective.services.helpers.RegisterBlockHelper;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import javax.annotation.Nullable;
import java.util.HashMap;

public class ForgeRegisterBlockHelper implements RegisterBlockHelper {
	private final HashMap<String, DeferredRegister<Block>> deferredBlockRegisterMap = new HashMap<String, DeferredRegister<Block>>();

    @Override
	public Pair<Block, BlockItem> registerAndGetBlockPair(ResourceLocation resourceLocation, Block block, @Nullable ResourceKey<CreativeModeTab> creativeModeTabResourceKey) {
		String namespace = resourceLocation.getNamespace();
		if (!deferredBlockRegisterMap.containsKey(namespace)) {
			deferredBlockRegisterMap.put(namespace, DeferredRegister.create(ForgeRegistries.BLOCKS, namespace));
		}

		RegistryObject<Block> deferredBlockObject = deferredBlockRegisterMap.get(namespace).register(resourceLocation.getPath(), () -> block);
		Block deferredBlock = deferredBlockObject.get();

		Item deferredItem = Services.REGISTERITEM.registerAndGetItem(resourceLocation, new BlockItem(block, new Item.Properties()), creativeModeTabResourceKey);

		return Pair.of(deferredBlock, (BlockItem)deferredItem);
	}
}