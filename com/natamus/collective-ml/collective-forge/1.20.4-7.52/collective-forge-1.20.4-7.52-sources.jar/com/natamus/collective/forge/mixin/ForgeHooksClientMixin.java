package com.natamus.collective.forge.mixin;

import com.natamus.collective.services.Services;
import net.minecraftforge.client.ForgeHooksClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@SuppressWarnings("UnstableApiUsage")
@Mixin(value = ForgeHooksClient.class, priority = 1001, remap = false)
public class ForgeHooksClientMixin {
	@Inject(method = "createWorldConfirmationScreen", at = @At(value = "HEAD"), cancellable = true)
	private static void createWorldConfirmationScreen(Runnable doConfirmedWorldLoad, CallbackInfo ci) {
		if (Services.MODLOADER.isDevelopmentEnvironment() || Services.MODLOADER.isModLoaded("hideexperimentalwarning")) {
			doConfirmedWorldLoad.run();
			ci.cancel();
		}
	}
}
