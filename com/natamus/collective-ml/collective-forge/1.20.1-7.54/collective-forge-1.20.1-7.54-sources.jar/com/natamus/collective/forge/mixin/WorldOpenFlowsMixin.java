package com.natamus.collective.forge.mixin;

import com.natamus.collective.services.Services;
import net.minecraft.client.gui.screens.worldselection.WorldOpenFlows;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value = WorldOpenFlows.class, priority = 1001)
public class WorldOpenFlowsMixin {
	@ModifyVariable(method = "doLoadLevel*", at = @At(value= "STORE"), ordinal = 5)
	public boolean loadLevel_bl2(boolean isLifeCycleStable) {
		return !Services.MODLOADER.isDevelopmentEnvironment() && !Services.MODLOADER.isModLoaded("hideexperimentalwarning");
	}
}
