package com.natamus.collective;

import com.natamus.collective.config.CollectiveConfigHandler;
import com.natamus.collective.config.DuskConfig;
import com.natamus.collective.data.GlobalVariables;
import com.natamus.collective.util.Reference;

public class CollectiveCommon {
    public static void init() {
        System.out.println("Loading Collective version " + Reference.VERSION + ".");

        CollectiveConfigHandler.initConfig();
        GlobalVariables.generateHashMaps();
    }
}
