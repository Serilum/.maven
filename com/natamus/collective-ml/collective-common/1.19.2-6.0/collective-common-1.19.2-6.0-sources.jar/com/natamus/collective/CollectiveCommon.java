package com.natamus.collective;

import com.natamus.collective.config.CollectiveConfigHandler;
import com.natamus.collective.data.GlobalVariables;
import com.natamus.collective.objects.SAMObject;
import com.natamus.collective.util.CollectiveReference;
import net.minecraft.world.entity.EntityType;

public class CollectiveCommon {
    public static void init() {
        System.out.println("Loading Collective version " + CollectiveReference.VERSION + ".");

        CollectiveConfigHandler.initConfig();
        GlobalVariables.generateHashMaps();

        new SAMObject(EntityType.ZOMBIE, EntityType.ZOMBIE_VILLAGER, null, 0.5, true, false, false);
    }
}
