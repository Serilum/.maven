package com.natamus.collective.util;

public class CollectiveReference {
	public static final String MOD_ID = "collective";
	public static final String NAME = "Collective";
	public static final String VERSION = "8.46";
	public static final String ACCEPTED_VERSIONS = "[26.3.0]";
}
