package com.natamus.collective.functions;

import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SignFunctions {
    public static List<String> getSignText(SignBlockEntity signentity) {
        List<String> lines = new ArrayList<String>();

        for (SignText signText : Arrays.asList(signentity.getFrontText(), signentity.getBackText())) {
            for (Component line : signText.getMessages(false)) {
                if (line.equals(Component.EMPTY)) {
                    lines.add("");
                    continue;
                }

                lines.add(line.getString());
            }
        }

        return lines;
    }
}
