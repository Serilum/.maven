package com.natamus.collective.functions;

import com.natamus.collective.events.CollectiveEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;

import java.util.ArrayList;
import java.util.WeakHashMap;

public class SpawnEntityFunctions {
	public static void spawnEntityOnNextTick(ServerLevel serverlevel, Entity entity) {
		if (!CollectiveEvents.entitiesToSpawn.containsKey(serverlevel)) {
			CollectiveEvents.entitiesToSpawn.put(serverlevel, new ArrayList<Entity>());
		}
		CollectiveEvents.entitiesToSpawn.get(serverlevel).add(entity);
	}

	public static void startRidingEntityOnNextTick(ServerLevel serverlevel, Entity ridden, Entity rider) {
		if (!CollectiveEvents.entitiesToRide.containsKey(serverlevel)) {
			CollectiveEvents.entitiesToRide.put(serverlevel, new WeakHashMap<Entity, Entity>());
		}
		CollectiveEvents.entitiesToRide.get(serverlevel).put(ridden, rider);
	}
}
