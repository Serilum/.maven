package com.natamus.collective.objects;

public record Triplet<T, U, V>(T first, U second, V third) {

}
