package com.natamus.collective.fabric.services;

import com.natamus.collective_common_fabric.services.helpers.BlockTagsHelper;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags;
import net.minecraft.class_2680;

public class FabricBlockTagsHelper implements BlockTagsHelper {
    @Override
    public boolean isOre(class_2680 blockState) {
		return blockState.method_26164(ConventionalBlockTags.ORES);
    }
}
