package com.natamus.collective.fabric.mixin;

import com.natamus.collective_common_fabric.data.IEntityDataHolder;
import com.natamus.collective_common_fabric.services.helpers.EntityDataHelper;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public class CollectiveEntityMixin implements IEntityDataHolder {
    @Unique private class_2487 collective_stored = new class_2487();

    @Override
    public class_2487 collective_getStored() {
        return collective_stored;
    }

    @Override
    public void collective_setStored(class_2487 data) {
        collective_stored = data;
    }

    @Inject(method = "saveWithoutId", at = @At("TAIL"))
    private void collective_saveData(class_2487 compound, CallbackInfoReturnable<class_2487> cir) {
        if (!collective_stored.method_33133()) {
            compound.method_10566(EntityDataHelper.KEY, collective_stored);
        }
    }

    @Inject(method = "load", at = @At("TAIL"))
    private void collective_readData(class_2487 compound, CallbackInfo ci) {
        collective_stored = compound.method_10562(EntityDataHelper.KEY);
    }
}
