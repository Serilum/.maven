package com.natamus.collective.fabric.services;

import com.natamus.collective_common_fabric.data.IEntityDataHolder;
import com.natamus.collective_common_fabric.services.helpers.EntityDataHelper;
import net.minecraft.class_1297;
import net.minecraft.class_2487;

public class FabricEntityDataHelper implements EntityDataHelper {
    @Override
    public void init() {
    }

    @Override
    public class_2487 getStored(class_1297 entity) {
        return ((IEntityDataHolder) entity).collective_getStored();
    }

    @Override
    public void setStored(class_1297 entity, class_2487 data) {
        ((IEntityDataHolder) entity).collective_setStored(data);
    }
}
