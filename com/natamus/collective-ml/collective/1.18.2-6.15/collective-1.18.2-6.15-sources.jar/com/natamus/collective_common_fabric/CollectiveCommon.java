package com.natamus.collective_common_forge;

import com.natamus.collective_common_forge.config.CollectiveConfigHandler;
import com.natamus.collective_common_forge.data.GlobalVariables;
import com.natamus.collective_common_forge.util.CollectiveReference;

public class CollectiveCommon {
    public static void init() {
        System.out.println("Loading Collective version " + CollectiveReference.VERSION + ".");

        CollectiveConfigHandler.initConfig();
        GlobalVariables.generateHashMaps();
    }
}
