package com.natamus.collective.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.natamus.collective.fabric.callbacks.CollectiveRenderEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_746;
import net.minecraft.class_759;

@Mixin(value = class_759.class, priority = 1001)
public class ItemInHandRendererMixin {
	@Shadow private class_1799 mainHandItem;
	@Shadow private class_1799 offHandItem;
	
	@Inject(method = "renderHandsWithItems", at = @At(value= "INVOKE", target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderArmWithItem(Lnet/minecraft/client/player/AbstractClientPlayer;FFLnet/minecraft/world/InteractionHand;FLnet/minecraft/world/item/ItemStack;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", ordinal = 0), cancellable = true)
	public void ItemInHandRenderer_renderHandsWithItems_Main(float f, class_4587 poseStack, class_4597.class_4598 bufferSource, class_746 localPlayer, int i, CallbackInfo ci) {
		if (!CollectiveRenderEvents.RENDER_SPECIFIC_HAND.invoker().onRenderSpecificHand(class_1268.field_5808, poseStack, this.mainHandItem)) {
			bufferSource.method_22993();
			ci.cancel();
		}
	}
	
	@Inject(method = "renderHandsWithItems", at = @At(value= "INVOKE", target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderArmWithItem(Lnet/minecraft/client/player/AbstractClientPlayer;FFLnet/minecraft/world/InteractionHand;FLnet/minecraft/world/item/ItemStack;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", ordinal = 1), cancellable = true)
	public void ItemInHandRenderer_renderHandsWithItems_Offhand(float f, class_4587 poseStack, class_4597.class_4598 bufferSource, class_746 localPlayer, int i, CallbackInfo ci) {
		if (!CollectiveRenderEvents.RENDER_SPECIFIC_HAND.invoker().onRenderSpecificHand(class_1268.field_5810, poseStack, this.offHandItem)) {
			bufferSource.method_22993();
			ci.cancel();		
		}
	}
}
