package com.natamus.collective_common_forge.services.helpers;

import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;

import javax.annotation.Nullable;

public interface RegisterItemHelper {
	Item registerAndGetItem(ResourceLocation resourceLocation, Item item, @Nullable ResourceKey<CreativeModeTab> creativeModeTabResourceKey);
}