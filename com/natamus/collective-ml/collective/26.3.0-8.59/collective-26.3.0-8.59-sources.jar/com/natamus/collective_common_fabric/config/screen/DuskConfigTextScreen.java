package com.natamus.collective_common_forge.config.screen;

import com.natamus.collective_common_forge.config.DuskConfigEntry;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.MultiLineEditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class DuskConfigTextScreen extends DuskConfigBaseScreen {
	private final Screen parent;
	private final DuskConfigEntry entry;
	private List<FormattedCharSequence> descriptionLines = new ArrayList<>();
	private String text;
	private int boxX;

	public DuskConfigTextScreen(Screen parent, DuskConfigEntry entry) {
		super(Component.literal(entry.getDisplayName()));
		this.parent = parent;
		this.entry = entry;
		this.text = entry.getText();
	}

	@Override
	protected void init() {
		super.init();

		int boxWidth = Math.min(this.width - 40, 400);
		boxX = (this.width - boxWidth) / 2;

		descriptionLines = this.font.split(FormattedText.of(String.join(" ", entry.description)), boxWidth);
		int boxTop = 34 + descriptionLines.size() * 10;

		MultiLineEditBox textBox = MultiLineEditBox.builder().setX(boxX).setY(boxTop).build(this.font, boxWidth, this.height - boxTop - 40, Component.literal(entry.getDisplayName()));
		textBox.setCharacterLimit(Integer.MAX_VALUE);
		textBox.setValue(text);
		textBox.setValueListener(newText -> text = newText);
		this.addRenderableWidget(textBox);
		this.setInitialFocus(textBox);

		addCancelButton(this.width / 2 - 154, this.height - 28);
		this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, button -> {
			entry.setValue(text.replaceAll("\\R", " "));
			onClose();
		}).pos(this.width / 2 + 4, this.height - 28).size(150, 20).build());
	}

	@Override
	protected boolean hasUnsavedChanges() {
		return !text.equals(entry.getText());
	}

	@Override
	public void onClose() {
		this.minecraft.setScreenAndShow(parent);
	}

	@Override
	public void extractRenderState(@NotNull GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTick) {
		super.extractRenderState(guiGraphics, mouseX, mouseY, partialTick);

		guiGraphics.centeredText(this.font, this.title, this.width / 2, 12, 0xFFFFFFFF);

		int y = 30;
		for (FormattedCharSequence line : descriptionLines) {
			guiGraphics.text(this.font, line, boxX, y, 0xFFA0A0A0);
			y += 10;
		}
	}
}
