package com.natamus.collective.fabric.mixin;

import com.natamus.collective_common_fabric.data.IEntityDataHolder;
import com.natamus.collective_common_fabric.services.helpers.EntityDataHelper;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_1297.class, priority = 1001)
public class EntityMixin implements IEntityDataHolder {
	@Unique private class_2487 collective_stored = new class_2487();

	@Override
	public class_2487 collective_getStored() {
		return collective_stored;
	}

	@Override
	public void collective_setStored(class_2487 data) {
		collective_stored = data;
	}

	@Inject(method = "saveWithoutId(Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag;", at = @At(value = "TAIL"))
	public void Entity_saveWithoutId(class_2487 compound, CallbackInfoReturnable<class_2487> cir) {
		if (!collective_stored.method_33133()) {
			compound.method_10566(EntityDataHelper.KEY, collective_stored);
		}
	}

	@Inject(method = "load(Lnet/minecraft/nbt/CompoundTag;)V", at = @At(value = "TAIL"))
	public void Entity_load(class_2487 compound, CallbackInfo ci) {
		collective_stored = compound.method_10562(EntityDataHelper.KEY);
	}
}
