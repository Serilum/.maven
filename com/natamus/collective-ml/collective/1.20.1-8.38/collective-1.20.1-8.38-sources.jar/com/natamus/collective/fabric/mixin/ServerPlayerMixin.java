package com.natamus.collective.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.natamus.collective_common_fabric.data.IEntityDataHolder;
import net.minecraft.class_1282;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import com.natamus.collective.fabric.callbacks.CollectiveItemEvents;
import com.natamus.collective.fabric.callbacks.CollectivePlayerEvents;

@Mixin(value = class_3222.class, priority = 1001)
public class ServerPlayerMixin {
	@Inject(method = "tick()V", at = @At(value = "HEAD"))
	public void ServerPlayer_tick(CallbackInfo ci) {
		class_3222 player = (class_3222)(Object)this;
		class_3218 world = (class_3218)player.method_5770();
		
		CollectivePlayerEvents.PLAYER_TICK.invoker().onTick(world, player);
	}
	
	@Inject(method = "die(Lnet/minecraft/world/damagesource/DamageSource;)V", at = @At(value = "HEAD"))
	public void ServerPlayer_die(class_1282 damageSource, CallbackInfo ci) {
		class_3222 player = (class_3222)(Object)this;
		class_3218 world = (class_3218)player.method_5770();
		
		CollectivePlayerEvents.PLAYER_DEATH.invoker().onDeath(world, player);
	}
	
	@Inject(method = "changeDimension(Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/world/entity/Entity;", at = @At(value = "RETURN"))
	public void ServerPlayer_changeDimension(class_3218 serverLevel, CallbackInfoReturnable<Boolean> ci) {
		class_3222 player = (class_3222)(Object)this;
		
		CollectivePlayerEvents.PLAYER_CHANGE_DIMENSION.invoker().onChangeDimension(serverLevel, player);
	}
	
	@Inject(method = "drop(Lnet/minecraft/world/item/ItemStack;ZZ)Lnet/minecraft/world/entity/item/ItemEntity;", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;addFreshEntity(Lnet/minecraft/world/entity/Entity;)Z"))
	private void ServerPlayer_drop(class_1799 itemStack, boolean bl, boolean bl2, CallbackInfoReturnable<class_1542> ci) {
		class_1657 player = (class_1657)(Object)this;
		CollectiveItemEvents.ON_ITEM_TOSSED.invoker().onItemTossed(player, itemStack);
	}

	@Inject(method = "restoreFrom(Lnet/minecraft/server/level/ServerPlayer;Z)V", at = @At(value = "TAIL"))
	public void ServerPlayer_restoreFrom(class_3222 oldPlayer, boolean restoreAll, CallbackInfo ci) {
		class_2487 stored = ((IEntityDataHolder)oldPlayer).collective_getStored();
		((IEntityDataHolder)this).collective_setStored(stored);
	}
}
