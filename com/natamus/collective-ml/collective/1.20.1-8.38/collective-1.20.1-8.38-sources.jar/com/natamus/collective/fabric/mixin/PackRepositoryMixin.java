package com.natamus.collective.fabric.mixin;

import com.natamus.collective_common_fabric.translations.TranslationPack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_3283;
import net.minecraft.class_3285;

@Mixin(value = class_3283.class, priority = 1001)
public class PackRepositoryMixin {
	@Shadow @Final @Mutable private Set<class_3285> sources;

	@Inject(method = "<init>", at = @At("TAIL"))
	private void collective$addTranslationPack(class_3285[] sources, CallbackInfo ci) {
		Set<class_3285> updated = new HashSet<>(this.sources);
		updated.add(TranslationPack::contribute);
		this.sources = updated;
	}
}
