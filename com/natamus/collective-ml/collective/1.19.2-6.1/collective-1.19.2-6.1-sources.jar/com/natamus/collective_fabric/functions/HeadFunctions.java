package com.natamus.collective_forge.functions;

import com.natamus.collective_forge.data.GlobalVariables;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.Base64;
import java.util.List;
import java.util.UUID;

public class HeadFunctions {
	public static ItemStack getPlayerHead(String playername, Integer amount) {
		// Head Data
		String data1 = DataFunctions.readStringFromURL(GlobalVariables.playerdataurl + playername.toLowerCase());
		if (data1.equals("")) {
			return null;
		}

		try {
			String[] sdata1 = data1.split("\":\"");
			String pname = sdata1[1].split("\"")[0];
			String pid = sdata1[2].split("\"")[0];

			String data2 = DataFunctions.readStringFromURL(GlobalVariables.skindataurl + pid);
			if (data2.equals("")) {
				return null;
			}

			String[] sdata2 = data2.replaceAll(" ", "").split("value\":\"");

			String tvalue = sdata2[1].split("\"")[0];
			String d = new String(Base64.getDecoder().decode((tvalue.getBytes())));

			String texture = Base64.getEncoder().encodeToString((("{\"textures\"" + d.split("\"textures\"")[1]).getBytes()));
			String oldid = new UUID(texture.hashCode(), texture.hashCode()).toString();

			return getTexturedHead(pname + "'s Head", texture, oldid, 1);
		}
		catch (ArrayIndexOutOfBoundsException ignored) { }

		return null;
	}
	
	public static ItemStack getTexturedHead(String headname, String texture, String oldid, Integer amount) {
		ItemStack texturedhead = new ItemStack(Items.PLAYER_HEAD, amount);
		
		List<Integer> intarray = UUIDFunctions.oldIdToIntArray(oldid);
		
		CompoundTag skullOwner = new CompoundTag();
		skullOwner.putIntArray("Id", intarray);
		
		CompoundTag properties = new CompoundTag();
		ListTag textures = new ListTag();
		CompoundTag tex = new CompoundTag();
		tex.putString("Value", texture);
		textures.add(tex);

		properties.put("textures", textures);
		skullOwner.put("Properties", properties);
		texturedhead.addTagElement("SkullOwner", skullOwner);
		
		Component tcname = Component.literal(headname);
		texturedhead.setHoverName(tcname);		
		return texturedhead;
	}
	
	public static boolean hasStandardHead(String mobname) {
        return mobname.equals("creeper") || mobname.equals("zombie") || mobname.equals("skeleton");
    }
}
