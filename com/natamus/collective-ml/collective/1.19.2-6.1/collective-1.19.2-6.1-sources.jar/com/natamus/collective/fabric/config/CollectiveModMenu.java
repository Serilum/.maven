package com.natamus.collective.fabric.config;

import com.natamus.collective_fabric.config.DuskConfig;
import com.natamus.collective_fabric.util.CollectiveReference;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

public class CollectiveModMenu implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> DuskConfig.DuskConfigScreen.getScreen(parent, CollectiveReference.MOD_ID);
    }
}