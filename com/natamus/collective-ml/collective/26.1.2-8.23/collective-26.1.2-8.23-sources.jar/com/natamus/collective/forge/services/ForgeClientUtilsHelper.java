package com.natamus.collective.forge.services;

import com.natamus.collective_common_forge.services.helpers.ClientUtilsHelper;

public class ForgeClientUtilsHelper implements ClientUtilsHelper {

}