package com.natamus.collective.neoforge.services;

import com.natamus.collective_common_neoforge.services.helpers.ClientUtilsHelper;

public class NeoForgeClientUtilsHelper implements ClientUtilsHelper {

}