package com.natamus.collective_common_neoforge.services.helpers;

public interface ClientUtilsHelper {
}