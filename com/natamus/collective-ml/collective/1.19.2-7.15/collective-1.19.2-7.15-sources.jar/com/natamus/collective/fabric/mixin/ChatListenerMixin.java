package com.natamus.collective.fabric.mixin;

import com.natamus.collective.fabric.callbacks.CollectiveChatEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.time.Instant;
import net.minecraft.class_2556;
import net.minecraft.class_2561;
import net.minecraft.class_640;
import net.minecraft.class_7471;
import net.minecraft.class_7594;

@Mixin(value = class_7594.class, priority = 1001)
public abstract class ChatListenerMixin {
    @Unique class_2556.class_7602 collective$bound;
    @Unique class_640 collective$playerInfo;

    @Inject(method = "showMessageToPlayer", at = @At("HEAD"))
    public void captureParams(class_2556.class_7602 bound, class_7471 playerChatMessage, class_2561 component, class_640 playerInfo, boolean bl, Instant instant, CallbackInfoReturnable<Boolean> cir) {
        collective$bound = bound;
        collective$playerInfo = playerInfo;
    }

    @ModifyVariable(method = "showMessageToPlayer", at = @At("HEAD"), argsOnly = true)
    public class_2561 modifyMessage(class_2561 component) {
        try {
            return CollectiveChatEvents.CLIENT_CHAT_RECEIVED.invoker().onClientChat(collective$bound.comp_919(), component, (collective$playerInfo != null ? collective$playerInfo.method_2966().getId() : null));
        } finally {
            collective$bound = null;
            collective$playerInfo = null;
        }
    }
}