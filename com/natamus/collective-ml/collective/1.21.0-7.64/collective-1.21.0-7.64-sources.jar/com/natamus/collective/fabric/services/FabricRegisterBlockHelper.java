package com.natamus.collective.fabric.services;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective_common_fabric.services.Services;
import com.natamus.collective_common_fabric.services.helpers.RegisterBlockHelper;
import javax.annotation.Nullable;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import java.util.function.Supplier;

public class FabricRegisterBlockHelper implements RegisterBlockHelper {
    @Override
	public <T extends class_2248> Pair<class_2248, class_1747> registerAndGetBlockPair(class_2960 resourceLocation, Supplier<T> blockSupplier, @Nullable class_5321<class_1761> creativeModeTabResourceKey) {
		class_2248 block = blockSupplier.get();

		class_2378.method_10230(class_7923.field_41175, resourceLocation, block);

		class_1792 item = Services.REGISTERITEM.registerAndGetItem(resourceLocation, () -> new class_1747(block, new class_1792.class_1793()), creativeModeTabResourceKey);

		return Pair.of(block, (class_1747)item);
    }
}