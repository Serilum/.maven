package com.natamus.collective_common_forge.services.helpers;

import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;

import javax.annotation.Nullable;
import java.util.function.Supplier;

public interface RegisterItemHelper {
	<T extends Item> Item registerAndGetItem(ResourceLocation resourceLocation, Supplier<T> itemSupplier, @Nullable ResourceKey<CreativeModeTab> creativeModeTabResourceKey);
}