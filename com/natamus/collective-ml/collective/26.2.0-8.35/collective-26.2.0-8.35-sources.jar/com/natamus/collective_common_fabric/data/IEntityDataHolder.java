package com.natamus.collective_common_forge.data;

import net.minecraft.nbt.CompoundTag;

public interface IEntityDataHolder {
    CompoundTag collective_getStored();

    void collective_setStored(CompoundTag data);
}
