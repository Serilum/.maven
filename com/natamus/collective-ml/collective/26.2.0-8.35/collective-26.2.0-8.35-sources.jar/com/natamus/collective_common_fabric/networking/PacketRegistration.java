package com.natamus.collective_common_forge.networking;

import com.natamus.collective_common_forge.implementations.networking.api.Network;
import com.natamus.collective_common_forge.networking.packets.*;

public class PacketRegistration {

    public void init() {
        initClientPackets();
    }

    private void initClientPackets() {
        Network.registerPacket(CollectiveInstalledPacket.CHANNEL, CollectiveInstalledPacket.class, CollectiveInstalledPacket::encode, CollectiveInstalledPacket::decode, CollectiveInstalledPacket::handle);
        Network.registerPacket(EntityDataSyncPacket.CHANNEL, EntityDataSyncPacket.class, EntityDataSyncPacket::encode, EntityDataSyncPacket::decode, EntityDataSyncPacket::handle);
    }
}
