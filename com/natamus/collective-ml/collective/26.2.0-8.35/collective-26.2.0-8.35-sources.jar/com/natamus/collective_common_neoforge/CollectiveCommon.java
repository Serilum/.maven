package com.natamus.collective_common_neoforge;

import com.natamus.collective_common_neoforge.config.CollectiveConfigHandler;
import com.natamus.collective_common_neoforge.config.LoadJSONFiles;
import com.natamus.collective_common_neoforge.data.Constants;
import com.natamus.collective_common_neoforge.data.GlobalVariables;
import com.natamus.collective_common_neoforge.networking.PacketRegistration;
import com.natamus.collective_common_neoforge.services.Services;
import com.natamus.collective_common_neoforge.util.CollectiveReference;

public class CollectiveCommon {
    public static void init() {
        Constants.LOG.info("Loading Collective version " + CollectiveReference.VERSION + ".");

        CollectiveConfigHandler.initConfig();
        GlobalVariables.generateHashMaps();
		LoadJSONFiles.startListening();

		registerPackets();
		loadEvents();
    }

	public static void registerPackets() {
		new PacketRegistration().init();
	}

	public static void loadEvents() {
		Services.ENTITYDATA.init();
	}
}
