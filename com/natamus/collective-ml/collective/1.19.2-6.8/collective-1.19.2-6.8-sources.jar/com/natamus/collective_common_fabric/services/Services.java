package com.natamus.collective_common_forge.services;

import com.natamus.collective_common_forge.services.helpers.ModLoaderHelper;
import com.natamus.collective_common_forge.services.helpers.ToolFunctionsHelper;

import java.util.ServiceLoader;

public class Services {
    public static final ModLoaderHelper MODLOADER = load(ModLoaderHelper.class);
    public static final ToolFunctionsHelper TOOLFUNCTIONS = load(ToolFunctionsHelper.class);

    public static <T> T load(Class<T> clazz) {
        return ServiceLoader.load(clazz).findFirst().orElseThrow(() -> new NullPointerException("[Collective] Failed to load service for " + clazz.getName() + "."));
    }
}