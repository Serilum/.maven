package com.natamus.collective_common_forge.util;

public class CollectiveReference {
	public static final String MOD_ID = "collective";
	public static final String NAME = "Collective";
	public static final String VERSION = "7.8";
	public static final String ACCEPTED_VERSIONS = "[1.19.2]";
}
