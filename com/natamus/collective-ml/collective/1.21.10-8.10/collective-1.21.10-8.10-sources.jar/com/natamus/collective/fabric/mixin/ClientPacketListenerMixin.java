package com.natamus.collective.fabric.mixin;

import com.google.common.hash.HashCode;
import net.minecraft.class_634;
import net.minecraft.class_6903;
import net.minecraft.class_9336;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_634.class, priority = 1001)
public class ClientPacketListenerMixin {
	@Inject(method = "method_68824", at = @At(value = "HEAD"), cancellable = true)
    private static void decoratedHashOpsGenerator(class_6903<?> registryOps, class_9336<?> typedDataComponent, CallbackInfoReturnable<Integer> cir) {
		try {
			HashCode hashCode = (HashCode) typedDataComponent.method_57943(registryOps).getOrThrow((string) -> {
				return new IllegalArgumentException();
			});
		}
		catch (IllegalArgumentException ex) {
			cir.setReturnValue(-1);
		}
	}
}