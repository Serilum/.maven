package com.natamus.collective_common_neoforge.check;

import com.natamus.collective_common_neoforge.config.DuskConfigMod;
import com.natamus.collective_common_neoforge.config.DuskConfigModToggles;
import com.natamus.collective_common_neoforge.functions.ConfigFunctions;
import com.natamus.collective_common_neoforge.services.Services;

public class ShouldLoadCheck {
	public static boolean shouldLoad(String modId) {
		if (Services.MODLOADER.isJarJard(modId) && !Services.MODLOADER.isBundleModEnabled(modId)) {
			return false;
		}

		DuskConfigModToggles.addKnownMod(modId);
		Services.MODLOADER.registerConfigScreen(modId);

		if (!ConfigFunctions.isModEnabled(modId)) {
			DuskConfigMod.addDisabledMod(modId);
			return false;
		}
		return true;
	}
}
