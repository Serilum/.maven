package com.natamus.collective_common_neoforge.services.helpers;

public interface ModLoaderHelper {
    String getModLoaderName();
    String getGameDirectory();
    boolean isModLoaded(String modId);
    boolean isDevelopmentEnvironment();
    boolean isClientSide();
}