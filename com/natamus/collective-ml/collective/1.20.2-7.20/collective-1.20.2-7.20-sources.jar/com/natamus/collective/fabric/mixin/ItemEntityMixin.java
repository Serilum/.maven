package com.natamus.collective.fabric.mixin;

import com.natamus.collective.fabric.callbacks.CollectiveItemEvents;
import com.natamus.collective.fabric.callbacks.CollectivePlayerEvents;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_1542.class, priority = 1001)
public abstract class ItemEntityMixin {
	@Unique private class_1799 copyStack = null;

	@Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/item/ItemEntity;discard()V", ordinal = 1))
	public void ItemEntity_tick(CallbackInfo ci) {
		class_1542 itemEntity = (class_1542)(Object)this;
		class_1799 itemStack = itemEntity.method_6983();
		CollectiveItemEvents.ON_ITEM_EXPIRE.invoker().onItemExpire(itemEntity, itemStack);
	}

	@Inject(method = "playerTouch(Lnet/minecraft/world/entity/player/Player;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getCount()I"))
	public void ItemEntity_playerTouch_Pre(class_1657 player, CallbackInfo ci) {
		copyStack = ((class_1542)(Object)this).method_6983().method_7972();
	}

	@Inject(method = "playerTouch(Lnet/minecraft/world/entity/player/Player;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;take(Lnet/minecraft/world/entity/Entity;I)V"))
	public void ItemEntity_playerTouch_Post(class_1657 player, CallbackInfo ci) {
		CollectivePlayerEvents.ON_ITEM_PICKED_UP.invoker().onItemPickedUp(player.method_37908(), player, copyStack);
	}
}
