package com.natamus.collective.fabric.services;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective_common_fabric.services.helpers.RegisterBlockHelper;
import javax.annotation.Nullable;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.function.Supplier;

public class FabricRegisterBlockHelper implements RegisterBlockHelper {
	private static final HashMap<class_2960, class_2248> registeredBlocks = new HashMap<>();
	private static final HashMap<class_2960, Pair<class_2248, class_1792>> registeredBlockPairs = new HashMap<>();

    @Override
	public <T extends class_2248> void registerBlock(Object modEventBusObject, class_2960 resourceLocation, Supplier<T> blockSupplier, boolean lastBlock) {
		staticRegisterBlock(modEventBusObject, resourceLocation, blockSupplier, null, lastBlock, false);
    }

	@Override
	public class_2248 getRegisteredBlock(class_2960 resourceLocation) {
		return registeredBlocks.get(resourceLocation);
	}

    @Override
	public <T extends class_2248> void registerBlockItem(Object modEventBusObject, class_2960 resourceLocation, Supplier<T> blockSupplier, @Nullable class_5321<class_1761> creativeModeTabResourceKey, boolean lastBlock) {
		staticRegisterBlock(modEventBusObject, resourceLocation, blockSupplier, creativeModeTabResourceKey, lastBlock, true);
    }

	@Override
	public Pair<class_2248, class_1747> getRegisteredBlockItemPair(class_2960 resourceLocation) {
		Pair<class_2248, class_1792> registeredPair = registeredBlockPairs.get(resourceLocation);
		return Pair.of(registeredPair.getFirst(), (class_1747)registeredPair.getSecond());
	}

	@Override
	public void setRegisteredBlockItemPair(class_2960 resourceLocation, Class<?> blockClass, String blockFieldName, Class<?> blockItemClass, String blockItemFieldName) {
		Pair<class_2248, class_1792> registeredPair = registeredBlockPairs.get(resourceLocation);

        try {
            Field blockField = blockClass.getDeclaredField(blockFieldName);
            blockField.setAccessible(true);
            blockField.set(null, registeredPair.getFirst());

            Field blockItemField = blockItemClass.getDeclaredField(blockItemFieldName);
            blockItemField.setAccessible(true);
            blockItemField.set(null, registeredPair.getSecond());
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
	}

	public static <T extends class_2248> void staticRegisterBlock(Object modEventBusObject, class_2960 resourceLocation, Supplier<T> blockSupplier, @Nullable class_5321<class_1761> creativeModeTabResourceKey, boolean lastBlock, boolean registerAsItem) {
		class_2248 block = blockSupplier.get();

		class_2378.method_10230(class_7923.field_41175, resourceLocation, block);

		if (registerAsItem) {
			class_1792 item = FabricRegisterItemHelper.staticRegisterItem(modEventBusObject, resourceLocation, () -> new class_1747(block, new class_1792.class_1793()), creativeModeTabResourceKey);

			registeredBlockPairs.put(resourceLocation, Pair.of(block, item));
		}
		else {
			registeredBlocks.put(resourceLocation, block);
		}
	}
}