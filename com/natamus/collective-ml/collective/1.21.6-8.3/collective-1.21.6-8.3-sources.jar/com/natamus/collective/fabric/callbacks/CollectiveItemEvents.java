package com.natamus.collective.fabric.callbacks;

import com.natamus.collective_common_fabric.implementations.event.Event;
import com.natamus.collective_common_fabric.implementations.event.EventFactory;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1536;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

public class CollectiveItemEvents {
	private CollectiveItemEvents() { }
	 
    public static final Event<Item_Expire> ON_ITEM_EXPIRE = EventFactory.createArrayBacked(Item_Expire.class, callbacks -> (itemEntity, itemStack) -> {
        for (Item_Expire callback : callbacks) {
        	callback.onItemExpire(itemEntity, itemStack);
        }
    });
    
    public static final Event<Item_Fished> ON_ITEM_FISHED = EventFactory.createArrayBacked(Item_Fished.class, callbacks -> (loot, hook) -> {
        for (Item_Fished callback : callbacks) {
        	callback.onItemFished(loot, hook);
        }
    });
    
    public static final Event<Item_Tossed> ON_ITEM_TOSSED = EventFactory.createArrayBacked(Item_Tossed.class, callbacks -> (player, itemStack) -> {
        for (Item_Tossed callback : callbacks) {
        	callback.onItemTossed(player, itemStack);
        }
    });

	public static final Event<Item_Destroyed> ON_ITEM_DESTROYED = EventFactory.createArrayBacked(Item_Destroyed.class, callbacks -> (player, itemStack, hand) -> {
		for (Item_Destroyed callback : callbacks) {
			callback.onItemDestroyed(player, itemStack, hand);
		}
	});

	public static final Event<Item_Use_Finished> ON_ITEM_USE_FINISHED = EventFactory.createArrayBacked(Item_Use_Finished.class, callbacks -> (player, usedItem, newItem, hand) -> {
		for (Item_Use_Finished callback : callbacks) {
			class_1799 changedStack = callback.onItemUsedFinished(player, usedItem, newItem, hand);
			if (changedStack != null) {
				return changedStack;
			}
		}
		return null;
	});
    
	@FunctionalInterface
	public interface Item_Expire {
		 void onItemExpire(class_1542 itemEntity, class_1799 itemStack);
	}
	
	@FunctionalInterface
	public interface Item_Fished {
		 void onItemFished(List<class_1799> loot, class_1536 hook);
	}
	
	@FunctionalInterface
	public interface Item_Tossed {
		 void onItemTossed(class_1657 player, class_1799 itemStack);
	}

	@FunctionalInterface
	public interface Item_Destroyed {
		void onItemDestroyed(class_1657 player, class_1799 stack, class_1268 hand);
	}

	@FunctionalInterface
	public interface Item_Use_Finished {
		class_1799 onItemUsedFinished(class_1657 player, class_1799 usedItem, class_1799 newItem, class_1268 hand);
	}
}
