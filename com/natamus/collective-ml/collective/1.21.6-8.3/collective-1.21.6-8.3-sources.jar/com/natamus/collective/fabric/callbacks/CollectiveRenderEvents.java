package com.natamus.collective.fabric.callbacks;

import com.natamus.collective_common_fabric.implementations.event.Event;
import com.natamus.collective_common_fabric.implementations.event.EventFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_4587;

public class CollectiveRenderEvents {
	private CollectiveRenderEvents() { }

	public static final Event<Render_Specific_Hand> RENDER_SPECIFIC_HAND = EventFactory.createArrayBacked(Render_Specific_Hand.class, callbacks -> (interactionHand, poseStack, itemStack) -> {
		for (Render_Specific_Hand callback : callbacks) {
			if (!callback.onRenderSpecificHand(interactionHand, poseStack, itemStack)) {
				return false;
			}
		}

		return true;
	});

	@FunctionalInterface
	public interface Render_Specific_Hand {
		boolean onRenderSpecificHand(class_1268 interactionHand, class_4587 poseStack, class_1799 itemStack);
	}
}
