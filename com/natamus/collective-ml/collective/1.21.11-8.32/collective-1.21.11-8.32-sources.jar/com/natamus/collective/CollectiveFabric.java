package com.natamus.collective;

import com.natamus.collective_common_fabric.CollectiveCommon;

import com.natamus.collective_common_fabric.check.RegisterMod;
import com.natamus.collective_common_fabric.cmds.CommandCollective;
import com.natamus.collective_common_fabric.config.GenerateJSONFiles;
import com.natamus.collective_common_fabric.events.CollectiveEvents;
import com.natamus.collective.fabric.callbacks.CollectivePlayerEvents;
import com.natamus.collective.fabric.networking.FabricNetworkHandler;
import com.natamus.collective_common_fabric.implementations.networking.NetworkSetup;
import com.natamus.collective_common_fabric.implementations.networking.data.Side;
import com.natamus.collective_common_fabric.translations.ServerTranslationPack;
import com.natamus.collective_common_fabric.util.CollectiveReference;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public class CollectiveFabric implements ModInitializer { 
	@Override
	public void onInitialize() {
		new NetworkSetup(new FabricNetworkHandler(Side.SERVER));

		setGlobalConstants();
		CollectiveCommon.init();

		ServerLifecycleEvents.SERVER_STARTING.register((minecraftServer) -> {
			GenerateJSONFiles.initGeneration(minecraftServer);
			ServerTranslationPack.onServerStarting(minecraftServer);
		});

		ServerWorldEvents.LOAD.register((MinecraftServer server, class_3218 level) -> {
			CollectiveEvents.onWorldLoad(level);
		});

		ServerTickEvents.START_WORLD_TICK.register((serverLevel) -> {
			CollectiveEvents.onWorldTick(serverLevel);
		});

		ServerTickEvents.START_SERVER_TICK.register((minecraftServer) -> {
			CollectiveEvents.onServerTick(minecraftServer);
		});
		
		ServerEntityEvents.ENTITY_LOAD.register((entity, serverLevel) -> {
			CollectiveEvents.onEntityJoinLevel(serverLevel, entity);
		});

		CollectivePlayerEvents.PLAYER_LOGGED_IN.register((world, player) -> {
			if (player instanceof class_3222 serverPlayer) {
				ServerTranslationPack.onPlayerJoin(serverPlayer);
			}
		});

		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			CommandCollective.register(dispatcher);
		});

		RegisterMod.register(CollectiveReference.NAME, CollectiveReference.MOD_ID, CollectiveReference.VERSION, CollectiveReference.ACCEPTED_VERSIONS);
	}

	private static void setGlobalConstants() {

	}
}
