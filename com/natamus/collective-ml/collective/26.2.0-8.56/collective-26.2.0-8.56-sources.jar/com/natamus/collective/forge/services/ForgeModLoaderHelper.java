package com.natamus.collective.forge.services;

import com.natamus.collective.forge.bundle.ForgeBundleConfigCheck;
import com.natamus.collective.forge.bundle.ForgeBundleJarJarCheck;
import com.natamus.collective.forge.config.ForgeCollectiveConfigScreen;
import com.natamus.collective_common_forge.services.helpers.ModLoaderHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.fml.loading.FMLLoader;
import net.minecraftforge.fml.loading.FMLPaths;

public class ForgeModLoaderHelper implements ModLoaderHelper {
	@Override
	public String getModLoaderName() {
		return "Forge";
	}

	@Override
	public String getGameDirectory() {
		return FMLPaths.GAMEDIR.get().toString();
	}

	@Override
	public boolean isModLoaded(String modId) {
		return ModList.isLoaded(modId);
	}

	@Override
	public boolean isDevelopmentEnvironment() {
		return !FMLLoader.isProduction();
	}

	@Override
	public boolean isClientSide() {
		return FMLEnvironment.dist.equals(Dist.CLIENT);
	}

	@Override
	public boolean isJarJard(String modId) {
		return ForgeBundleJarJarCheck.isModJarJard(modId);
	}

	@Override
	public boolean isBundleModEnabled(String modId) {
		return ForgeBundleConfigCheck.isBundleModEnabled(modId);
	}

	@Override
	public void registerConfigScreen(String modId) {
		ModLoadingContext modLoadingContext = ModLoadingContext.get();
		if (modId.equals(modLoadingContext.getActiveNamespace())) {
			ForgeCollectiveConfigScreen.registerScreen(modLoadingContext, modId);
		}
	}
}