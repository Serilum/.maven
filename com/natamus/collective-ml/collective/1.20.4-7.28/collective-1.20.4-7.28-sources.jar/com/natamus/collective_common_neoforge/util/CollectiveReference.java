package com.natamus.collective_common_neoforge.util;

public class CollectiveReference {
	public static final String MOD_ID = "collective";
	public static final String NAME = "Collective";
	public static final String VERSION = "7.28";
	public static final String ACCEPTED_VERSIONS = "[1.20.4]";
}
