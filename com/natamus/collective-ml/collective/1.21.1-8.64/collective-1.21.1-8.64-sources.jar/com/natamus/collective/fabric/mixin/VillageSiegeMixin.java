package com.natamus.collective.fabric.mixin;

import com.natamus.collective_common_fabric.events.CollectiveSpawnCheckEvents;
import net.minecraft.class_1419;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value = class_1419.class, priority = 1001)
public class VillageSiegeMixin {
	@ModifyVariable(method = "trySpawn(Lnet/minecraft/server/level/ServerLevel;)V", at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/world/entity/ai/village/VillageSiege;findRandomSpawnPos(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/phys/Vec3;"))
	private class_243 trySpawn_spawnPos(class_243 spawnPos, class_3218 serverLevel) {
		if (spawnPos == null) {
			return null;
		}

		if (!CollectiveSpawnCheckEvents.onSiegeZombieSpawn(serverLevel, spawnPos)) {
			return null;
		}
		return spawnPos;
	}
}
