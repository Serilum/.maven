package com.natamus.collective.fabric.mixin;

import com.mojang.authlib.GameProfile;
import com.natamus.collective.fabric.callbacks.CollectiveChatEvents;
import net.minecraft.class_156;
import net.minecraft.class_2556;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_7469;
import net.minecraft.class_7471;
import net.minecraft.class_7591;
import net.minecraft.class_7594;
import net.minecraft.class_7595;
import net.minecraft.class_7649;
import net.minecraft.network.chat.*;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.time.Instant;

@Mixin(value = class_7594.class, priority = 1001)
public abstract class ChatListenerMixin {
    @Shadow private @Final class_310 minecraft;
    @Shadow private long previousMessageTime;
    @Shadow protected abstract void narrateChatMessage(class_2556.class_7602 bound, class_2561 component);
    @Shadow protected abstract void logPlayerMessage(class_7471 playerChatMessage, class_2556.class_7602 bound, GameProfile gameProfile, class_7595 chatTrustLevel);
    @Shadow protected abstract boolean showMessageToPlayer(class_2556.class_7602 bound, class_7471 playerChatMessage, class_2561 component, GameProfile gameProfile, boolean bl, Instant instant);

    @Inject(method = "showMessageToPlayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;getChat()Lnet/minecraft/client/gui/components/ChatComponent;"), cancellable = true, locals = LocalCapture.CAPTURE_FAILSOFT)
    public void showMessageToPlayer(class_2556.class_7602 bound, class_7471 playerChatMessage, class_2561 component, GameProfile gameProfile, boolean bl, Instant instant, CallbackInfoReturnable<Boolean> cir, class_7595 chatTrustLevel, class_7591 guiMessageTag, class_7469 messageSignature, class_7649 filterMask) {
        class_2561 newMessage = CollectiveChatEvents.CLIENT_CHAT_RECEIVED.invoker().onClientChat(bound.comp_919(), component, (gameProfile != null ? gameProfile.getId() : null));
		if (component != newMessage) {
            this.minecraft.field_1705.method_1743().method_44811(newMessage, messageSignature, guiMessageTag);
            this.narrateChatMessage(bound, playerChatMessage.method_46291());
            this.logPlayerMessage(playerChatMessage, bound, gameProfile, chatTrustLevel);
            this.previousMessageTime = class_156.method_658();
            cir.setReturnValue(true);
		}
    }
}
