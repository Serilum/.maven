package com.natamus.collective.fabric.services;

import com.natamus.collective_common_fabric.data.IEntityDataHolder;
import com.natamus.collective_common_fabric.services.helpers.EntityDataHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;

public class FabricEntityDataHelper implements EntityDataHelper {
    @Override
    public void init() {
    }

    @Override
    public CompoundTag getStored(Entity entity) {
        return ((IEntityDataHolder) entity).collective_getStored();
    }

    @Override
    public void setStored(Entity entity, CompoundTag data) {
        ((IEntityDataHolder) entity).collective_setStored(data);
    }
}
