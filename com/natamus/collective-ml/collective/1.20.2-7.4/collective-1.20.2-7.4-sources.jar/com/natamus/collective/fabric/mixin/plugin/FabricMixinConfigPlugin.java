package com.natamus.collective.fabric.mixin.plugin;

import com.natamus.collective_common_fabric.services.Services;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import java.util.List;
import java.util.Set;

public class FabricMixinConfigPlugin implements IMixinConfigPlugin {
    @Override
    public void onLoad(String mixinPackage) {

    }

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        return !(mixinClassName.contains(".neoforge.") && !Services.MODLOADER.getModLoaderName().equals("NeoForge") ||
                mixinClassName.contains(".forge.") && !Services.MODLOADER.getModLoaderName().equals("Forge") ||
                mixinClassName.contains(".fabric.") && !Services.MODLOADER.getModLoaderName().equals("Fabric"));
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {

    }

    @Override
    public List<String> getMixins() {
        return null;
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {

    }

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {

    }
}