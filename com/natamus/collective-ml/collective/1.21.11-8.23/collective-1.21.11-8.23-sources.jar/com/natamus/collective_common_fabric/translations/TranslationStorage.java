package com.natamus.collective_common_forge.translations;

import java.util.Map;

public interface TranslationStorage {
	void collective$mergeTranslations(Map<String, String> translations);
}
