package com.natamus.collective.fabric.services;

import com.natamus.collective_common_fabric.data.ClientConstants;
import com.natamus.collective_common_fabric.services.helpers.RegisterKeyMappingHelper;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import org.jetbrains.annotations.Nullable;

public class FabricRegisterKeyMappingHelper implements RegisterKeyMappingHelper {
	public @Nullable class_304 registerKeyMapping(String description, int key, String category) {
		if (!ClientConstants.keyMappingCategories.containsKey(category)) {
			return null;
		}

		return registerKeyMapping(description, key, ClientConstants.keyMappingCategories.get(category));
	}
	public class_304 registerKeyMapping(String description, int key, class_304.class_11900 keyMappingCategory) {
		return KeyBindingHelper.registerKeyBinding(new class_304(description, key, keyMappingCategory));
	}
}