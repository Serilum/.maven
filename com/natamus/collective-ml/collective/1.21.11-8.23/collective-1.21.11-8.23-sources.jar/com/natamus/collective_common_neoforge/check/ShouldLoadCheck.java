package com.natamus.collective_common_neoforge.check;

import com.natamus.collective_common_neoforge.services.Services;

public class ShouldLoadCheck {
	public static boolean shouldLoad(String modId) {
		if (Services.MODLOADER.isJarJard(modId)) {
			return Services.MODLOADER.isBundleModEnabled(modId);
		}
		return true;
	}
}
