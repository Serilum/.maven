package com.natamus.collective_common_forge.check;

import com.natamus.collective_common_forge.services.Services;

public class ShouldLoadCheck {
	public static boolean shouldLoad(String modId) {
		if (Services.MODLOADER.isJarJard(modId)) {
			return Services.MODLOADER.isBundleModEnabled(modId);
		}
		return true;
	}
}
