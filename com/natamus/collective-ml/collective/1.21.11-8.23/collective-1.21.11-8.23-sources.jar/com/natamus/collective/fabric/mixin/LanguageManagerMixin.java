package com.natamus.collective.fabric.mixin;

import com.natamus.collective_common_fabric.translations.TranslationLoader;
import net.minecraft.class_1076;
import net.minecraft.class_3300;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_1076.class, priority = 1001)
public abstract class LanguageManagerMixin {
	@Shadow public abstract String getSelected();

	@Inject(method = "onResourceManagerReload", at = @At("TAIL"))
	private void collective$onLanguageReload(class_3300 resourceManager, CallbackInfo ci) {
		TranslationLoader.onLanguageChanged(this.getSelected());
	}
}
