package com.natamus.collective.fabric.mixin;

import com.natamus.collective.fabric.callbacks.CollectiveSpawnEvents;
import com.natamus.collective_common_fabric.util.CollectiveReference;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Optional;
import net.minecraft.class_11368;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1917;
import net.minecraft.class_1937;
import net.minecraft.class_1952;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_5819;
import net.minecraft.class_8942;

@Mixin(value = class_1917.class, priority = 1001)
public abstract class BaseSpawnerMixin {
	@Shadow protected abstract void delay(class_1937 level, class_2338 blockPos);
	
	@Inject(method = "serverTick(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;)V", at = @At(value= "INVOKE", target = "Lnet/minecraft/world/entity/Mob;checkSpawnObstruction(Lnet/minecraft/world/level/LevelReader;)Z"), cancellable = true, locals = LocalCapture.CAPTURE_FAILSOFT)
	private void BaseSpawner_serverTickprivate(class_3218 serverLevel, class_2338 pos, CallbackInfo ci, boolean bl, class_5819 randomSource, class_1952 spawnData, int i, class_8942.class_11340 scopedCollector, class_11368 valueInput, Optional<?> optional, class_243 vec3, class_2338 blockPos, class_1297 entity, int j, class_1308 mob) {
		mob.method_5780(CollectiveReference.MOD_ID + ".fromspawner");
		
		if (!CollectiveSpawnEvents.MOB_CHECK_SPAWN.invoker().onMobCheckSpawn(mob, serverLevel, blockPos, class_3730.field_16469)) {
			ci.cancel();
			delay(serverLevel, blockPos);
		}
	}
}
