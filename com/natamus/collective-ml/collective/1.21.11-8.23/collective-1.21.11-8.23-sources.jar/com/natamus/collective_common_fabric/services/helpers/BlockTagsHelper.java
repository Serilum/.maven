package com.natamus.collective_common_forge.services.helpers;

import net.minecraft.world.level.block.state.BlockState;

public interface BlockTagsHelper {
    boolean isOre(BlockState blockState);
    boolean isOre(BlockState blockState, boolean fuzzyCheck);
}