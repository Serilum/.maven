package com.natamus.collective.fabric.services;

import com.natamus.collective_common_fabric.data.IEntityDataHolder;
import com.natamus.collective_common_fabric.services.helpers.EntityDataHelper;
import net.minecraft.class_1297;
import net.minecraft.class_2487;

public class FabricEntityDataHelper implements EntityDataHelper {
	@Override
	public void init() {
	}

	@Override
	public class_2487 getStored(class_1297 entity) {
		// Degrade gracefully if EntityMixin's holder interface isn't applied (e.g. an outdated loader Mixin rejects it).
		if (entity instanceof IEntityDataHolder holder) {
			return holder.collective_getStored();
		}
		return new class_2487();
	}

	@Override
	public void setStored(class_1297 entity, class_2487 data) {
		if (entity instanceof IEntityDataHolder holder) {
			holder.collective_setStored(data);
		}
	}
}
