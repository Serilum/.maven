package com.natamus.collective.forge.mixin;

import com.natamus.collective_common_forge.services.Services;
import net.minecraft.client.gui.screens.worldselection.WorldOpenFlows;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value = WorldOpenFlows.class, priority = 1001, remap = false)
public class WorldOpenFlowsMixin {
	@ModifyVariable(method = "loadLevel(Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lcom/mojang/serialization/Dynamic;ZZLjava/lang/Runnable;Z)V", at = @At(value= "STORE"), ordinal = 5)
	public boolean loadLevel_bl2(boolean isLifeCycleStable) {
		return !Services.MODLOADER.isDevelopmentEnvironment() && !Services.MODLOADER.isModLoaded("hideexperimentalwarning");
	}
}
