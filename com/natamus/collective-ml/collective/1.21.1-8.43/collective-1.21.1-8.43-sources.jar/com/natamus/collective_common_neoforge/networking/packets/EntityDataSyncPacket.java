package com.natamus.collective_common_neoforge.networking.packets;

import com.natamus.collective_common_neoforge.implementations.networking.api.Dispatcher;
import com.natamus.collective_common_neoforge.implementations.networking.data.PacketContext;
import com.natamus.collective_common_neoforge.implementations.networking.data.Side;
import com.natamus.collective_common_neoforge.services.Services;
import com.natamus.collective_common_neoforge.util.CollectiveReference;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

public class EntityDataSyncPacket {
	public static final ResourceLocation CHANNEL = ResourceLocation.fromNamespaceAndPath(CollectiveReference.MOD_ID, "entity_data_sync");

	public final int entityId;
	public final CompoundTag data;

	public EntityDataSyncPacket(int entityId, CompoundTag data) {
		this.entityId = entityId;
		this.data = data;
	}

	public static EntityDataSyncPacket decode(FriendlyByteBuf buf) {
		return new EntityDataSyncPacket(buf.readVarInt(), buf.readNbt());
	}

	public void encode(FriendlyByteBuf buf) {
		buf.writeVarInt(entityId);
		buf.writeNbt(data);
	}

	public static void handle(PacketContext<EntityDataSyncPacket> ctx) {
		if (!Side.CLIENT.equals(ctx.side())) {
			return;
		}

		EntityDataSyncClientHandler.apply(ctx.message().entityId, ctx.message().data);
	}

	public static void syncToTrackers(Entity entity) {
		if (entity.level().isClientSide()) {
			return;
		}

		CompoundTag data = Services.ENTITYDATA.getStored(entity);
		if (data.isEmpty()) {
			return;
		}

		Dispatcher.sendToClientsLoadingChunk(new EntityDataSyncPacket(entity.getId(), data), entity.level().getChunkAt(entity.blockPosition()));
	}

	public static void syncToPlayer(Entity entity, ServerPlayer player) {
		CompoundTag data = Services.ENTITYDATA.getStored(entity);
		if (data.isEmpty()) {
			return;
		}

		Dispatcher.sendToClient(new EntityDataSyncPacket(entity.getId(), data), player);
	}
}
