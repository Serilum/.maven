package com.natamus.collective_common_neoforge.implementations.networking;


import com.natamus.collective_common_neoforge.implementations.networking.api.NetworkHandler;
import com.natamus.collective_common_neoforge.implementations.networking.data.PacketContainer;
import com.natamus.collective_common_neoforge.implementations.networking.data.PacketContext;
import com.natamus.collective_common_neoforge.implementations.networking.data.Side;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

/** The networking code is based on the MIT licensed
 *   <a href="https://github.com/mysticdrew/common-networking">common-networking</a> v1.0.8
 *  by MysticDrew */

public abstract class PacketRegistrationHandler implements NetworkHandler, PacketRegistrar {
	public final Map<Class<?>, PacketContainer<?>> PACKET_MAP = new ConcurrentHashMap<>();

	protected final Side side;

	/**
	 * Handles packet registration
	 *
	 * @param side - The side
	 */
	public PacketRegistrationHandler(Side side) {
		this.side = side;
	}

	public <T> PacketRegistrar registerPacket(ResourceLocation packetIdentifier, Class<T> packetClass, BiConsumer<T, FriendlyByteBuf> encoder, Function<FriendlyByteBuf, T> decoder, Consumer<PacketContext<T>> handler) {
		PacketContainer<T> container = new PacketContainer<>(packetIdentifier, packetClass, encoder, decoder, handler);
		PACKET_MAP.put(packetClass, container);
		registerPacket(container);
		return this;
	}

	public Side getSide() {
		return side;
	}

	protected abstract <T> void registerPacket(PacketContainer<T> container);
}

