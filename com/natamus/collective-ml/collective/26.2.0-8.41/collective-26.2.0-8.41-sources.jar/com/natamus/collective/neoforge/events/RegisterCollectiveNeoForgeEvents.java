package com.natamus.collective.neoforge.events;

import com.natamus.collective_common_neoforge.cmds.CommandCollective;
import com.natamus.collective_common_neoforge.config.GenerateJSONFiles;
import com.natamus.collective_common_neoforge.events.CollectiveEvents;
import com.natamus.collective_common_neoforge.functions.WorldFunctions;
import com.natamus.collective_common_neoforge.translations.ServerTranslationPack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.level.LevelEvent;
import net.neoforged.neoforge.event.server.ServerAboutToStartEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

@EventBusSubscriber
public class RegisterCollectiveNeoForgeEvents {
	@SubscribeEvent
	public static void onServerStarted(ServerAboutToStartEvent e) {
		GenerateJSONFiles.initGeneration(e.getServer());
		ServerTranslationPack.onServerStarting(e.getServer());
	}

	@SubscribeEvent
	public static void onWorldLoad(LevelEvent.Load e) {
		Level level = WorldFunctions.getWorldIfInstanceOfAndNotRemote(e.getLevel());
		if (level == null) {
			return;
		}

		CollectiveEvents.onWorldLoad(level);
	}

	@SubscribeEvent
	public static void onWorldTick(LevelTickEvent.Post e) {
		Level level = e.getLevel();
		if (level.isClientSide()) {
			return;
		}

		CollectiveEvents.onWorldTick((ServerLevel)level);
	}

	@SubscribeEvent
	public static void onServerTick(ServerTickEvent.Post e) {
		CollectiveEvents.onServerTick(e.getServer());
	}

	@SubscribeEvent
	public static void onEntityJoinLevel(EntityJoinLevelEvent e) {
		if (!CollectiveEvents.onEntityJoinLevel(e.getLevel(), e.getEntity())) {
			e.setCanceled(true);
		}
	}

	@SubscribeEvent
	public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent e) {
		if (e.getEntity() instanceof ServerPlayer player) {
			ServerTranslationPack.onPlayerJoin(player);
		}
	}

	@SubscribeEvent
	public static void registerCommands(RegisterCommandsEvent e) {
		CommandCollective.register(e.getDispatcher());
	}
}