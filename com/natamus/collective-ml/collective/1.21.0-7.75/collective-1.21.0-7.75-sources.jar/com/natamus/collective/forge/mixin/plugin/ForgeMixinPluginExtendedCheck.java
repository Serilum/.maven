package com.natamus.collective.forge.mixin.plugin;

import net.minecraftforge.fml.ModContainer;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.forgespi.language.IModInfo;

import java.util.Optional;

public class ForgeMixinPluginExtendedCheck {
	public static boolean enableMixinLoad(String targetClassName, String mixinClassName) {
		System.out.println("!!! FABRIC enableMixinLoad");
		System.out.println("targetClassName: " + targetClassName);
		System.out.println("mixinClassName: " + mixinClassName);

		String[] pSpl = mixinClassName.split("\\.");
		if (pSpl.length < 3) {
			System.out.println("pSpl length < 3");
			return true;
		}

		String modId = pSpl[2].split("_")[0];
		System.out.println("CHECKING MOD (ID): " + modId);

		Optional<? extends ModContainer> modContainerOpt = ModList.get().getModContainerById(modId);

        if (modContainerOpt.isPresent()) {
            ModContainer modContainer = modContainerOpt.get();

            // Get the mod info
            IModInfo modInfo = modContainer.getModInfo();

            // Get the location of the mod
            String location = modInfo.getOwningFile().getFile().getFilePath().toString();
            System.out.println("Mod Location: " + location);

            // Check if the mod is jar-in-jar'd
            if (location.contains(".jar!/")) {
                System.out.println("The mod is jar-in-jar'd.");
            } else {
                System.out.println("The mod is not jar-in-jar'd.");
            }
        }
		else {
			System.out.println("Mod Container not present.");
		}

		return true;
	}
}
