package com.natamus.collective.fabric.mixin.plugin;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;

import java.util.Optional;

public class FabricMixinPluginExtendedCheck {
	public static boolean enableMixinLoad(String targetClassName, String mixinClassName) {
		System.out.println("!!! FABRIC enableMixinLoad");
		System.out.println("targetClassName: " + targetClassName);
		System.out.println("mixinClassName: " + mixinClassName);

		String[] pSpl = mixinClassName.split("\\.");
		if (pSpl.length < 3) {
			System.out.println("pSpl length < 3");
			return true;
		}

		String modId = pSpl[2].split("_")[0];
		System.out.println("CHECKING MOD (ID): " + modId);

		Optional<ModContainer> modContainerOpt = FabricLoader.getInstance().getModContainer(modId);

        if (modContainerOpt.isPresent()) {
            ModContainer modContainer = modContainerOpt.get();

            // Get the location of the mod
            String location = modContainer.getOrigin().toString();
            System.out.println("Mod Location: " + location);

            // Check if the mod is jar-in-jar'd
            if (location.contains(".jar!/")) {
                System.out.println("The mod is jar-in-jar'd.");
            } else {
                System.out.println("The mod is not jar-in-jar'd.");
            }
        }
		else {
			System.out.println("Mod Container not present.");
		}

		return true;
	}
}
