package com.natamus.collective;

import com.natamus.collective_common_fabric.CollectiveCommon;
import com.natamus.collective_common_fabric.check.RegisterMod;
import com.natamus.collective_common_fabric.cmds.CommandCollective;
import com.natamus.collective_common_fabric.config.GenerateJSONFiles;
import com.natamus.collective_common_fabric.data.GlobalConstants;
import com.natamus.collective_common_fabric.events.CollectiveEvents;
import com.natamus.collective.fabric.data.GlobalFabricObjects;
import com.natamus.collective.fabric.networking.FabricNetworkHandler;
import com.natamus.collective_common_fabric.implementations.networking.NetworkSetup;
import com.natamus.collective_common_fabric.implementations.networking.data.Side;
import com.natamus.collective_common_fabric.util.CollectiveReference;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1297;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

public class CollectiveFabric implements ModInitializer { 
	@Override
	public void onInitialize() {
        if (!FabricLoader.getInstance().getEnvironmentType().equals(EnvType.CLIENT)) {
			new NetworkSetup(new FabricNetworkHandler(Side.SERVER));
		}

		setGlobalConstants();
		CollectiveCommon.init();

		ServerLifecycleEvents.SERVER_STARTING.register((MinecraftServer minecraftServer) -> {
			GenerateJSONFiles.initGeneration(minecraftServer);
		});
		
		ServerTickEvents.START_WORLD_TICK.register((class_3218 world) -> {
			CollectiveEvents.onWorldTick(world);
		});

		ServerTickEvents.START_SERVER_TICK.register((MinecraftServer minecraftServer) -> {
			CollectiveEvents.onServerTick(minecraftServer);
		});
		
		ServerEntityEvents.ENTITY_LOAD.register((class_1297 entity, class_3218 world) -> {
			CollectiveEvents.onEntityJoinLevel(world, entity);
		});

		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			CommandCollective.register(dispatcher);
		});

		RegisterMod.register(CollectiveReference.NAME, CollectiveReference.MOD_ID, CollectiveReference.VERSION, CollectiveReference.ACCEPTED_VERSIONS);
	}

	private static void setGlobalConstants() {
		GlobalConstants.isClient = GlobalFabricObjects.fabricLoader.getEnvironmentType() == EnvType.CLIENT;
		GlobalConstants.gameDir = GlobalFabricObjects.fabricLoader.getGameDir().toString();
	}
}
