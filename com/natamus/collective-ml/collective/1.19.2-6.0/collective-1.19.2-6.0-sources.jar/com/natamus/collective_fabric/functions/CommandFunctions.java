package com.natamus.collective_fabric.functions;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_1918;
import net.minecraft.class_2168;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;

public class CommandFunctions {
    public static String getRawCommandOutput(class_3218 serverLevel, @Nullable class_243 vec, String command) {
        class_1918 bcb = new class_1918() {
            @Override
            public @NotNull class_3218 method_8293() {
                return serverLevel;
            }

            @Override
            public void method_8295() { }

            @Override
            public @NotNull class_243 method_8300() {
                return Objects.requireNonNullElseGet(vec, () -> new class_243(0, 0, 0));
            }

            @Override
            public @NotNull class_2168 method_8303() {
                return new class_2168(this, method_8300(), class_241.field_1340, serverLevel, 2, "dev", class_2561.method_43470("dev"), serverLevel.method_8503(), null);
            }
        };

        bcb.method_8286(command);
        bcb.method_8287(true);
        bcb.method_8301(serverLevel);

        return bcb.method_8292().getString();
    }
}
