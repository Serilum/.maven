package com.natamus.collective.forge.config;

import com.natamus.collective_forge.config.DuskConfig;
import com.natamus.collective_forge.util.CollectiveReference;
import net.minecraftforge.client.ConfigScreenHandler;
import net.minecraftforge.fml.ModLoadingContext;

public class CollectiveConfigScreen {
    public static void registerScreen(ModLoadingContext modLoadingContext) {
        modLoadingContext.registerExtensionPoint(ConfigScreenHandler.ConfigScreenFactory.class, () -> {
            return new ConfigScreenHandler.ConfigScreenFactory((mc, screen) -> {
                return DuskConfig.getScreen(screen, CollectiveReference.MOD_ID);
            });
        });
    }
}
