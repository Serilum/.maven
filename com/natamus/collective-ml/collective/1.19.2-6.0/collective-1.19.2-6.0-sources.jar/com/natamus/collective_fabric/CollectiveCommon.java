package com.natamus.collective_forge;

import com.natamus.collective_forge.config.CollectiveConfigHandler;
import com.natamus.collective_forge.data.GlobalVariables;
import com.natamus.collective_forge.objects.SAMObject;
import com.natamus.collective_forge.util.CollectiveReference;
import net.minecraft.world.entity.EntityType;

public class CollectiveCommon {
    public static void init() {
        System.out.println("Loading Collective version " + CollectiveReference.VERSION + ".");

        CollectiveConfigHandler.initConfig();
        GlobalVariables.generateHashMaps();

        new SAMObject(EntityType.ZOMBIE, EntityType.ZOMBIE_VILLAGER, null, 0.5, true, false, false);
    }
}
