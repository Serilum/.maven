package com.natamus.collective.fabric.mixin;

import com.mojang.authlib.minecraft.UserApiService;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.natamus.collective.fabric.callbacks.CollectiveLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;
import net.minecraft.class_542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_310.class, priority = 1001)
public class MinecraftMixin {
    @Inject(method = "<init>(Lnet/minecraft/client/main/GameConfig;)V", at = @At(value = "TAIL"))
    public void Minecraft_init(class_542 gameConfig, CallbackInfo ci) {
        ((class_310)(Object)this).execute(() -> {
            CollectiveLifecycleEvents.MINECRAFT_LOADED.invoker().onMinecraftLoad(true);
        });
    }

    @Inject(method = "createUserApiService", at = @At(value = "HEAD"), cancellable = true)
    public void Minecraft_createUserApiService(YggdrasilAuthenticationService yggdrasilAuthenticationService, class_542 gameConfig, CallbackInfoReturnable<UserApiService> cir) {
        if (FabricLoader.getInstance().isDevelopmentEnvironment()) {
            System.out.println("Failed to verify authentication");
            cir.setReturnValue(UserApiService.OFFLINE);
        }
    }
}
