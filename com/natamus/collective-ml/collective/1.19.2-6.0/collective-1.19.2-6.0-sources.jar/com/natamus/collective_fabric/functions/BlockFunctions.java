package com.natamus.collective_fabric.functions;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2333;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import com.natamus.collective_fabric.data.GlobalVariables;

public class BlockFunctions {
	// START: Checks whether specificblock equals tocheckblock
	public static Boolean isSpecificBlock(class_2248 specificblock, class_2248 tocheckblock) {
		if (specificblock == null || tocheckblock == null) {
			return false;
		}
        return specificblock.equals(tocheckblock);
    }
	public static Boolean isSpecificBlock(class_2248 specificblock, class_1799 tocheckitemstack) {
		if (tocheckitemstack == null) {
			return false;
		}
		class_1792 tocheckitem = tocheckitemstack.method_7909();
		if (tocheckitem == null) {
			return false;
		}
		
		class_2248 tocheckblock = class_2248.method_9503(tocheckitem);
		return isSpecificBlock(specificblock, tocheckblock);
	}
	public static Boolean isSpecificBlock(class_2248 specificblock, class_1937 world, class_2338 pos) {
		class_2248 tocheckblock = world.method_8320(pos).method_26204();
		return isSpecificBlock(specificblock, tocheckblock);
	}
	// END: Checks whether specificblock equals tocheckblock
	
	public static void dropBlock(class_1937 world, class_2338 pos) {
		class_2680 blockstate = world.method_8320(pos);
		class_2586 tileentity = world.method_8321(pos);
		
		class_2248.method_9610(blockstate, world, pos, tileentity);
		world.method_8652(pos, class_2246.field_10124.method_9564(), 3);
	}
	
	// START: Check whether the block to check is one of the blocks in the array.
	public static Boolean isOneOfBlocks(List<class_2248> blocks, class_2248 tocheckblock) {
		if (blocks.size() < 1) {
			return false;
		}
		
		for (class_2248 specificblock : blocks) {
			if (isSpecificBlock(specificblock, tocheckblock)) {
				return true;
			}
		}
		
		return false;
	}
	public static Boolean isOneOfBlocks(List<class_2248> blocks, class_1799 tocheckitemstack) {
		if (tocheckitemstack == null) {
			return false;
		}
		class_1792 tocheckitem = tocheckitemstack.method_7909();
		if (tocheckitem == null) {
			return false;
		}
		
		class_2248 tocheckblock = class_2248.method_9503(tocheckitem);
		return isOneOfBlocks(blocks, tocheckblock);
	}
	public static Boolean isOneOfBlocks(List<class_2248> blocks, class_1937 world, class_2338 pos) {
		class_2248 tocheckblock = world.method_8320(pos).method_26204();
		return isOneOfBlocks(blocks, tocheckblock);
	}
	// END: Check whether the block to check is one of the blocks in the array.
	
	// For bamboo
	public static boolean isGrowBlock(class_2248 block) {
		return GlobalVariables.growblocks.contains(block);
    }
	
	public static boolean isStoneTypeBlock(class_2248 block) {
        return GlobalVariables.stoneblocks.contains(block);
    }
	
	public static Boolean isFilledPortalFrame(class_2680 blockstate) {
		class_2248 block = blockstate.method_26204();
		if (!block.equals(class_2246.field_10398)) {
			return false;
		}
		
		return blockstate.method_11654(class_2333.field_10958);
	}
	
	public static String blockToReadableString(class_2248 block, int amount) {
		String blockstring;
		String[] blockspl = block.method_9539().replace("block.", "").split("\\.");
		if (blockspl.length > 1) {
			blockstring = blockspl[1];
		}
		else {
			blockstring = blockspl[0];
		}
		
		blockstring = blockstring.replace("_", " ");
		if (amount > 1) {
			blockstring = blockstring + "s";
		}
		
		return blockstring;
	}
	public static String blockToReadableString(class_2248 block) {
		return blockToReadableString(block, 1);
	}
}