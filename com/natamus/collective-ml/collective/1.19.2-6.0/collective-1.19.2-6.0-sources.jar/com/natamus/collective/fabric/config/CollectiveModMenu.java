package com.natamus.collective.fabric.config;

import com.natamus.collective_fabric.config.DuskConfig;
import com.natamus.collective_fabric.util.Reference;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

public class CollectiveModMenu implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> DuskConfig.getScreen(parent, Reference.MOD_ID);
    }
}