package com.natamus.collective_forge.data;

public class GlobalConstants {
    public static boolean isClient = false;
    public static String gameDir = "";
}
