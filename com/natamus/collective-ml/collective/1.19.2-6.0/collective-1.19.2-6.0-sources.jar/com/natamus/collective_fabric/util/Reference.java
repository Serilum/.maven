package com.natamus.collective_fabric.util;

public class Reference {
	public static final String MOD_ID = "collective";
	public static final String NAME = "Collective";
	public static final String VERSION = "6.0";
	public static final String ACCEPTED_VERSIONS = "[1.19.2]";
}
