package com.natamus.collective_forge;

import com.natamus.collective_forge.config.CollectiveConfigHandler;
import com.natamus.collective_forge.config.DuskConfig;
import com.natamus.collective_forge.data.GlobalVariables;
import com.natamus.collective_forge.util.Reference;

public class CollectiveCommon {
    public static void init() {
        System.out.println("Loading Collective version " + Reference.VERSION + ".");

        CollectiveConfigHandler.initConfig();
        GlobalVariables.generateHashMaps();
    }
}
