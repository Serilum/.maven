package com.natamus.collective.forge.services;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective_common_forge.services.helpers.RegisterItemHelper;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.function.Supplier;

public class ForgeRegisterItemHelper implements RegisterItemHelper {
	private final HashMap<String, DeferredRegister<Item>> deferredItemRegisterMap = new HashMap<String, DeferredRegister<Item>>();
	private static final List<Pair<ResourceKey<CreativeModeTab>, Item>> creativeInventoryItemPairs = new ArrayList<Pair<ResourceKey<CreativeModeTab>, Item>>();

    @Override
	public <T extends Item> Item registerAndGetItem(Object modEventBusObject, ResourceLocation resourceLocation, Supplier<T> itemSupplier, @Nullable ResourceKey<CreativeModeTab> creativeModeTabResourceKey) {
		String namespace = resourceLocation.getNamespace();
		if (!deferredItemRegisterMap.containsKey(namespace)) {
			DeferredRegister<Item> deferredItemRegister = DeferredRegister.create(ForgeRegistries.ITEMS, namespace);
			deferredItemRegister.register((IEventBus)modEventBusObject);
			deferredItemRegisterMap.put(namespace, deferredItemRegister);
		}

		RegistryObject<Item> deferredItemObject = deferredItemRegisterMap.get(namespace).register(resourceLocation.getPath(), itemSupplier);
		Item deferredItem = deferredItemObject.get();

		if (creativeModeTabResourceKey != null) {
			creativeInventoryItemPairs.add(Pair.of(creativeModeTabResourceKey, deferredItem));
		}

		return deferredItem;
	}

	public static void addItemsToCreativeInventory(BuildCreativeModeTabContentsEvent e) {
		for (Pair<ResourceKey<CreativeModeTab>, Item> tabPair : creativeInventoryItemPairs) {
			if (e.getTabKey().equals(tabPair.getFirst())) {
				e.accept(tabPair.getSecond());
			}
		}
	}
}