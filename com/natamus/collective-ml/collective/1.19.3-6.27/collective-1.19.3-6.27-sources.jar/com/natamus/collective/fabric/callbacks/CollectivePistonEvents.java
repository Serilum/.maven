package com.natamus.collective.fabric.callbacks;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public class CollectivePistonEvents {
	private CollectivePistonEvents() { }
	 
    public static final Event<Explosion_Detonate> PRE_PISTON_ACTIVATE = EventFactory.createArrayBacked(Explosion_Detonate.class, callbacks -> (level, blockPos, direction, isExtending) -> {
        for (Explosion_Detonate callback : callbacks) {
        	if (!callback.onPistonActivate(level, blockPos, direction, isExtending)) {
				return false;
			}
        }
		return true;
    });
    
	@FunctionalInterface
	public interface Explosion_Detonate {
		 boolean onPistonActivate(class_1937 level, class_2338 blockPos, class_2350 direction, boolean isExtending);
	}
}
