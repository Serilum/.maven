package com.natamus.collective.fabric.services;

import com.natamus.collective_common_fabric.services.helpers.TeleportHelper;
import net.fabricmc.fabric.api.dimension.v1.FabricDimensions;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_5454;

public class FabricTeleportHelper implements TeleportHelper {
    @Override
    public <T extends class_1297> class_1297 teleportEntity(T entity, class_3218 serverLevel, class_5454 portalInfo) {
        return FabricDimensions.teleport(entity, serverLevel, portalInfo);
    }

    @Override
    public <T extends class_1297> class_1297 teleportEntity(T entity, class_3218 serverLevel, class_243 vec3) {
        return teleportEntity(entity, serverLevel, new class_5454(vec3, entity.method_18798(), entity.method_36454(), entity.method_36455()));
    }

    @Override
    public <T extends class_1297> class_1297 teleportEntity(T entity, class_3218 serverLevel, class_2338 blockPos) {
        return teleportEntity(entity, serverLevel, new class_243(blockPos.method_10263()+0.5, blockPos.method_10264(), blockPos.method_10260()+0.5));
    }

    @Override
    public <T extends class_1297> class_1297 teleportEntity(T entity, class_5321<class_1937> targetDimension, class_243 vec3) {
        if (entity.method_37908().field_9236) {
            return entity;
        }

        return teleportEntity(entity, entity.method_5682().method_3847(targetDimension), new class_5454(vec3, entity.method_18798(), entity.method_36454(), entity.method_36455()));
    }

    @Override
    public <T extends class_1297> class_1297 teleportEntity(T entity, class_5321<class_1937> targetDimension, class_2338 blockPos) {
        return teleportEntity(entity, targetDimension, new class_243(blockPos.method_10263()+0.5, blockPos.method_10264(), blockPos.method_10260()+0.5));
    }
}
