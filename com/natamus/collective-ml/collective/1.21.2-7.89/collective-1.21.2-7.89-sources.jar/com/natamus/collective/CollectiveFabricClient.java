package com.natamus.collective;

import com.natamus.collective.fabric.networking.FabricNetworkHandler;
import com.natamus.collective_common_fabric.globalcallbacks.CollectiveGuiCallback;
import com.natamus.collective_common_fabric.implementations.networking.NetworkSetup;
import com.natamus.collective_common_fabric.implementations.networking.data.Side;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public class CollectiveFabricClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		new NetworkSetup(new FabricNetworkHandler(Side.CLIENT));

		registerEvents();
	}
	
	private void registerEvents() {
		HudRenderCallback.EVENT.register((class_332 guiGraphics, class_9779 deltaTracker) -> {
			CollectiveGuiCallback.ON_GUI_RENDER.invoker().onGuiRender(guiGraphics, deltaTracker);
		});
	}
}
