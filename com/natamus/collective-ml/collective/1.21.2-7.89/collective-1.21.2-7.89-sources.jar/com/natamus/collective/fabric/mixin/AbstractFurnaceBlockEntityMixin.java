package com.natamus.collective.fabric.mixin;

import com.natamus.collective.fabric.callbacks.CollectiveFurnaceEvents;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2609;
import net.minecraft.class_9895;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_2609.class, priority = 1001)
public class AbstractFurnaceBlockEntityMixin {
	@Inject(method = "getBurnDuration", at = @At(value = "HEAD"), cancellable = true)
	public void AbstractFurnaceBlockEntity_getBurnDuration(class_9895 fuelValues, class_1799 itemStack, CallbackInfoReturnable<Integer> ci) {
		if (!itemStack.method_7960()) {
			class_1792 item = itemStack.method_7909();
			int burntime = fuelValues.method_61755(itemStack);
			int newburntime = CollectiveFurnaceEvents.CALCULATE_FURNACE_BURN_TIME.invoker().getFurnaceBurnTime(itemStack, burntime);
			if (burntime != newburntime) {
				ci.setReturnValue(newburntime);
			}
		}
	}
}
