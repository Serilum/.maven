package com.natamus.collective_common_forge.services.helpers;

public interface ModLoaderHelper {
	String getModLoaderName();
	String getGameDirectory();
	boolean isModLoaded(String modId);
	boolean isDevelopmentEnvironment();
	boolean isClientSide();
	boolean isJarJard(String modId);
	boolean isBundleModEnabled(String modId);
}