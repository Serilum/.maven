package com.natamus.collective_common_forge;

import com.natamus.collective_common_forge.config.CollectiveConfigHandler;
import com.natamus.collective_common_forge.config.LoadJSONFiles;
import com.natamus.collective_common_forge.data.Constants;
import com.natamus.collective_common_forge.data.GlobalVariables;
import com.natamus.collective_common_forge.networking.PacketRegistration;
import com.natamus.collective_common_forge.services.Services;
import com.natamus.collective_common_forge.util.CollectiveReference;

public class CollectiveCommon {
	public static void init() {
		Constants.LOG.info("Loading Collective version " + CollectiveReference.VERSION + ".");

		CollectiveConfigHandler.initConfig();
		GlobalVariables.generateHashMaps();
		LoadJSONFiles.startListening();

		registerPackets();
		loadEvents();
	}

	public static void registerPackets() {
		new PacketRegistration().init();
	}

	public static void loadEvents() {
		Services.ENTITYDATA.init();
	}
}
