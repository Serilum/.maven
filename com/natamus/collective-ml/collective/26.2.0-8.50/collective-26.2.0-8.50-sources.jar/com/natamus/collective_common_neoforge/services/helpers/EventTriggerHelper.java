package com.natamus.collective_common_neoforge.services.helpers;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.portal.PortalShape;

public interface EventTriggerHelper {
	void triggerNetherPortalSpawnEvent(Level level, BlockPos portalPos, PortalShape size);
	void triggerLivingConversionEvent(LivingEntity entity, LivingEntity outcome);
}