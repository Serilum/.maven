package com.natamus.collective_common_forge.data;

public class GlobalConstants {
    public static boolean isClient = false;
    public static String gameDir = "";
}
