package com.natamus.collective.fabric.services;

import com.natamus.collective_common_fabric.services.helpers.ToolFunctionsHelper;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalItemTags;
import net.minecraft.class_1743;
import net.minecraft.class_1786;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1819;
import net.minecraft.class_1820;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.world.item.*;

public class FabricToolFunctionsHelper implements ToolFunctionsHelper {
    @Override
    public boolean isTool(class_1799 itemstack) {
		return isPickaxe(itemstack) || isAxe(itemstack) || isShovel(itemstack) || isHoe(itemstack) || isShears(itemstack);
    }

    @Override
	public boolean isSword(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1829 || itemStack.method_31573(ConventionalItemTags.SWORDS);
    }

    @Override
	public boolean isShield(class_1799 itemStack) {
		return itemStack.method_7909() instanceof class_1819;
	}

    @Override
	public boolean isPickaxe(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1810 || itemStack.method_31573(ConventionalItemTags.PICKAXES);
    }

    @Override
	public boolean isAxe(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1743 || itemStack.method_31573(ConventionalItemTags.AXES);
    }

    @Override
	public boolean isShovel(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1821 || itemStack.method_31573(ConventionalItemTags.SHOVELS);
    }

    @Override
	public boolean isHoe(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1794 || itemStack.method_31573(ConventionalItemTags.HOES);
    }

    @Override
	public boolean isShears(class_1799 itemStack) {
		return itemStack.method_7909() instanceof class_1820 || itemStack.method_31573(ConventionalItemTags.SHEARS);
	}

    @Override
    public boolean isFlintAndSteel(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1786;
    }
}
