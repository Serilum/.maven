package com.natamus.collective.fabric.mixin;

import java.util.List;
import net.minecraft.class_1536;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import com.natamus.collective.fabric.callbacks.CollectiveItemEvents;

@Mixin(value = class_1536.class, priority = 1001)
public abstract class FishingHookMixin {
	@ModifyVariable(method = "retrieve", at = @At(value= "INVOKE_ASSIGN", target = "Lnet/minecraft/world/level/storage/loot/LootTable;getRandomItems(Lnet/minecraft/world/level/storage/loot/LootContext;)Ljava/util/List;"))
	private List<class_1799> FishingHook_retrieve(List<class_1799> list, class_1799 itemStack) {
		class_1536 hook = (class_1536)(Object)this;
		CollectiveItemEvents.ON_ITEM_FISHED.invoker().onItemFished(list, hook);
		
		return list;
	}
}
