package com.natamus.collective_common_forge.data;

import com.natamus.collective_common_forge.util.CollectiveReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Constants {
    public static final Logger LOG = LoggerFactory.getLogger(CollectiveReference.NAME);
}
