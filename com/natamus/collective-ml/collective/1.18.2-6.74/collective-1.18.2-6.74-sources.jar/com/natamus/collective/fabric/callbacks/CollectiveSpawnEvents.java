package com.natamus.collective.fabric.callbacks;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1308;
import net.minecraft.class_1917;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3730;

public class CollectiveSpawnEvents {
	private CollectiveSpawnEvents() { }

    public static final Event<Mob_Check_Spawn> MOB_CHECK_SPAWN = EventFactory.createArrayBacked(Mob_Check_Spawn.class, callbacks -> (entity, world, spawnerPos, spawnReason) -> {
        for (Mob_Check_Spawn callback : callbacks) {
        	if (!callback.onMobCheckSpawn(entity, world, spawnerPos, spawnReason)) {
        		return false;
        	}
        }

        return true;
    });

    public static final Event<Mob_Special_Spawn> MOB_SPECIAL_SPAWN = EventFactory.createArrayBacked(Mob_Special_Spawn.class, callbacks -> (entity, level, blockPos, spawner, spawnReason) -> {
        for (Mob_Special_Spawn callback : callbacks) {
        	if (!callback.onMobSpecialSpawn(entity, level, blockPos, spawner, spawnReason)) {
        		return false;
        	}
        }

        return true;
    });

	@FunctionalInterface
	public interface Mob_Check_Spawn {
		 boolean onMobCheckSpawn(class_1308 entity, class_3218 world, class_2338 spawnerPos, class_3730 spawnReason);
	}

	@FunctionalInterface
	public interface Mob_Special_Spawn {
		 boolean onMobSpecialSpawn(class_1308 entity, class_1937 level, class_2338 blockPos, class_1917 spawner, class_3730 spawnReason);
	}
}