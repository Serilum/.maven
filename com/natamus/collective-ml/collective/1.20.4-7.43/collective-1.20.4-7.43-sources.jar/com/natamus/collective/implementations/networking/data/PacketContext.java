package com.natamus.collective.implementations.networking.data;

import net.minecraft.server.level.ServerPlayer;

/** The networking code is based on the MIT licensed
 *   <a href="https://github.com/mysticdrew/common-networking">common-networking</a> v1.0.8
 *  by MysticDrew */

public record PacketContext<T>(ServerPlayer sender, T message, Side side) {
    public PacketContext(T message, Side side) {
        this(null, message, side);
    }
}
