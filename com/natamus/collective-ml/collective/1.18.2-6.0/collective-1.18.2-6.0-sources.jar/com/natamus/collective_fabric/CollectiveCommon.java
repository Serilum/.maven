package com.natamus.collective_fabric;

import com.natamus.collective_fabric.config.CollectiveConfigHandler;
import com.natamus.collective_fabric.config.DuskConfig;
import com.natamus.collective_fabric.data.GlobalVariables;
import com.natamus.collective_fabric.util.Reference;

public class CollectiveCommon {

    public static void init() {
        DuskConfig.init(Reference.MOD_ID, CollectiveConfigHandler.class);
        GlobalVariables.generateHashMaps();
    }
}
