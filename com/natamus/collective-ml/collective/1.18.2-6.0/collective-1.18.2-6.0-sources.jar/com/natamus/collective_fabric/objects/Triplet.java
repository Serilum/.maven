package com.natamus.collective_fabric.objects;

public record Triplet<T, U, V>(T first, U second, V third) {

}
