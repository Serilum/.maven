package com.natamus.collective;

import com.natamus.collective_fabric.CollectiveCommon;
import com.natamus.collective_fabric.check.RegisterMod;
import com.natamus.collective_fabric.data.GlobalConstants;
import com.natamus.collective_fabric.events.CollectiveEvents;
import com.natamus.collective.fabric.data.GlobalFabricObjects;
import com.natamus.collective_fabric.util.Reference;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.class_1297;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

public class CollectiveFabric implements ModInitializer { 
	@Override
	public void onInitialize() {
		System.out.println("Loading Collective (Fabric) version " + Reference.VERSION + ".");

		setGlobalConstants();
		CollectiveCommon.init();

		ServerWorldEvents.LOAD.register((MinecraftServer server, class_3218 world) -> {
			CollectiveEvents.onWorldLoad(world);
		});
		
		ServerTickEvents.START_WORLD_TICK.register((class_3218 world) -> {
			CollectiveEvents.onWorldTick(world);
		});
		
		ServerEntityEvents.ENTITY_LOAD.register((class_1297 entity, class_3218 world) -> {
			CollectiveEvents.onEntityJoinLevel(world, entity);
		});

		RegisterMod.register(Reference.NAME, Reference.MOD_ID, Reference.VERSION, Reference.ACCEPTED_VERSIONS);
	}

	private static void setGlobalConstants() {
		GlobalConstants.isClient = GlobalFabricObjects.fabricLoader.getEnvironmentType() == EnvType.CLIENT;
		GlobalConstants.gameDir = GlobalFabricObjects.fabricLoader.getGameDir().toString();

		GlobalConstants.assetsFolder = ""; // TODO
	}
}
