package com.natamus.collective_fabric.fakeplayer;

import com.mojang.authlib.GameProfile;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import net.minecraft.class_1282;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2598;
import net.minecraft.class_2708;
import net.minecraft.class_2793;
import net.minecraft.class_2795;
import net.minecraft.class_2797;
import net.minecraft.class_2799;
import net.minecraft.class_2803;
import net.minecraft.class_2805;
import net.minecraft.class_2811;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_2817;
import net.minecraft.class_2820;
import net.minecraft.class_2822;
import net.minecraft.class_2824;
import net.minecraft.class_2827;
import net.minecraft.class_2828;
import net.minecraft.class_2833;
import net.minecraft.class_2836;
import net.minecraft.class_2838;
import net.minecraft.class_2840;
import net.minecraft.class_2842;
import net.minecraft.class_2846;
import net.minecraft.class_2848;
import net.minecraft.class_2851;
import net.minecraft.class_2853;
import net.minecraft.class_2855;
import net.minecraft.class_2856;
import net.minecraft.class_2859;
import net.minecraft.class_2863;
import net.minecraft.class_2866;
import net.minecraft.class_2868;
import net.minecraft.class_2870;
import net.minecraft.class_2871;
import net.minecraft.class_2873;
import net.minecraft.class_2875;
import net.minecraft.class_2877;
import net.minecraft.class_2879;
import net.minecraft.class_2884;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import net.minecraft.class_3244;
import net.minecraft.class_3445;
import net.minecraft.class_3753;
import net.minecraft.class_4210;
import net.minecraft.class_4211;
import net.minecraft.class_5194;
import net.minecraft.class_5427;
import net.minecraft.network.protocol.game.*;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Set;
import java.util.UUID;

//Preliminary, simple Fake Player class
public class FakePlayer extends class_3222 {
	    public FakePlayer(MinecraftServer minecraftServer, class_3218 serverLevel, GameProfile gameProfile,
			class_3225 serverPlayerGameMode) {
		super(minecraftServer, serverLevel, gameProfile);
	}
		@Override public @NotNull class_243 method_19538(){ return new class_243(0, 0, 0); }
	    @Override public @NotNull class_2338 method_24515(){ return class_2338.field_10980; }
	    @Override public void method_7353(@NotNull class_2561 chatComponent, boolean actionBar){}
	    @Override public void method_9203(@NotNull class_2561 component, @NotNull UUID senderUUID) {}
	    @Override public void method_7342(@NotNull class_3445<?> par1StatBase, int par2){}
	    //@Override public void openGui(Object mod, int modGuiId, World world, int x, int y, int z){}
	    @Override public boolean method_5679(@NotNull class_1282 source){ return true; }
	    @Override public boolean method_7256(@NotNull class_1657 player){ return false; }
	    @Override public void method_6078(@NotNull class_1282 source){ }
	    @Override public void method_5773(){ }
	    @Override public void method_14213(@NotNull class_2803 pkt){ }

	    @SuppressWarnings("unused")
		private static class FakePlayerNetHandler extends class_3244 {
	        private static final class_2535 DUMMY_CONNECTION = new class_2535(class_2598.field_11942);

	        public FakePlayerNetHandler(MinecraftServer server, class_3222 player) {
	            super(server, DUMMY_CONNECTION, player);
	        }

	        @Override public void method_18784() { }
	        @Override public void method_14372() { }
	        @Override public void method_14367(@NotNull class_2561 message) { }
	        @Override public void method_12067(@NotNull class_2851 packet) { }
	        @Override public void method_12078(@NotNull class_2833 packet) { }
	        @Override public void method_12050(@NotNull class_2793 packet) { }
	        @Override public void method_12047(@NotNull class_2853 packet) { }
	        @Override public void method_30303(@NotNull class_5427 packet) { }
	        @Override public void method_12058(@NotNull class_2859 packet) { }
	        @Override public void method_12059(@NotNull class_2805 packet) { }
	        @Override public void method_12077(@NotNull class_2870 packet) { }
	        @Override public void method_12049(@NotNull class_2871 packet) { }
	        @Override public void method_12084(@NotNull class_2838 packet) { }
	        @Override public void method_12060(@NotNull class_2855 packet) { }
	        @Override public void method_12057(@NotNull class_2866 packet) { }
	        @Override public void method_12051(@NotNull class_2875 packet) { }
	        @Override public void method_16383(@NotNull class_3753 packet) { }
	        @Override public void method_27273(@NotNull class_5194 packet) { }
	        @Override public void method_12080(@NotNull class_2863 packet) { }
	        @Override public void method_12053(@NotNull class_2820 packet) { }
	        @Override public void method_12074(@NotNull class_2822 packet) { }
	        @Override public void method_12072(@NotNull class_2795 packet) { }
	        @Override public void method_12063(@NotNull class_2828 packet) { }
	        @Override public void method_14363(double x, double y, double z, float yaw, float pitch) { }
	        @Override public void method_14360(double x, double y, double z, float yaw, float pitch, @NotNull Set<class_2708.class_2709> flags) { }
	        @Override public void method_12066(@NotNull class_2846 packet) { }
	        @Override public void method_12046(@NotNull class_2885 packet) { }
	        @Override public void method_12065(@NotNull class_2886 packet) { }
	        @Override public void method_12073(@NotNull class_2884 packet) { }
	        @Override public void method_12081(@NotNull class_2856 packet) { }
	        @Override public void method_12064(@NotNull class_2836 packet) { }
	        @Override public void method_10839(@NotNull class_2561 message) { }
	        @Override public void method_14364(@NotNull class_2596<?> packet) { }
	        @Override public void method_14369(@NotNull class_2596<?> packet, @Nullable GenericFutureListener<? extends Future<? super Void>> listener) { }
	        @Override public void method_12056(@NotNull class_2868 packet) { }
	        @Override public void method_12048(@NotNull class_2797 packet) { }
	        @Override public void method_12052(@NotNull class_2879 packet) { }
	        @Override public void method_12045(@NotNull class_2848 packet) { }
	        @Override public void method_12062(@NotNull class_2824 packet) { }
	        @Override public void method_12068(@NotNull class_2799 packet) { }
	        @Override public void method_12054(@NotNull class_2815 packet) { }
	        @Override public void method_12076(@NotNull class_2813 packet) { }
	        @Override public void method_12061(@NotNull class_2840 packet) { }
	        @Override public void method_12055(@NotNull class_2811 packet) { }
	        @Override public void method_12070(@NotNull class_2873 packet) { }
	        @Override public void method_12071(@NotNull class_2877 packet) { }
	        @Override public void method_12082(@NotNull class_2827 packet) { }
	        @Override public void method_12083(@NotNull class_2842 packet) { }
	        @Override public void method_12069(@NotNull class_2803 packet) { }
	        @Override public void method_12075(@NotNull class_2817 packet) { }
	        @Override public void method_19475(@NotNull class_4210 packet) { }
	        @Override public void method_19476(@NotNull class_4211 packet) { }
	    }
}