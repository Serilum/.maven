package com.natamus.collective_fabric.data;

public class GlobalConstants {
    public static boolean isClient = false;
    public static String gameDir = "";
    public static String assetsFolder = "";
}
