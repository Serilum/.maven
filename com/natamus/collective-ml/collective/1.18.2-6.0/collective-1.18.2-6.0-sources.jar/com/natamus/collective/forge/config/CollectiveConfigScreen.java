package com.natamus.collective.forge.config;

import com.natamus.collective_forge.config.DuskConfig;
import com.natamus.collective_forge.util.Reference;
import net.minecraftforge.client.ConfigGuiHandler;
import net.minecraftforge.fml.ModLoadingContext;

public class CollectiveConfigScreen {
    public static void registerScreen(ModLoadingContext modLoadingContext) {
        modLoadingContext.registerExtensionPoint(ConfigGuiHandler.ConfigGuiFactory.class, () -> {
            return new ConfigGuiHandler.ConfigGuiFactory((mc, screen) -> {
                return DuskConfig.getScreen(screen, Reference.MOD_ID);
            });
        });
    }
}
