package com.natamus.collective_forge.objects;

public record Triplet<T, U, V>(T first, U second, V third) {

}
