package com.natamus.collective.fabric.services;

import com.natamus.collective_common_fabric.services.helpers.ClientUtilsHelper;

public class FabricClientUtilsHelper implements ClientUtilsHelper {
}