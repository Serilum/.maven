package com.natamus.collective_common_forge.services.helpers;

public interface ClientUtilsHelper {
}