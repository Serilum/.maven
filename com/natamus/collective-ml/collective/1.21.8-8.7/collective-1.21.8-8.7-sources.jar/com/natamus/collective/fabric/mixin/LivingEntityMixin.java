package com.natamus.collective.fabric.mixin;

import com.natamus.collective.fabric.callbacks.CollectiveEntityEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3483;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_1309.class, priority = 1001)
public abstract class LivingEntityMixin {
	@Shadow protected class_1799 useItem;

	@Shadow public abstract class_1268 getUsedItemHand();

	@Inject(method = "tick()V", at = @At(value = "HEAD"))
	public void LivingEntity_tick(CallbackInfo ci) {
		class_1297 entity = (class_1297)(Object)this;
		class_1937 world = entity.method_37908();
		
		CollectiveEntityEvents.LIVING_TICK.invoker().onTick(world, entity);
	}
	
	@Inject(method = "die(Lnet/minecraft/world/damagesource/DamageSource;)V", at = @At(value = "HEAD"), cancellable = true)
	public void LivingEntity_die(class_1282 damageSource, CallbackInfo ci) {
		class_1297 entity = (class_1297)(Object)this;
		if (!CollectiveEntityEvents.LIVING_ENTITY_DEATH.invoker().onDeath(entity.method_37908(), entity, damageSource)) {
			ci.cancel();
		}
	}
	
	@Inject(method = "calculateFallDamage(DF)I", at = @At(value = "RETURN"), cancellable = true)
	protected void LivingEntity_calculateFallDamage(double fallDistance, float damageMultiplier, CallbackInfoReturnable<Integer> cir) {
		class_1309 livingEntity = (class_1309)(Object)this;
		if (livingEntity.method_5864().method_20210(class_3483.field_42971)) {
			return;
		}

		if (CollectiveEntityEvents.ON_FALL_DAMAGE_CALC.invoker().onFallDamageCalc(livingEntity.method_37908(), livingEntity, fallDistance, damageMultiplier) == 0) {
			cir.setReturnValue(0);
		}
	}
	
	@ModifyVariable(method = "actuallyHurt(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/damagesource/DamageSource;F)V", at = @At(value= "INVOKE_ASSIGN", target = "Ljava/lang/Math;max(FF)F"), argsOnly = true)
	private float LivingEntity_actuallyHurt(float g, class_3218 serverLevel, class_1282 damageSource, float damage) {
		class_1309 livingEntity = (class_1309)(Object)this;
		class_1937 world = livingEntity.method_37908();

		float newDamage = CollectiveEntityEvents.ON_LIVING_DAMAGE_CALC.invoker().onLivingDamageCalc(world, livingEntity, damageSource, g);
		if (newDamage != -1 && newDamage != g) {
			return newDamage;
		}
		
		return g;
	}

	@Inject(method = "hurtServer(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/damagesource/DamageSource;F)Z", at = @At(value = "HEAD"), cancellable = true)
	public void LivingEntity_hurt(class_3218 serverLevel, class_1282 damageSource, float f, CallbackInfoReturnable<Boolean> cir) {
		class_1309 livingEntity = (class_1309)(Object)this;
		class_1937 world = livingEntity.method_37908();

		if (!CollectiveEntityEvents.ON_LIVING_ATTACK.invoker().onLivingAttack(world, livingEntity, damageSource, f)) {
			cir.setReturnValue(false);
		}
	}
	
	@Inject(method = "dropAllDeathLoot(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/damagesource/DamageSource;)V", at = @At(value = "TAIL"))
	protected void dropAllDeathLoot(class_3218 serverLevel, class_1282 damageSource, CallbackInfo ci) {
		class_1309 livingEntity = (class_1309)(Object)this;
		class_1937 world = livingEntity.method_37908();
		
		CollectiveEntityEvents.ON_ENTITY_IS_DROPPING_LOOT.invoker().onDroppingLoot(world, livingEntity, damageSource);
	}
	
	@Inject(method = "jumpFromGround", at = @At(value = "TAIL"))
	protected void LivingEntity_jumpFromGround(CallbackInfo ci) {
		class_1309 livingEntity = (class_1309)(Object)this;
		class_1937 world = livingEntity.method_37908();
		
		CollectiveEntityEvents.ON_ENTITY_IS_JUMPING.invoker().onLivingJump(world, livingEntity);
	}
}
