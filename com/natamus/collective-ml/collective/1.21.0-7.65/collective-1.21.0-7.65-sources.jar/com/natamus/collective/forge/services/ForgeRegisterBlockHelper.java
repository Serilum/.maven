package com.natamus.collective.forge.services;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective_common_forge.services.Services;
import com.natamus.collective_common_forge.services.helpers.RegisterBlockHelper;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.function.Supplier;

public class ForgeRegisterBlockHelper implements RegisterBlockHelper {
	private final HashMap<String, DeferredRegister<Block>> deferredBlockRegisterMap = new HashMap<String, DeferredRegister<Block>>();

    @Override
	public <T extends Block> Pair<Block, BlockItem> registerAndGetBlockPair(Object modEventBusObject, ResourceLocation resourceLocation, Supplier<T> blockSupplier, @Nullable ResourceKey<CreativeModeTab> creativeModeTabResourceKey) {
		String namespace = resourceLocation.getNamespace();
		if (!deferredBlockRegisterMap.containsKey(namespace)) {
			DeferredRegister<Block> deferredBlockRegister = DeferredRegister.create(ForgeRegistries.BLOCKS, namespace);
			((IEventBus)modEventBusObject).register(deferredBlockRegister);
			deferredBlockRegisterMap.put(namespace, deferredBlockRegister);
		}

		RegistryObject<Block> deferredBlockObject = deferredBlockRegisterMap.get(namespace).register(resourceLocation.getPath(), blockSupplier);
		Block deferredBlock = deferredBlockObject.get();

		Item deferredItem = Services.REGISTERITEM.registerAndGetItem(modEventBusObject, resourceLocation, () -> new BlockItem(deferredBlock, new Item.Properties()), creativeModeTabResourceKey);

		return Pair.of(deferredBlock, (BlockItem)deferredItem);
	}
}