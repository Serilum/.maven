package com.natamus.collective.fabric.services;

import com.natamus.collective_common_fabric.services.helpers.RegisterItemHelper;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import javax.annotation.Nullable;
import java.util.function.Supplier;

public class FabricRegisterItemHelper implements RegisterItemHelper {
    @Override
	public <T extends class_1792> class_1792 registerAndGetItem(Object modEventBusObject, class_2960 resourceLocation, Supplier<T> itemSupplier, @Nullable class_5321<class_1761> creativeModeTabResourceKey) {
		class_1792 item = itemSupplier.get();

		class_2378.method_10230(class_7923.field_41178, resourceLocation, item);

		if (creativeModeTabResourceKey != null) {
			ItemGroupEvents.modifyEntriesEvent(creativeModeTabResourceKey).register(entries -> entries.method_45421(item));
		}

		return item;
    }
}