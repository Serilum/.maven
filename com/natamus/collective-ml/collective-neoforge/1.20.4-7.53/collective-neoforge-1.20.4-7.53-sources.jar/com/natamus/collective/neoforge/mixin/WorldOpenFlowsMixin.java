package com.natamus.collective.neoforge.mixin;

import com.mojang.serialization.Lifecycle;
import com.natamus.collective.services.Services;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.worldselection.CreateWorldScreen;
import net.minecraft.client.gui.screens.worldselection.WorldOpenFlows;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = WorldOpenFlows.class, priority = 1001, remap = false)
public class WorldOpenFlowsMixin {
	@ModifyVariable(method = "loadLevel(Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lcom/mojang/serialization/Dynamic;ZZLjava/lang/Runnable;Z)V", at = @At(value= "STORE"), ordinal = 5)
	public boolean loadLevel_bl2(boolean isLifeCycleStable) {
		System.out.println("loadLevel (Collective): " + Services.MODLOADER.isModLoaded("collective"));
		System.out.println("loadLevel (Experimental): " + Services.MODLOADER.isModLoaded("hideexperimentalwarning"));
		System.out.println("loadLevel (Dev): " + Services.MODLOADER.isDevelopmentEnvironment());
		return !Services.MODLOADER.isDevelopmentEnvironment() && !Services.MODLOADER.isModLoaded("hideexperimentalwarning");
	}

	@Inject(method = "confirmWorldCreation", at = @At(value = "INVOKE_ASSIGN", target = "Lcom/mojang/serialization/Lifecycle;experimental()Lcom/mojang/serialization/Lifecycle;"), cancellable = true)
	private static void confirmWorldCreation(Minecraft minecraft, CreateWorldScreen screen, Lifecycle lifecycle, Runnable loadWorld, boolean skipWarnings, CallbackInfo ci) {
		System.out.println("confirmWorldCreation (Collective): " + Services.MODLOADER.isModLoaded("collective"));
		System.out.println("confirmWorldCreation (Experimental): " + Services.MODLOADER.isModLoaded("hideexperimentalwarning"));
		System.out.println("confirmWorldCreation (Dev): " + Services.MODLOADER.isDevelopmentEnvironment());

		if (Services.MODLOADER.isDevelopmentEnvironment() || Services.MODLOADER.isModLoaded("hideexperimentalwarning")) {
			loadWorld.run();
			ci.cancel();
		}
	}
}
