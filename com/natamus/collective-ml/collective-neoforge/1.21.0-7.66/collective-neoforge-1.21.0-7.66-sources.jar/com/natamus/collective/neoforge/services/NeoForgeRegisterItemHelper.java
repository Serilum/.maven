package com.natamus.collective.neoforge.services;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective.services.helpers.RegisterItemHelper;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.function.Supplier;

public class NeoForgeRegisterItemHelper implements RegisterItemHelper {
	private final HashMap<String, DeferredRegister.Items> deferredItemRegisterMap = new HashMap<String, DeferredRegister.Items>();
	private static final List<Pair<ResourceKey<CreativeModeTab>, Item>> creativeInventoryItemPairs = new ArrayList<Pair<ResourceKey<CreativeModeTab>, Item>>();

    @Override
	public <T extends Item> Item registerAndGetItem(Object modEventBusObject, ResourceLocation resourceLocation, Supplier<T> itemSupplier, @Nullable ResourceKey<CreativeModeTab> creativeModeTabResourceKey) {
		String namespace = resourceLocation.getNamespace();
		if (!deferredItemRegisterMap.containsKey(namespace)) {
			DeferredRegister.Items deferredItemRegister = DeferredRegister.createItems(namespace);
			deferredItemRegister.register((IEventBus)modEventBusObject);
			deferredItemRegisterMap.put(namespace, deferredItemRegister);
		}

		DeferredItem<Item> deferredItemObject = deferredItemRegisterMap.get(namespace).register(resourceLocation.getPath(), itemSupplier);
		Item deferredItem = deferredItemObject.get();

		if (creativeModeTabResourceKey != null) {
			creativeInventoryItemPairs.add(Pair.of(creativeModeTabResourceKey, deferredItem));
		}

		return deferredItem;
	}

	public static void addItemsToCreativeInventory(BuildCreativeModeTabContentsEvent e) {
		for (Pair<ResourceKey<CreativeModeTab>, Item> tabPair : creativeInventoryItemPairs) {
			if (e.getTabKey().equals(tabPair.getFirst())) {
				e.accept(tabPair.getSecond());
			}
		}
	}
}