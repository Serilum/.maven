package com.natamus.collective.neoforge.services;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective.services.Services;
import com.natamus.collective.services.helpers.RegisterBlockHelper;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.function.Supplier;

public class NeoForgeRegisterBlockHelper implements RegisterBlockHelper {
	private final HashMap<String, DeferredRegister.Blocks> deferredBlockRegisterMap = new HashMap<String, DeferredRegister.Blocks>();

    @Override
	public <T extends Block> Pair<Block, BlockItem> registerAndGetBlockPair(ResourceLocation resourceLocation, Supplier<T> blockSupplier, @Nullable ResourceKey<CreativeModeTab> creativeModeTabResourceKey) {
		String namespace = resourceLocation.getNamespace();
		if (!deferredBlockRegisterMap.containsKey(namespace)) {
			deferredBlockRegisterMap.put(namespace, DeferredRegister.createBlocks(namespace));
		}

		DeferredBlock<Block> deferredBlockObject = deferredBlockRegisterMap.get(namespace).register(resourceLocation.getPath(), blockSupplier);
		Block deferredBlock = deferredBlockObject.get();

		Item deferredItem = Services.REGISTERITEM.registerAndGetItem(resourceLocation, () -> new BlockItem(deferredBlock, new Item.Properties()), creativeModeTabResourceKey);

		return Pair.of(deferredBlock, (BlockItem)deferredItem);
	}
}