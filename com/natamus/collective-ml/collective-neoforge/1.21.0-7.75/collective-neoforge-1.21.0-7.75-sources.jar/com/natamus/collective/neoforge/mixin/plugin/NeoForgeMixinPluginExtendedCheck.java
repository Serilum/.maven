package com.natamus.collective.neoforge.mixin.plugin;

import net.neoforged.fml.loading.LoadingModList;
import net.neoforged.fml.loading.moddiscovery.ModFileInfo;

public class NeoForgeMixinPluginExtendedCheck {
	@SuppressWarnings("UnstableApiUsage")
	public static boolean enableMixinLoad(String targetClassName, String mixinClassName) {
		System.out.println("\n!!! NEOFORGE enableMixinLoad");
		System.out.println("targetClassName: " + targetClassName);
		System.out.println("mixinClassName: " + mixinClassName);

		String[] pSpl = mixinClassName.split("\\.");
		if (pSpl.length < 3) {
			System.out.println("pSpl length < 3");
			return true;
		}

		String modId = pSpl[2].split("_")[0];
		System.out.println("CHECKING MOD (ID): " + modId);

		LoadingModList modListInstance = LoadingModList.get();
		if (modListInstance != null) {
			System.out.println("modListInstance not null.");
			ModFileInfo modFileInfo = modListInstance.getModFileById(modId);

			if (modFileInfo != null) {
				// Get the location of the mod
				String location = modFileInfo.getFile().getFilePath().toString();
				System.out.println("Mod Location: " + location);

				// Check if the mod is jar-in-jar'd
				if (location.contains("jarjar")) {
					System.out.println("The mod is jar-in-jar'd.");
				} else {
					System.out.println("The mod is not jar-in-jar'd.");
				}
			} else {
				System.out.println("ModFileInfo is null.");
			}
		}
		else {
			System.out.println("modListInstance is null");
		}


		return true;
	}
}
