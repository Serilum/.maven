package com.natamus.collective.functions;

import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;
import java.net.URI;
import java.net.URISyntaxException;

public class MessageFunctions {
    public static void sendMessage(class_2168 source, class_5250 message) {
        sendMessage(source, message, false);
    }
    public static void sendMessage(class_1657 player, class_5250 message) {
        sendMessage(player, message, false);
    }

    public static void sendMessage(class_2168 source, String m, class_124 colour) {
        sendMessage(source, m, colour, false);
    }
    public static void sendMessage(class_1657 player, String m, class_124 colour) {
        sendMessage(player, m, colour, false);
    }

    public static void sendMessage(class_2168 source, String m, class_124 colour, boolean emptyline) {
        sendMessage(source, m, colour, emptyline, "");
    }
    public static void sendMessage(class_1657 player, String m, class_124 colour, boolean emptyline) {
        sendMessage(player, m, colour, emptyline, "");
    }

    public static void sendMessage(class_2168 source, String m, class_124 colour, String url) {
        sendMessage(source, m, colour, false, url);
    }
    public static void sendMessage(class_1657 player, String m, class_124 colour, String url) {
        sendMessage(player, m, colour, false, url);
    }

    public static void sendMessage(class_2168 source, String m, class_124 colour, boolean emptyline, String url) {
        if (m.isEmpty()) {
            return;
        }

        class_5250 message = class_2561.method_43470(m);
        message.method_27692(colour);
        if (m.contains("http") || !url.isEmpty()) {
            if (url.isEmpty()) {
                for (String word : m.split(" ")) {
                    if (word.contains("http")) {
                        url = word;
                        break;
                    }
                }
            }

            if (!url.isEmpty()) {
                try {
                    class_2583 clickstyle = message.method_10866().method_10958(new class_2558.class_10608(new URI(url)));
                    message.method_27696(clickstyle);
                }
                catch (URISyntaxException ignored) { }
            }
        }
        sendMessage(source, message, emptyline);
    }
    public static void sendMessage(class_2168 source, class_5250 message, boolean emptyline) {
        if (emptyline) {
            source.method_9226(() -> {
                return class_2561.method_43470("");
            }, false);
        }

        source.method_9226(() -> {
            return message;
        }, false);
    }

    public static void sendMessage(class_1657 player, String m, class_124 colour, boolean emptyline, String url) {
        if (m.isEmpty()) {
            return;
        }

        class_5250 message = class_2561.method_43470(m);
        message.method_27692(colour);
        if (m.contains("http") || !url.isEmpty()) {
            if (url.isEmpty()) {
                for (String word : m.split(" ")) {
                    if (word.contains("http")) {
                        url = word;
                        break;
                    }
                }
            }

            if (!url.isEmpty()) {
                try {
                    class_2583 clickstyle = message.method_10866().method_10958(new class_2558.class_10608(new URI(url)));
                    message.method_27696(clickstyle);
                }
                catch (URISyntaxException ignored) { }
            }
        }

        sendMessage(player, message, emptyline);
    }
    public static void sendMessage(class_1657 player, class_5250 message, boolean emptyline) {
        if (player.method_73183().method_8608()) {
            return;
        }

        class_3222 serverPlayer = (class_3222)player;
        if (emptyline) {
            serverPlayer.method_64398(class_2561.method_43470(""));
        }

        serverPlayer.method_64398(message);
    }

    public static void sendTranslatableMessage(class_2168 source, String key, class_124 colour, Object... args) {
        sendMessage(source, class_2561.method_43469(key, args).method_27692(colour));
    }
    public static void sendTranslatableMessage(class_1657 player, String key, class_124 colour, Object... args) {
        sendMessage(player, class_2561.method_43469(key, args).method_27692(colour));
    }

    public static void sendTranslatableMessage(class_2168 source, String key, boolean emptyLine, class_124 colour, Object... args) {
        sendMessage(source, class_2561.method_43469(key, args).method_27692(colour), emptyLine);
    }
    public static void sendTranslatableMessage(class_1657 player, String key, boolean emptyLine, class_124 colour, Object... args) {
        sendMessage(player, class_2561.method_43469(key, args).method_27692(colour), emptyLine);
    }

    public static void sendTranslatableMessage(class_2168 source, String indent, String key, class_124 colour, Object... args) {
        sendMessage(source, class_2561.method_43470(indent).method_10852(class_2561.method_43469(key, args)).method_27692(colour));
    }
    public static void sendTranslatableMessage(class_1657 player, String indent, String key, class_124 colour, Object... args) {
        sendMessage(player, class_2561.method_43470(indent).method_10852(class_2561.method_43469(key, args)).method_27692(colour));
    }

    public static void broadcastMessage(class_1937 world, String m, class_124 colour) {
        if (m.isEmpty()) {
            return;
        }

        class_5250 message = class_2561.method_43470(m);
        message.method_27692(colour);
        broadcastMessage(world, message);
    }
    public static void broadcastMessage(class_1937 world, class_5250 message) {
        MinecraftServer server = world.method_8503();
        if (server == null) {
            return;
        }

        for (class_1657 player : server.method_3760().method_14571()) {
            sendMessage(player, message);
        }
    }

    public static void sendMessageToPlayersAround(class_1937 world, class_2338 p, int radius, String message, class_124 colour) {
        if (message.isEmpty()) {
            return;
        }

        for (class_1297 around : world.method_8335(null, new class_238(p.method_10263() - radius, p.method_10264() - radius, p.method_10260() - radius, p.method_10263() + radius, p.method_10264() + radius, p.method_10260() + radius))) {
            if (around instanceof class_1657) {
                sendMessage((class_1657) around, message, colour);
            }
        }
    }
    public static void sendMessageToPlayersAround(class_1937 world, class_2338 p, int radius, class_5250 message) {
        for (class_1297 around : world.method_8335(null, new class_238(p.method_10263() - radius, p.method_10264() - radius, p.method_10260() - radius, p.method_10263() + radius, p.method_10264() + radius, p.method_10260() + radius))) {
            if (around instanceof class_1657) {
                sendMessage((class_1657) around, message);
            }
        }
    }
}