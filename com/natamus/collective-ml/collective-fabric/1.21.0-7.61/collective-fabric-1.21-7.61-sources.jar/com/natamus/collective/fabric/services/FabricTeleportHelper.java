package com.natamus.collective.fabric.services;

import com.natamus.collective.services.helpers.TeleportHelper;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class FabricTeleportHelper implements TeleportHelper {
    @Override
    public boolean teleportEntity(class_1297 entity, class_3218 serverLevel, class_2338 targetPos) {
        return entity.method_48105(serverLevel, targetPos.method_10263(), targetPos.method_10264(), targetPos.method_10260(), null, entity.method_36454(), entity.method_36455());
    }
}
