package com.natamus.collective.services.helpers;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public interface TeleportHelper {
    boolean teleportEntity(class_1297 entity, class_3218 serverLevel, class_2338 targetPos);
}