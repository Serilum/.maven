package com.natamus.collective.globalcallbacks;

import com.natamus.collective.implementations.event.Event;
import com.natamus.collective.implementations.event.EventFactory;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class GlobalCropCallback {
	private GlobalCropCallback() { }

    public static final Event<On_Bone_Meal_Apply> ON_BONE_MEAL_APPLY = EventFactory.createArrayBacked(On_Bone_Meal_Apply.class, callbacks -> (player, world, pos, state, stack) -> {
        for (On_Bone_Meal_Apply callback : callbacks) {
        	if (!callback.onBoneMealApply(player, world, pos, state, stack)) {
        		return false;
        	}
        }

        return true;
    });

	@FunctionalInterface
	public interface On_Bone_Meal_Apply {
		 boolean onBoneMealApply(class_1657 player, class_1937 world, class_2338 pos, class_2680 state, class_1799 stack);
	}
}
