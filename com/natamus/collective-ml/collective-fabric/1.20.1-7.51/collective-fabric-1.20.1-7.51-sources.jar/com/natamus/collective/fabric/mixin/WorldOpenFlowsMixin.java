package com.natamus.collective.fabric.mixin;

import com.natamus.collective.services.Services;
import net.minecraft.class_7196;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value = class_7196.class, priority = 1001)
public class WorldOpenFlowsMixin {
	@ModifyVariable(method = "doLoadLevel", at = @At(value= "STORE"), ordinal = 3)
	public boolean loadLevel_bl2(boolean isLifeCycleStable) {
		return !Services.MODLOADER.isDevelopmentEnvironment() && !Services.MODLOADER.isModLoaded("hideexperimentalwarning");
	}
}
