package com.natamus.collective.functions;

import com.natamus.collective.config.CollectiveConfigHandler;
import com.natamus.collective.data.GlobalVariables;
import com.natamus.collective.fakeplayer.FakePlayer;
import com.natamus.collective.fakeplayer.FakePlayerFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_173;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_181;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_243;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3468;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8567;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

public class ItemFunctions {
	public static void generateEntityDropsFromLootTable(class_1937 level) {
		MinecraftServer server = level.method_8503();
		if (server == null) {
			return;
		}
		
		GlobalVariables.entitydrops = new HashMap<class_1299<?>, List<class_1792>>();
		
		FakePlayer fakeplayer = FakePlayerFactory.getMinecraft((class_3218)level);
		class_243 vec = new class_243(0, 0, 0);
		
		class_1799 lootingsword = new class_1799(class_1802.field_8802, 1);
		lootingsword.method_7978(level.method_30349().method_30530(class_7924.field_41265).method_40290(class_1893.field_9110), 10);
		fakeplayer.method_5673(class_1304.field_6173, lootingsword);
		
		Collection<Entry<class_5321<class_1299<?>>, class_1299<?>>> entitytypes = level.method_30349().method_30530(class_7924.field_41266).method_29722();
		for (Entry<class_5321<class_1299<?>>, class_1299<?>> entry : entitytypes) {
			class_1299<?> type = entry.getValue();
			if (type == null) {
				continue;
			}
			class_1297 entity = type.method_5883(level);
			if (!(entity instanceof class_1309)) {
				continue;
			}
			
			class_1309 le = (class_1309)entity;
			class_5321<class_52> lootlocation = le.method_5864().method_16351();
			
			class_52 loottable = server.method_58576().method_58295(lootlocation);
			class_8567 lootParams = new class_8567.class_8568((class_3218)level)
	                .method_51871(1000000F)
	                .method_51874(class_181.field_1226, entity)
	                .method_51874(class_181.field_24424, vec)
	                .method_51874(class_181.field_1230, fakeplayer)
	                .method_51874(class_181.field_1231, level.method_48963().method_48802(fakeplayer))
	                .method_51875(class_173.field_1173);
			
			List<class_1792> alldrops = new ArrayList<class_1792>();
			for (int n = 0; n < CollectiveConfigHandler.loopsAmountUsedToGetAllEntityDrops; n++) {
				List<class_1799> newdrops = loottable.method_51878(lootParams);
				for (class_1799 newdrop : newdrops) {
					class_1792 newitem = newdrop.method_7909();
					if (!alldrops.contains(newitem) && !newitem.equals(class_1802.field_8162)) {
						alldrops.add(newitem);
					}
				}
			}
			
			GlobalVariables.entitydrops.put(type, alldrops);
		}
	}
	
	public static void shrinkGiveOrDropItemStack(class_1657 player, class_1268 hand, class_1799 used, class_1799 give) {
		used.method_7934(1);
		
		if (used.method_7960()) {
			class_1792 giveitem = give.method_7909();
			int maxstacksize = give.method_7914();
			List<class_1799> inventory = player.method_31548().field_7547;
			
			boolean increased = false;
			for (class_1799 slot : inventory) {
				if (slot.method_7909().equals(giveitem)) {
					int slotcount = slot.method_7947();
					if (slotcount < maxstacksize) {
						slot.method_7939(slotcount + 1);
						increased = true;
						break;
					}
				}
			}
			
			if (!increased) {
				player.method_6122(hand, give);
			}
		}
		else if (!player.method_31548().method_7394(give)) {
			player.method_7328(give, false);
		}
	}
	
	public static void giveOrDropItemStack(class_1657 player, class_1799 give) {
		if (!player.method_31548().method_7394(give)) {
			player.method_7328(give, false);
		}
	}

	public static void itemHurtBreakAndEvent(class_1799 itemStack, class_3222 player, class_1268 hand, int damage) {
		class_1937 level = player.method_37908();
		if (level.field_9236) {
			return;
		}

		if (!(player.method_31549().field_7477)) {
			if (itemStack.method_7963()) {
				itemStack.method_7956(damage, (class_3218)level, player, (class_1792 item) -> {
					//CollectiveItemEvents.ON_ITEM_DESTROYED.invoker().onItemDestroyed(player, itemStack, hand); // TODO

					itemStack.method_7934(1);
					itemStack.method_7974(0);

					player.method_7259(class_3468.field_15383.method_14956(item));
				});
			}
		}
	}
	
	public static boolean isStoneTypeItem(class_1792 item) {
		return GlobalVariables.stoneblockitems.contains(item);
	}
	
	public static String itemToReadableString(class_1792 item, int amount) {
		String itemstring;
		String translationkey = item.method_7876();
		if (translationkey.contains("block.")) {
			return BlockFunctions.blockToReadableString(class_2248.method_9503(item), amount);
		}
		
		String[] itemspl = translationkey.replace("item.", "").split("\\.");
		if (itemspl.length > 1) {
			itemstring = itemspl[1];
		}
		else {
			itemstring = itemspl[0];
		}
		
		itemstring = itemstring.replace("_", " ");
		if (amount > 1) {
			itemstring = itemstring + "s";
		}
		
		return itemstring;
	}
	public static String itemToReadableString(class_1792 item) {
		return itemToReadableString(item, 1);
	}

	public static String getNBTStringFromItemStack(class_1937 level, class_1799 itemStack) {
		return getNBTStringFromItemStack(level, itemStack, true);
	}
	public static String getNBTStringFromItemStack(class_1937 level, class_1799 itemStack, boolean shouldSanitize) {
		class_2520 nbt = itemStack.method_57358(level.method_30349());

		String nbtstring = nbt.toString();
		if (shouldSanitize) {
			nbtstring = nbtstring.replace(" : ", ": ");
		}

		return nbtstring;
	}

	public static void setItemCategory(class_1792 item, class_1761 category) { }
}