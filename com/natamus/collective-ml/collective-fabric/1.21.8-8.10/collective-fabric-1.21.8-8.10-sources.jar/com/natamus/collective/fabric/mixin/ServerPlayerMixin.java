package com.natamus.collective.fabric.mixin;

import com.natamus.collective.fabric.callbacks.CollectiveItemEvents;
import com.natamus.collective.fabric.callbacks.CollectivePlayerEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_5454;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_3222.class, priority = 1001)
public class ServerPlayerMixin {
	@Inject(method = "tick()V", at = @At(value = "HEAD"))
	public void ServerPlayer_tick(CallbackInfo ci) {
		class_3222 serverPlayer = (class_3222)(Object)this;

		CollectivePlayerEvents.PLAYER_TICK.invoker().onTick(serverPlayer.method_51469(), serverPlayer);
	}
	
	@Inject(method = "die(Lnet/minecraft/world/damagesource/DamageSource;)V", at = @At(value = "HEAD"))
	public void ServerPlayer_die(class_1282 damageSource, CallbackInfo ci) {
		class_3222 serverPlayer = (class_3222)(Object)this;

		CollectivePlayerEvents.PLAYER_DEATH.invoker().onDeath(serverPlayer.method_51469(), serverPlayer);
	}
	
	@Inject(method = "teleport(Lnet/minecraft/world/level/portal/TeleportTransition;)Lnet/minecraft/server/level/ServerPlayer;", at = @At(value = "RETURN"))
	public void ServerPlayer_teleport(class_5454 teleportTransition, CallbackInfoReturnable<class_3222> cir) {
		class_3222 serverPlayer = (class_3222)(Object)this;
		
		CollectivePlayerEvents.PLAYER_CHANGE_DIMENSION.invoker().onChangeDimension(serverPlayer.method_51469(), serverPlayer);
	}
	
	@Inject(method = "drop(Lnet/minecraft/world/item/ItemStack;ZZ)Lnet/minecraft/world/entity/item/ItemEntity;", at = @At(value = "TAIL"))
	private void ServerPlayer_drop(class_1799 itemStack, boolean bl, boolean bl2, CallbackInfoReturnable<class_1542> ci) {
		class_3222 serverPlayer = (class_3222)(Object)this;
		CollectiveItemEvents.ON_ITEM_TOSSED.invoker().onItemTossed(serverPlayer, itemStack);
	}
}
