package com.natamus.collective.events;

import com.mojang.datafixers.util.Pair;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_310;
import net.minecraft.class_3738;

public class CollectiveClientEvents {
    public static CopyOnWriteArrayList<Pair<Integer, Runnable>> scheduledClientRunnables = new CopyOnWriteArrayList<>();

    public static int clientTickCount = 0;
    public static void onClientTick() {
		for (Pair<Integer, Runnable> pair : scheduledClientRunnables) {
			if (pair.getFirst() <= clientTickCount) {
                class_310.method_1551().execute(new class_3738(clientTickCount, pair.getSecond()));
				scheduledClientRunnables.remove(pair);
			}
		}

        clientTickCount++;
	}
}