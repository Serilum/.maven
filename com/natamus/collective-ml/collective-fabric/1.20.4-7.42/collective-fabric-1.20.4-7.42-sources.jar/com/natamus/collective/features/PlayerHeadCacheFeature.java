package com.natamus.collective.features;

import com.mojang.authlib.GameProfile;
import com.natamus.collective.data.FeatureFlags;
import com.natamus.collective.functions.HeadFunctions;
import java.util.HashMap;
import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3218;

public class PlayerHeadCacheFeature {
	public static HashMap<String, class_1799> cachedPlayerHeadsMap = new HashMap<String, class_1799>();
	public static HashMap<String, UUID> cachedPlayerNamesMap = new HashMap<String, UUID>();
	public static HashMap<UUID, String> cachedPlayerUUIDsMap = new HashMap<UUID, String>();
	public static HashMap<UUID, GameProfile> cachedGameProfileMap = new HashMap<UUID, GameProfile>();

	public static class_1799 cachePlayer(class_1657 player) {
		return cachePlayer(player.method_5477().getString(), player.method_7334());
	}
	public static class_1799 cachePlayer(class_3218 serverLevel, String playerName) {
		if (cachedPlayerHeadsMap.containsKey(playerName)) {
			return cachedPlayerHeadsMap.get(playerName).method_7972();
		}

		class_1799 headStack = HeadFunctions.getNewPlayerHead(serverLevel, playerName, 1);
		if (headStack == null) {
			return null;
		}

		cachedPlayerHeadsMap.put(playerName, headStack);

		return headStack.method_7972();
	}
	public static class_1799 cachePlayer(String playerName, GameProfile gameProfile) {
		if (cachedPlayerHeadsMap.containsKey(playerName)) {
			return cachedPlayerHeadsMap.get(playerName).method_7972();
		}

		class_1799 headStack = HeadFunctions.getNewPlayerHead(gameProfile, 1);
		if (headStack == null) {
			return null;
		}

		cachedPlayerHeadsMap.put(gameProfile.getName(), headStack);

		return headStack.method_7972();
	}

	public static class_1799 getPlayerHeadStackFromCache(class_1657 player) {
		return cachePlayer(player);
	}
	public static class_1799 getPlayerHeadStackFromCache(class_3218 serverLevel, String playerName) {
		if (cachedPlayerHeadsMap.containsKey(playerName)) {
			return cachedPlayerHeadsMap.get(playerName).method_7972();
		}

		return cachePlayer(serverLevel, playerName);
	}

	public static boolean isHeadCachingEnabled() {
		return FeatureFlags.shouldCachePlayerHeads;
	}

	public static void enableHeadCaching() {
		FeatureFlags.shouldCachePlayerHeads = true;
	}

	public static boolean resetPlayerHeadCache() {
		cachedPlayerHeadsMap = new HashMap<String, class_1799>();
		return true;
	}


	// Backwards compatibility. Will be removed in a later version.
	@Deprecated
	public static class_1799 getPlayerHeadStackFromCache(String playerName) {
		if (cachedPlayerHeadsMap.containsKey(playerName)) {
			return cachedPlayerHeadsMap.get(playerName).method_7972();
		}

		class_1799 headStack = HeadFunctions.getPlayerHead(playerName, 1);
		if (headStack == null) {
			return null;
		}

		cachedPlayerHeadsMap.put(playerName, headStack);

		return headStack.method_7972();
	}
}
