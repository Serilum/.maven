package com.natamus.collective.schematic;

import com.mojang.datafixers.util.Pair;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class ParsedSchematicObject {
	public Schematic schematic;
	public List<Pair<class_2338, class_2680>> blocks;
	public List<Pair<class_2338, class_1297>> entities;
	public List<class_2338> blockEntityPositions;
	public String parseMessageString;
	public boolean parsedCorrectly;

	public int offsetX;
	public int offsetY;
	public int offsetZ;

	public ParsedSchematicObject(Schematic _schematic, List<Pair<class_2338, class_2680>> _blocks, List<Pair<class_2338, class_1297>> _entities, List<class_2338> _blockEntityPositions, String _parseMessageString, boolean _parsedCorrectly) {
		schematic = _schematic;
		blocks = _blocks;
		entities = _entities;
		blockEntityPositions = _blockEntityPositions;
		parseMessageString = _parseMessageString;
		parsedCorrectly = _parsedCorrectly;

		offsetX = _schematic.getOffsetX();
		offsetY = _schematic.getOffsetY();
		offsetZ = _schematic.getOffsetZ();
	}

	public void placeBlockEntitiesInWorld(class_1937 level) {
		for (class_2338 pos : blockEntityPositions) {
			placeBlockEntityInWorld(level, pos);
		}
	}

	public void placeBlockEntityInWorld(class_1937 level, class_2338 pos) {
		int blockEntityIndex = blockEntityPositions.indexOf(pos);
		if (blockEntityIndex < 0) {
			return;
		}

		class_2586 blockEntity = level.method_8321(pos);
		if (blockEntity == null) {
			return;
		}

		class_2487 compoundTag = schematic.getBlockEntities().get(blockEntityIndex);
		blockEntity.method_58690(compoundTag, level.method_30349());
		blockEntity.method_5431();
	}

	public List<Pair<class_2338, class_2586>> getBlockEntities(class_1937 level) {
		List<Pair<class_2338, class_2586>> blockEntities = new ArrayList<Pair<class_2338, class_2586>>();
		for (class_2338 pos : blockEntityPositions) {
			blockEntities.add(new Pair<class_2338, class_2586>(pos, level.method_8321(pos)));
		}
		return blockEntities;
	}
}