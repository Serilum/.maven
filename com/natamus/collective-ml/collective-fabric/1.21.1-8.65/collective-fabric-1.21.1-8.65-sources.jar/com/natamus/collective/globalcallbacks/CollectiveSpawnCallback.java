package com.natamus.collective.globalcallbacks;

import com.natamus.collective.implementations.event.Event;
import com.natamus.collective.implementations.event.EventFactory;
import net.minecraft.class_1308;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3730;

public class CollectiveSpawnCallback {
	private CollectiveSpawnCallback() { }

	public static final Event<On_Mob_Check_Spawn> ON_MOB_CHECK_SPAWN = EventFactory.createArrayBacked(On_Mob_Check_Spawn.class, callbacks -> (mob, level, spawnerPos, spawnReason) -> {
		for (On_Mob_Check_Spawn callback : callbacks) {
			if (!callback.onMobCheckSpawn(mob, level, spawnerPos, spawnReason)) {
				return false;
			}
		}

		return true;
	});

	@FunctionalInterface
	public interface On_Mob_Check_Spawn {
		 boolean onMobCheckSpawn(class_1308 mob, class_3218 level, class_2338 spawnerPos, class_3730 spawnReason);
	}
}
