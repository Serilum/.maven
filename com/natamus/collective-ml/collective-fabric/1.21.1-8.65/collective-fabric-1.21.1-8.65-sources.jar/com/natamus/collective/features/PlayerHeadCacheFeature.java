package com.natamus.collective.features;

import com.mojang.authlib.GameProfile;
import com.natamus.collective.data.FeatureFlags;
import com.natamus.collective.data.GlobalCaches;
import com.natamus.collective.functions.HeadFunctions;
import java.util.HashMap;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3218;

public class PlayerHeadCacheFeature {
	public static class_1799 cachePlayer(class_1657 player) {
		return cachePlayer(player.method_5477().getString(), player.method_7334());
	}
	public static class_1799 cachePlayer(class_3218 serverLevel, String playerName) {
		if (GlobalCaches.cachedPlayerHeadsMap.containsKey(playerName)) {
			return GlobalCaches.cachedPlayerHeadsMap.get(playerName).method_7972();
		}

		class_1799 headStack = HeadFunctions.getNewPlayerHead(serverLevel, playerName, 1);
		if (headStack == null) {
			return null;
		}

		GlobalCaches.cachedPlayerHeadsMap.put(playerName, headStack);

		return headStack.method_7972();
	}
	public static class_1799 cachePlayer(String playerName, GameProfile gameProfile) {
		if (GlobalCaches.cachedPlayerHeadsMap.containsKey(playerName)) {
			return GlobalCaches.cachedPlayerHeadsMap.get(playerName).method_7972();
		}

		class_1799 headStack = HeadFunctions.getNewPlayerHead(gameProfile, 1);
		if (headStack == null) {
			return null;
		}

		GlobalCaches.cachedPlayerHeadsMap.put(gameProfile.getName(), headStack);

		return headStack.method_7972();
	}

	public static class_1799 getPlayerHeadStackFromCache(class_1657 player) {
		return cachePlayer(player);
	}
	public static class_1799 getPlayerHeadStackFromCache(class_3218 serverLevel, String playerName) {
		if (GlobalCaches.cachedPlayerHeadsMap.containsKey(playerName)) {
			return GlobalCaches.cachedPlayerHeadsMap.get(playerName).method_7972();
		}

		return cachePlayer(serverLevel, playerName);
	}

	public static boolean isHeadCachingEnabled() {
		return FeatureFlags.shouldCachePlayerHeads;
	}

	public static void enableHeadCaching() {
		FeatureFlags.shouldCachePlayerHeads = true;
	}

	public static boolean resetPlayerHeadCache() {
		GlobalCaches.cachedPlayerHeadsMap = new HashMap<>();
		return true;
	}
}
