package com.natamus.collective.data;

import com.mojang.authlib.GameProfile;
import java.lang.ref.WeakReference;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2586;
import net.minecraft.class_2591;

public class GlobalCaches {
	public static List<class_2591<?>> blockEntitiesToCache = new ArrayList<>();
	public static List<class_2591<?>> serverSideBlockEntityTypes = new ArrayList<>();
	public static List<class_2591<?>> clientSideBlockEntityTypes = new ArrayList<>();
	public static HashMap<class_2591<?>, WeakHashMap<class_1937, CopyOnWriteArrayList<WeakReference<class_2586>>>> cachedBlockEntities = new HashMap<>();

	public static HashMap<String, class_1799> cachedPlayerHeadsMap = new HashMap<>();
	public static HashMap<String, UUID> cachedPlayerNamesMap = new HashMap<>();
	public static HashMap<UUID, String> cachedPlayerUUIDsMap = new HashMap<>();
	public static HashMap<UUID, GameProfile> cachedGameProfileMap = new HashMap<>();

	public static final Map<String, Boolean> bundleConfigCache = new ConcurrentHashMap<>();
	public static final Map<String, Boolean> modEnabledCache = new ConcurrentHashMap<>();

	public static String serverTranslationPackHash = null;
}
