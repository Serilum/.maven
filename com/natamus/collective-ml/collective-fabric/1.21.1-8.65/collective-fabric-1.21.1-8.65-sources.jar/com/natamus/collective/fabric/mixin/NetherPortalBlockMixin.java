package com.natamus.collective.fabric.mixin;

import com.natamus.collective.events.CollectiveSpawnCheckEvents;
import net.minecraft.class_2338;
import net.minecraft.class_2423;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_2423.class, priority = 1001)
public class NetherPortalBlockMixin {
	@Inject(method = "randomTick(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/util/RandomSource;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/EntityType;spawn(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/MobSpawnType;)Lnet/minecraft/world/entity/Entity;"), cancellable = true)
	private void randomTick(class_2680 state, class_3218 serverLevel, class_2338 pos, class_5819 random, CallbackInfo ci) {
		if (!CollectiveSpawnCheckEvents.onNetherPortalSpawn(serverLevel, pos.method_10084())) {
			ci.cancel();
		}
	}
}
