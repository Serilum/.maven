package com.natamus.collective.config.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_6379;

public class DuskConfigIdRow extends class_4265.class_4266<DuskConfigIdRow> {
	private final class_1799 icon;
	private final DuskConfigModIcons modIcon;
	private final String name;
	private final String id;
	private final int colour;
	private final class_4185 button;
	private final class_342 amountBox;

	public DuskConfigIdRow(class_1799 icon, DuskConfigModIcons modIcon, String name, String id, int colour, class_2561 buttonLabel, class_4185.class_4241 onPress) {
		this(icon, modIcon, name, id, colour, buttonLabel, onPress, null);
	}
	public DuskConfigIdRow(class_1799 icon, DuskConfigModIcons modIcon, String name, String id, int colour, class_2561 buttonLabel, class_4185.class_4241 onPress, class_342 amountBox) {
		this.icon = icon;
		this.modIcon = modIcon;
		this.name = name;
		this.id = id;
		this.colour = colour;
		this.button = class_4185.method_46430(buttonLabel, onPress).method_46437(20, 20).method_46431();
		this.amountBox = amountBox;
	}

	@Override
	public void method_25343(@NotNull class_332 guiGraphics, int index, int y, int x, int width, int height, int mouseX, int mouseY, boolean hovered, float partialTick) {
		int right = x + width - 4;

		if (!icon.method_7960()) {
			guiGraphics.method_51427(icon, x - 2, y + 2);
		}
		else if (modIcon != null) {
			RenderSystem.enableBlend();
			guiGraphics.method_25293(modIcon.texture, x - 2, y + 2, 16, 16, 0, 0, modIcon.width, modIcon.height, modIcon.width, modIcon.height);
			RenderSystem.disableBlend();
		}

		class_327 font = class_310.method_1551().field_1772;
		int labelWidth = right - x - 48;
		if (amountBox != null) {
			labelWidth -= amountBox.method_25368() + 4;
		}
		if (name.isEmpty()) {
			guiGraphics.method_25303(font, DuskConfigRow.fitLabel(font, id, labelWidth), x + 20, y + 6, colour);
		}
		else {
			guiGraphics.method_25303(font, DuskConfigRow.fitLabel(font, name, labelWidth), x + 20, y + 1, colour);

			guiGraphics.method_51448().method_22903();
			guiGraphics.method_51448().method_46416(x + 23, y + 12, 0);
			guiGraphics.method_51448().method_22905(0.75F, 0.75F, 1F);
			guiGraphics.method_25303(font, DuskConfigRow.fitLabel(font, id, (int) (labelWidth / 0.75F)), 0, 0, 0xFF909090);
			guiGraphics.method_51448().method_22909();
		}

		button.method_46421(right - 24);
		button.method_46419(y);
		button.method_25394(guiGraphics, mouseX, mouseY, partialTick);

		if (amountBox != null) {
			amountBox.method_46421(right - 28 - amountBox.method_25368());
			amountBox.method_46419(y);
			amountBox.method_25394(guiGraphics, mouseX, mouseY, partialTick);
		}
	}

	@Override
	public @NotNull List<? extends class_364> method_25396() {
		if (amountBox != null) {
			return List.of(amountBox, button);
		}
		return List.of(button);
	}

	@Override
	public @NotNull List<? extends class_6379> method_37025() {
		if (amountBox != null) {
			return List.of(amountBox, button);
		}
		return List.of(button);
	}
}
