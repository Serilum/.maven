package com.natamus.collective.config.screen;

import com.natamus.collective.config.DuskConfigEntry;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import net.minecraft.class_7529;

public class DuskConfigTextScreen extends DuskConfigBaseScreen {
	private final class_437 parent;
	private final DuskConfigEntry entry;
	private List<class_5481> descriptionLines = new ArrayList<>();
	private String text;
	private int boxX;

	public DuskConfigTextScreen(class_437 parent, DuskConfigEntry entry) {
		super(class_2561.method_43470(entry.getDisplayName()));
		this.parent = parent;
		this.entry = entry;
		this.text = getEntryText();
	}

	private String getEntryText() {
		if (entry.isList()) {
			return entry.getListLines();
		}
		return entry.getText();
	}

	@Override
	protected void method_25426() {
		super.method_25426();

		int boxWidth = Math.min(this.field_22789 - 40, 400);
		boxX = (this.field_22789 - boxWidth) / 2;

		descriptionLines = this.field_22793.method_1728(class_5348.method_29430(String.join(" ", entry.description)), boxWidth);
		int boxTop = 34 + descriptionLines.size() * 10;

		class_7529 textBox = new class_7529(this.field_22793, boxX, boxTop, boxWidth, this.field_22790 - boxTop - 40, class_2561.method_43473(), class_2561.method_43470(entry.getDisplayName()));
		textBox.method_44402(Integer.MAX_VALUE);
		textBox.method_44400(text);
		textBox.method_44401(newText -> text = newText);
		this.method_37063(textBox);
		this.method_48265(textBox);

		addCancelButton(this.field_22789 / 2 - 154, this.field_22790 - 28);
		this.method_37063(class_4185.method_46430(class_5244.field_24334, button -> {
			if (entry.isList()) {
				entry.setListFromLines(text);
			}
			else {
				entry.setValue(text.replaceAll("\\R", " "));
			}
			method_25419();
		}).method_46433(this.field_22789 / 2 + 4, this.field_22790 - 28).method_46437(150, 20).method_46431());
	}

	@Override
	protected boolean hasUnsavedChanges() {
		return !text.equals(getEntryText());
	}

	@Override
	public void method_25419() {
		this.field_22787.method_1507(parent);
	}

	@Override
	public void method_25420(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		if (this.field_22787.field_1687 == null) {
			this.method_57728(guiGraphics, partialTick);
		}

		this.method_57734(partialTick);
	}

	@Override
	public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

		guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 12, 0xFFFFFFFF);

		int y = 30;
		for (class_5481 line : descriptionLines) {
			guiGraphics.method_35720(this.field_22793, line, boxX, y, 0xFFA0A0A0);
			y += 10;
		}
	}
}
