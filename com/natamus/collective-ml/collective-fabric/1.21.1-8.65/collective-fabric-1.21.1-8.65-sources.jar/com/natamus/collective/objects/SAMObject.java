package com.natamus.collective.objects;

import com.natamus.collective.data.GlobalVariables;
import com.natamus.collective.functions.ConfigFunctions;
import java.util.Locale;
import java.util.Optional;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

public class SAMObject {
	public class_1299<?> fromEntityType;
	public class_1299<?> toEntityType;
	public class_1792 itemToHold;

	public double changeChance;
	public boolean onlyFromSpawner;
	public boolean rideNotReplace;
	public boolean onlyOnSurface;
	public boolean onlyBelowSurface;
	public boolean onlyBelowSpecificY;
	public int specificY;

	public String dimensionIds = "";
	public String biomeIds = "";

	public SAMObject(class_1299<?> fromEntityTypeIn, class_1299<?> toEntityTypeIn, class_1792 itemToHoldIn, double changeChanceIn, boolean onlyFromSpawnerIn, boolean rideNotReplaceIn, boolean onlyOnSurfaceIn) {
		new SAMObject(fromEntityTypeIn, toEntityTypeIn, itemToHoldIn, changeChanceIn, onlyFromSpawnerIn, rideNotReplaceIn, onlyOnSurfaceIn, false);
	}
	public SAMObject(class_1299<?> fromEntityTypeIn, class_1299<?> toEntityTypeIn, class_1792 itemToHoldIn, double changeChanceIn, boolean onlyFromSpawnerIn, boolean rideNotReplaceIn, boolean onlyOnSurfaceIn, boolean onlyBelowSurfaceIn) {
		new SAMObject(fromEntityTypeIn, toEntityTypeIn, itemToHoldIn, changeChanceIn, onlyFromSpawnerIn, rideNotReplaceIn, onlyOnSurfaceIn, onlyBelowSurfaceIn, false, Integer.MAX_VALUE);
	}
	public SAMObject(class_1299<?> fromEntityTypeIn, class_1299<?> toEntityTypeIn, class_1792 itemToHoldIn, double changeChanceIn, boolean onlyFromSpawnerIn, boolean rideNotReplaceIn, boolean onlyOnSurfaceIn, boolean onlyBelowSurfaceIn, boolean onlyBelowSpecificYIn, int specificYIn) {
		fromEntityType = fromEntityTypeIn;
		toEntityType = toEntityTypeIn;
		itemToHold = itemToHoldIn;

		changeChance = changeChanceIn;
		onlyFromSpawner = onlyFromSpawnerIn;
		rideNotReplace = rideNotReplaceIn;
		onlyOnSurface = onlyOnSurfaceIn;
		onlyBelowSurface = onlyBelowSurfaceIn;
		onlyBelowSpecificY = onlyBelowSpecificYIn;
		specificY = specificYIn;

		GlobalVariables.globalSAMs.add(this);
		if (!GlobalVariables.activeSAMEntityTypes.contains(fromEntityType)) {
			GlobalVariables.activeSAMEntityTypes.add(fromEntityType);
		}
	}

	public boolean isInAllowedDimension(class_1937 level) {
		if (dimensionIds.isBlank()) {
			return true;
		}
		return ConfigFunctions.isInIdList(dimensionIds, level.method_27983().method_29177().toString());
	}

	public boolean isInAllowedBiome(class_1937 level, class_2338 pos) {
		if (biomeIds.isBlank()) {
			return true;
		}

		class_6880<class_1959> biome = level.method_23753(pos);
		for (String rawEntry : biomeIds.split(",")) {
			String entry = rawEntry.strip().toLowerCase(Locale.ROOT);
			if (!entry.startsWith("#")) {
				continue;
			}

			class_2960 tagLocation = class_2960.method_12829(entry.substring(1));
			if (tagLocation != null && biome.method_40220(class_6862.method_40092(class_7924.field_41236, tagLocation))) {
				return true;
			}
		}

		Optional<class_5321<class_1959>> biomeKey = biome.method_40230();
		if (!biomeKey.isPresent()) {
			return false;
		}
		return ConfigFunctions.isInIdList(biomeIds, biomeKey.get().method_29177().toString());
	}
}
