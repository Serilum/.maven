package com.natamus.collective.fabric.mixin;

import com.natamus.collective.events.CollectiveSpawnCheckEvents;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3769;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_3769.class, priority = 1001)
public class PatrolSpawnerMixin {
	@Inject(method = "spawnPatrolMember(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/util/RandomSource;Z)Z", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/EntityType;create(Lnet/minecraft/world/level/Level;)Lnet/minecraft/world/entity/Entity;"), cancellable = true)
	private void spawnPatrolMember(class_3218 serverLevel, class_2338 pos, class_5819 random, boolean isLeader, CallbackInfoReturnable<Boolean> cir) {
		if (!CollectiveSpawnCheckEvents.onPatrolMemberSpawn(serverLevel, pos)) {
			cir.setReturnValue(false);
		}
	}
}
