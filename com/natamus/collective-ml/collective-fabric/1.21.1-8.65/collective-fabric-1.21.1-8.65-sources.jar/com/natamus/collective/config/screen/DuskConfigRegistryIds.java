package com.natamus.collective.config.screen;

import com.natamus.collective.config.DuskConfigModToggles;
import com.natamus.collective.functions.FilterFunctions;
import com.natamus.collective.functions.StringFunctions;
import com.natamus.collective.services.Services;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_634;
import net.minecraft.class_7923;

public class DuskConfigRegistryIds {
	private static final HashMap<class_1299<?>, class_1826> spawnEggs = new HashMap<>();

	public static List<String> getIds(String registryName) {
		List<String> ids = new ArrayList<>();
		if (registryName.equals("dimension")) {
			addDimensionIds(ids);
		}
		else if (registryName.equals(DuskConfigModToggles.modRegistry)) {
			addModIds(ids);
		}
		else {
			class_2378<?> registry = getRegistry(registryName);
			if (registry != null) {
				for (class_2960 resourceLocation : registry.method_10235()) {
					ids.add(resourceLocation.toString());
				}
			}
		}

		Collections.sort(ids);
		return ids;
	}

	public static List<String> getSuggestedIds(String registryName, String filter) {
		List<String> ids = new ArrayList<>();

		class_2378<?> registry = getRegistry(registryName);
		if (filter.isEmpty() || registry == null) {
			return ids;
		}

		try {
			for (class_2960 resourceLocation : registry.method_10235()) {
				if (FilterFunctions.isInFilter(filter, registry.method_10223(resourceLocation))) {
					ids.add(resourceLocation.toString());
				}
			}
		}
		catch (Exception ignored) {
			ids.clear();
		}

		Collections.sort(ids);
		return ids;
	}

	public static class_1799 getIcon(String registryName, String id) {
		if (registryName.equals(DuskConfigModToggles.modRegistry)) {
			return class_1799.field_8037;
		}

		class_2960 resourceLocation = class_2960.method_12829(id);
		class_2378<?> registry = getRegistry(registryName);
		if (resourceLocation == null || registry == null || !registry.method_10250(resourceLocation)) {
			return class_1799.field_8037;
		}

		Object value = registry.method_10223(resourceLocation);
		if (value instanceof class_1935 itemLike) {
			return new class_1799(itemLike);
		}

		if (value instanceof class_1299<?> entityType) {
			class_1826 spawnEgg = getSpawnEgg(entityType);
			if (spawnEgg != null) {
				return new class_1799(spawnEgg);
			}
		}
		return class_1799.field_8037;
	}

	private static class_1826 getSpawnEgg(class_1299<?> entityType) {
		if (spawnEggs.isEmpty()) {
			for (class_1792 item : class_7923.field_41178) {
				if (item instanceof class_1826 spawnEggItem) {
					spawnEggs.put(spawnEggItem.method_8015(new class_1799(spawnEggItem)), spawnEggItem);
				}
			}
		}
		return spawnEggs.get(entityType);
	}

	public static String getName(String registryName, String id) {
		if (registryName.equals(DuskConfigModToggles.modRegistry)) {
			return Services.MODLOADER.getModName(id);
		}

		class_2960 resourceLocation = class_2960.method_12829(id);
		class_2378<?> registry = getRegistry(registryName);
		if (resourceLocation == null || registry == null || !registry.method_10250(resourceLocation)) {
			return "";
		}

		Object value = registry.method_10223(resourceLocation);
		if (value instanceof class_1792 item) {
			return class_2561.method_43471(item.method_7876()).getString();
		}
		if (value instanceof class_2248 block) {
			return block.method_9518().getString();
		}
		if (value instanceof class_1299<?> entityType) {
			return entityType.method_5897().getString();
		}
		if (value instanceof class_1959) {
			return class_2561.method_43471(resourceLocation.method_42093("biome")).getString();
		}
		return "";
	}

	public static class_2561 getAmountLabel(String registryName, int amount) {
		return class_2561.method_43469("options.generic_value", getRegistryLabel(registryName), amount);
	}

	public static class_2561 getAllLabel(String registryName) {
		return class_2561.method_43469("options.generic_value", getRegistryLabel(registryName), class_2561.method_43471("gui.all"));
	}

	private static class_2561 getRegistryLabel(String registryName) {
		String registryPath = registryName.substring(registryName.indexOf(':') + 1);
		return switch (registryPath) {
			case "item" -> class_2561.method_43471("stat.itemsButton");
			case "block" -> class_2561.method_43471("collective.collective.gui.blocks");
			case "entity_type" -> class_2561.method_43471("collective.collective.gui.entities");
			case "dimension" -> class_2561.method_43471("collective.collective.gui.dimensions");
			case "worldgen/biome" -> class_2561.method_43471("collective.collective.gui.biomes");
			case DuskConfigModToggles.modRegistry -> class_2561.method_43471("collective.collective.gui.mods");
			default -> class_2561.method_43471("collective.collective.gui.entries");
		};
	}

	public static boolean needsWorld(String registryName) {
		return !registryName.equals(DuskConfigModToggles.modRegistry);
	}

	public static class_2561 getFilterLabel(String filter) {
		return switch (filter) {
			case "tools" -> class_2561.method_43471("collective.collective.gui.filtertools");
			case "axes" -> class_2561.method_43471("collective.collective.gui.filteraxes");
			case "pickaxes" -> class_2561.method_43471("collective.collective.gui.filterpickaxes");
			case "shovels" -> class_2561.method_43471("collective.collective.gui.filtershovels");
			case "hoes" -> class_2561.method_43471("collective.collective.gui.filterhoes");
			case "swords" -> class_2561.method_43471("collective.collective.gui.filterswords");
			case "blocks" -> class_2561.method_43471("collective.collective.gui.blocks");
			case "logs" -> class_2561.method_43471("collective.collective.gui.filterlogs");
			case "leaves" -> class_2561.method_43471("collective.collective.gui.filterleaves");
			case "ores" -> class_2561.method_43471("collective.collective.gui.filterores");
			case "mobs" -> class_2561.method_43471("gamerule.category.mobs");
			case "monsters" -> class_2561.method_43471("collective.collective.gui.filtermonsters");
			case "animals" -> class_2561.method_43471("collective.collective.gui.filteranimals");
			default -> class_2561.method_43470(StringFunctions.capitalizeFirst(filter));
		};
	}

	private static class_2378<?> getRegistry(String registryName) {
		class_2960 registryId = class_2960.method_12829(registryName);
		if (registryId == null) {
			return null;
		}

		class_2378<?> builtInRegistry = class_7923.field_41167.method_10223(registryId);
		if (builtInRegistry != null) {
			return builtInRegistry;
		}

		class_634 connection = class_310.method_1551().method_1562();
		if (connection == null) {
			return null;
		}

		Optional<class_2378<Object>> worldRegistry = connection.method_29091().method_33310(class_5321.method_29180(registryId));
		if (worldRegistry.isPresent()) {
			return worldRegistry.get();
		}
		return null;
	}

	private static void addModIds(List<String> ids) {
		ids.addAll(DuskConfigModToggles.getListableModIds());
	}

	private static void addDimensionIds(List<String> ids) {
		class_634 connection = class_310.method_1551().method_1562();
		if (connection == null) {
			return;
		}

		for (class_5321<class_1937> levelKey : connection.method_29356()) {
			ids.add(levelKey.method_29177().toString());
		}
	}
}
