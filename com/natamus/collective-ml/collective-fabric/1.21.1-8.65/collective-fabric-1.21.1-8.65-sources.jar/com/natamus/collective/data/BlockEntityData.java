package com.natamus.collective.data;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1937;
import net.minecraft.class_2586;
import net.minecraft.class_2591;

public class BlockEntityData {
	public static void addBlockEntityToCache(class_2591<?> blockEntityType) {
		addBlockEntityToCache(blockEntityType, true, true);
	}

	public static void addBlockEntityToCache(class_2591<?> blockEntityType, boolean cacheServerSide, boolean cacheClientSide) {
		if (!GlobalCaches.blockEntitiesToCache.contains(blockEntityType)) {
			GlobalCaches.blockEntitiesToCache.add(blockEntityType);
		}

		if (cacheServerSide && !GlobalCaches.serverSideBlockEntityTypes.contains(blockEntityType)) {
			GlobalCaches.serverSideBlockEntityTypes.add(blockEntityType);
		}

		if (cacheClientSide && !GlobalCaches.clientSideBlockEntityTypes.contains(blockEntityType)) {
			GlobalCaches.clientSideBlockEntityTypes.add(blockEntityType);
		}

		if (!GlobalCaches.cachedBlockEntities.containsKey(blockEntityType)) {
			GlobalCaches.cachedBlockEntities.put(blockEntityType, new WeakHashMap<>());
		}
	}

	public static boolean shouldCacheOnSide(class_2591<?> blockEntityType, boolean isClientSide) {
		if (isClientSide) {
			return GlobalCaches.clientSideBlockEntityTypes.contains(blockEntityType);
		}

		return GlobalCaches.serverSideBlockEntityTypes.contains(blockEntityType);
	}

	public static void cacheBlockEntity(class_2591<?> blockEntityType, class_1937 level, class_2586 blockEntity) {
		WeakHashMap<class_1937, CopyOnWriteArrayList<WeakReference<class_2586>>> levelCache = GlobalCaches.cachedBlockEntities.get(blockEntityType);
		if (levelCache == null) {
			return;
		}

		if (!levelCache.containsKey(level)) {
			levelCache.put(level, new CopyOnWriteArrayList<>());
		}

		levelCache.get(level).add(new WeakReference<>(blockEntity));
	}

	public static void uncacheBlockEntity(class_2591<?> blockEntityType, class_1937 level, class_2586 blockEntity) {
		WeakHashMap<class_1937, CopyOnWriteArrayList<WeakReference<class_2586>>> levelCache = GlobalCaches.cachedBlockEntities.get(blockEntityType);
		if (levelCache == null) {
			return;
		}

		CopyOnWriteArrayList<WeakReference<class_2586>> blockEntities = levelCache.get(level);
		if (blockEntities == null) {
			return;
		}

		for (WeakReference<class_2586> reference : blockEntities) {
			class_2586 cachedBlockEntity = reference.get();
			if (cachedBlockEntity == null || cachedBlockEntity.equals(blockEntity)) {
				blockEntities.remove(reference);
			}
		}
	}

	public static List<class_2586> getCachedBlockEntities(class_2591<?> blockEntityType, class_1937 level) {
		List<class_2586> blockEntities = new ArrayList<>();

		WeakHashMap<class_1937, CopyOnWriteArrayList<WeakReference<class_2586>>> levelCache = GlobalCaches.cachedBlockEntities.get(blockEntityType);
		if (levelCache == null) {
			return blockEntities;
		}

		CopyOnWriteArrayList<WeakReference<class_2586>> cachedReferences = levelCache.get(level);
		if (cachedReferences == null) {
			return blockEntities;
		}

		for (WeakReference<class_2586> reference : cachedReferences) {
			class_2586 cachedBlockEntity = reference.get();
			if (cachedBlockEntity == null) {
				cachedReferences.remove(reference);
				continue;
			}

			blockEntities.add(cachedBlockEntity);
		}

		return blockEntities;
	}

	public static void removeLevelFromCache(class_1937 level) {
		if (level == null) {
			return;
		}

		for (WeakHashMap<class_1937, CopyOnWriteArrayList<WeakReference<class_2586>>> levelCache : GlobalCaches.cachedBlockEntities.values()) {
			levelCache.remove(level);
		}
	}
}
