package com.natamus.collective.config.screen;

import org.jetbrains.annotations.NotNull;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.class_1144;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_6382;

public class DuskConfigDragArea extends class_339 {
	private final BiConsumer<Float, Float> onPick;
	private final Consumer<class_332> renderer;

	public DuskConfigDragArea(int x, int y, int width, int height, BiConsumer<Float, Float> onPick, Consumer<class_332> renderer) {
		super(x, y, width, height, class_2561.method_43473());
		this.onPick = onPick;
		this.renderer = renderer;
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		if (!this.field_22763 || !this.field_22764) {
			return false;
		}
		if (!this.method_25351(button) || !this.method_25361(mouseX, mouseY)) {
			return false;
		}

		pick(mouseX, mouseY);
		return true;
	}

	@Override
	protected void method_25349(double mouseX, double mouseY, double dragX, double dragY) {
		pick(mouseX, mouseY);
	}

	private void pick(double mouseX, double mouseY) {
		float fractionX = (float) class_3532.method_15350((mouseX - this.method_46426()) / (this.field_22758 - 1), 0, 1);
		float fractionY = (float) class_3532.method_15350((mouseY - this.method_46427()) / (this.field_22759 - 1), 0, 1);
		onPick.accept(fractionX, fractionY);
	}

	@Override
	protected void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		renderer.accept(guiGraphics);
	}

	@Override
	public void method_25354(@NotNull class_1144 soundManager) { }

	@Override
	protected void method_47399(@NotNull class_6382 narrationElementOutput) { }
}
