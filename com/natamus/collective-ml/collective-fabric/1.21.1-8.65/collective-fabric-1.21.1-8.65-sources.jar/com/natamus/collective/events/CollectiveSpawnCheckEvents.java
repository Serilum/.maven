package com.natamus.collective.events;

import com.natamus.collective.globalcallbacks.CollectiveSpawnCallback;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3730;

public class CollectiveSpawnCheckEvents {
	public static boolean onMobCheckSpawn(class_1308 mob, class_3218 level, class_2338 spawnerPos, class_3730 spawnReason) {
		if (mob == null) {
			return true;
		}

		return CollectiveSpawnCallback.ON_MOB_CHECK_SPAWN.invoker().onMobCheckSpawn(mob, level, spawnerPos, spawnReason);
	}

	public static boolean onPatrolMemberSpawn(class_3218 level, class_2338 pos) {
		return onUnspawnedMobCheckSpawn(class_1299.field_6105, level, new class_243(pos.method_10263(), pos.method_10264(), pos.method_10260()), class_3730.field_16527);
	}

	public static boolean onSiegeZombieSpawn(class_3218 level, class_243 spawnPos) {
		return onUnspawnedMobCheckSpawn(class_1299.field_6051, level, spawnPos, class_3730.field_16467);
	}

	public static boolean onNetherPortalSpawn(class_3218 level, class_2338 spawnPos) {
		return onUnspawnedMobCheckSpawn(class_1299.field_6050, level, class_243.method_24955(spawnPos), class_3730.field_16474);
	}

	private static boolean onUnspawnedMobCheckSpawn(class_1299<? extends class_1308> entityType, class_3218 level, class_243 spawnPos, class_3730 spawnReason) {
		class_1308 mob = entityType.method_5883(level);
		if (mob == null) {
			return true;
		}

		mob.method_5814(spawnPos.field_1352, spawnPos.field_1351, spawnPos.field_1350);
		return onMobCheckSpawn(mob, level, null, spawnReason);
	}
}
