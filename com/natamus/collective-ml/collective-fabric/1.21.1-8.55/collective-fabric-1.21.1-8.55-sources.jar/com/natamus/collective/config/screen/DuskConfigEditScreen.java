package com.natamus.collective.config.screen;

import com.natamus.collective.config.DuskConfig;
import com.natamus.collective.config.DuskConfigEntry;
import com.natamus.collective.config.DuskConfigFile;
import com.natamus.collective.config.DuskConfigMod;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3675;
import net.minecraft.class_407;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7919;

public class DuskConfigEditScreen extends DuskConfigBaseScreen {
	public static boolean showTooltips = false;

	private final class_437 parent;
	private final DuskConfigMod configMod;
	private final List<DuskConfigSetting> settings = new ArrayList<>();
	private final List<String> initialValues = new ArrayList<>();
	private DuskConfigList list;
	private class_342 searchBox;
	private class_4185 doneButton;
	private String search = "";

	public DuskConfigEditScreen(class_437 parent, DuskConfigMod configMod) {
		super(class_2561.method_43469("collective.collective.gui.configtitle", StringUtils.capitalize(configMod.name)));
		this.parent = parent;
		this.configMod = configMod;

		for (DuskConfigEntry entry : configMod.entries) {
			initialValues.add(entry.getText());
		}
	}

	@Override
	protected boolean hasUnsavedChanges() {
		for (int i = 0; i < configMod.entries.size(); i++) {
			if (!configMod.entries.get(i).getText().equals(initialValues.get(i))) {
				return true;
			}
		}
		return false;
	}

	public static class_437 getScreen(class_437 parent, String modid) {
		DuskConfigMod configMod = DuskConfigMod.configMods.get(modid);
		if (configMod == null) {
			return parent;
		}

		DuskConfigFile.reload(configMod);
		return new DuskConfigEditScreen(parent, configMod);
	}

	@Override
	protected void method_25426() {
		super.method_25426();

		settings.clear();
		for (DuskConfigEntry entry : configMod.getActiveEntries()) {
			settings.add(new DuskConfigSetting(this, entry, this.field_22789 - 3));
		}

		searchBox = this.method_37063(new class_342(this.field_22793, this.field_22789 / 2 - 70, 28, 140, 20, class_2561.method_43471("gui.recipebook.search_hint")));
		searchBox.method_47404(class_2561.method_43471("gui.recipebook.search_hint").method_27692(class_124.field_1063));
		searchBox.method_1852(search);
		searchBox.method_1863(text -> {
			search = text;
			refreshRows();
			list.method_25307(0);
		});

		class_124 tooltipColour = class_124.field_1063;
		class_2561 tooltipState = class_5244.field_24333;
		if (showTooltips) {
			tooltipColour = class_124.field_1068;
			tooltipState = class_5244.field_24332;
		}

		class_4185 tooltipButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("?").method_27692(tooltipColour), button -> {
			showTooltips = !showTooltips;
			this.method_41843();
		}).method_46433(this.field_22789 - 67, 28).method_46437(20, 20).method_46431());
		tooltipButton.method_47400(class_7919.method_47407(class_2561.method_43469("collective.collective.gui.tooltips", tooltipState)));

		class_4185 guiScaleButton = this.method_37063(new DuskConfigButton(this.field_22789 - 43, 28, 30, 20, getGuiScaleLabel(), button -> cycleGuiScale(false), button -> cycleGuiScale(true)));
		guiScaleButton.method_47400(class_7919.method_47407(class_2561.method_43469("options.generic_value", class_2561.method_43471("options.guiScale"), getGuiScaleLabel())));

		class_2561 patreonLabel = class_2561.method_43470("❤ ").method_27692(class_124.field_1061).method_10852(class_2561.method_43470("Patreon").method_27692(class_124.field_1068));
		this.method_37063(new DuskConfigButton(10, 28, this.field_22793.method_27525(patreonLabel) + 12, 20, patreonLabel, class_407.method_60867(this, "https://link.serilum.com/patreon", true)));

		double scroll = 0;
		if (list != null) {
			scroll = list.method_25341();
		}

		list = new DuskConfigList(this.field_22787, this.field_22789, this.field_22790 - 92, 56, 25);
		this.method_25429(list);
		refreshRows();
		list.method_25307(scroll);

		addCancelButton(this.field_22789 / 2 - 154, this.field_22790 - 28);
		doneButton = this.method_37063(class_4185.method_46430(class_5244.field_24334, button -> saveAndClose()).method_46433(this.field_22789 / 2 + 4, this.field_22790 - 28).method_46437(150, 20).method_46431());

		onSettingChanged();
	}

	private void refreshRows() {
		String searchText = search.strip().toLowerCase(Locale.ROOT);

		List<DuskConfigRow> rows = new ArrayList<>();
		for (DuskConfigSetting setting : settings) {
			String displayName = setting.entry.getDisplayName();
			if (displayName.toLowerCase(Locale.ROOT).contains(searchText) || setting.entry.getName().toLowerCase(Locale.ROOT).contains(searchText)) {
				rows.add(new DuskConfigRow(displayName, setting.widgets));
			}
		}
		list.setRows(rows);
	}

	public void onSettingChanged() {
		if (doneButton == null) {
			return;
		}

		doneButton.field_22763 = true;
		for (DuskConfigSetting setting : settings) {
			setting.updateResetButton();
			if (!setting.isValid) {
				doneButton.field_22763 = false;
			}
		}
	}

	private void saveAndClose() {
		DuskConfig.write(configMod.modid);
		this.field_22787.method_1507(parent);
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		if (button == class_3675.field_32002 && searchBox.method_25405(mouseX, mouseY)) {
			searchBox.method_1852("");
			return true;
		}
		return super.method_25402(mouseX, mouseY, button);
	}

	@Override
	public void method_25419() {
		DuskConfigFile.reload(configMod);
		this.field_22787.method_1507(parent);
	}

	@Override
	public void method_25420(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		if (this.field_22787.field_1687 == null) {
			this.method_57728(guiGraphics, partialTick);
		}

		this.method_57734(partialTick);
	}

	@Override
	public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

		list.method_25394(guiGraphics, mouseX, mouseY, partialTick);
		guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 12, 0xFFFFFFFF);
	}
}
