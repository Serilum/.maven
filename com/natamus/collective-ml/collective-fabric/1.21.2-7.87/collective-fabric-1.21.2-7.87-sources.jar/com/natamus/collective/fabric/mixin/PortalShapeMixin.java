package com.natamus.collective.fabric.mixin;

import com.natamus.collective.fabric.callbacks.CollectiveBlockEvents;
import com.natamus.collective.functions.WorldFunctions;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2424;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_2424.class, priority = 1001)
public class PortalShapeMixin {
	@Shadow private @Final class_2338 bottomLeft;
	
	@Inject(method = "createPortalBlocks(Lnet/minecraft/world/level/LevelAccessor;)V", at = @At(value= "HEAD"))
	public void createPortalBlocks(class_1936 levelAccessor, CallbackInfo ci) {
		class_2424 portalshape = (class_2424)(Object)this;
		CollectiveBlockEvents.ON_NETHER_PORTAL_SPAWN.invoker().onPossiblePortal(WorldFunctions.getWorldIfInstanceOfAndNotRemote(levelAccessor), bottomLeft, portalshape);
	}
}
