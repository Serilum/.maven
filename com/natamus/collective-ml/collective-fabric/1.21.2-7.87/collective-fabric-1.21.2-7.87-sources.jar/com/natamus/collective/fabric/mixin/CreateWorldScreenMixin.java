package com.natamus.collective.fabric.mixin;

import com.mojang.serialization.Lifecycle;
import com.natamus.collective.services.Services;
import net.minecraft.class_1940;
import net.minecraft.class_31;
import net.minecraft.class_5219;
import net.minecraft.class_525;
import net.minecraft.class_7193;
import net.minecraft.class_7659;
import net.minecraft.class_7723;
import net.minecraft.class_7780;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@SuppressWarnings({"rawtypes", "unchecked", })
@Mixin(value = class_525.class, priority = 1001)
public abstract class CreateWorldScreenMixin {
	@Shadow
	private boolean recreated;
	@Shadow
	protected abstract boolean createNewWorld(class_7780<class_7659> layeredRegistryAccess, class_5219 worldData);

	@Inject(method = "onCreate", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/worldselection/WorldOpenFlows;confirmWorldCreation(Lnet/minecraft/client/Minecraft;Lnet/minecraft/client/gui/screens/worldselection/CreateWorldScreen;Lcom/mojang/serialization/Lifecycle;Ljava/lang/Runnable;Z)V"), locals = LocalCapture.CAPTURE_FAILSOFT, cancellable = true)
	private void onCreate(CallbackInfo ci, class_7193 worldCreationContext, class_7723.class_7725 complete, class_7780 layeredRegistryAccess, Lifecycle lifecycle, Lifecycle lifecycle2, Lifecycle lifecycle3, boolean bl, class_1940 levelSettings, class_31 primaryLevelData) {
		if (this.recreated) {
			return;
		}

		if (Services.MODLOADER.isDevelopmentEnvironment() || Services.MODLOADER.isModLoaded("hideexperimentalwarning")) {
			this.createNewWorld(layeredRegistryAccess, primaryLevelData);
			ci.cancel();
		}
	}
}
