package com.natamus.collective.functions;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1927;
import net.minecraft.class_2338;
import net.minecraft.class_9892;

public class ExplosionFunctions {
	public static List<class_2338> getAffectedBlockPositions(class_1927 explosion) {
		if (explosion.method_64504().field_9236) {
			return new ArrayList<class_2338>();
		}
		return getAffectedBlockPositions((class_9892)explosion);
	}
	public static List<class_2338> getAffectedBlockPositions(class_9892 serverExplosion) {
		return serverExplosion.method_61740();
	}

	public static void clearExplosion(class_1927 explosion) {
		if (!explosion.method_64504().field_9236) {
			clearExplosion((class_9892)explosion);
		}
	}
	public static void clearExplosion(class_9892 serverExplosion) {
		serverExplosion.field_52625 = 0;
	}
}
