package com.natamus.collective.translations;

import com.natamus.collective.services.Services;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_3259;
import net.minecraft.class_3264;
import net.minecraft.class_3288;
import net.minecraft.class_5352;
import net.minecraft.class_9224;
import net.minecraft.class_9225;

public class TranslationPack {
	public static Path getPackDir() {
		return Path.of(Services.MODLOADER.getGameDirectory(), "data", "serilum", "translations");
	}

	public static void contribute(Consumer<class_3288> consumer) {
		if (!Files.isRegularFile(getPackDir().resolve("pack.mcmeta"))) {
			return;
		}

		class_3288 pack = buildTranslationPack();
		if (pack != null) {
			consumer.accept(pack);
		}
	}

	public static class_3288 buildTranslationPack() {
		return class_3288.method_45275(
				new class_9224("serilum_mod_translations", class_2561.method_43470("Serilum Mod Translations"), class_5352.field_25348, Optional.empty()),
				new class_3259.class_8619(getPackDir()),
				class_3264.field_14188,
				new class_9225(true, class_3288.class_3289.field_14281, false)
		);
	}
}