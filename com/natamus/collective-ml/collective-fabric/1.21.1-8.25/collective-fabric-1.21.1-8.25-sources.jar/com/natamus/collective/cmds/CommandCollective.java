package com.natamus.collective.cmds;

import com.mojang.brigadier.CommandDispatcher;
import com.natamus.collective.features.PlayerHeadCacheFeature;
import com.natamus.collective.functions.MessageFunctions;
import com.natamus.collective.util.CollectiveReference;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2168;
import net.minecraft.class_2170;

public class CommandCollective {
	public static void register(CommandDispatcher<class_2168> dispatcher) {
		dispatcher.register(class_2170.method_9247("collective").requires((commandSourceStack) -> commandSourceStack.method_43737())
			.executes((command) -> {
				return showCommandHelp(command.getSource());
			})
			.then(class_2170.method_9247("help")
			.executes((command) -> {
				return showCommandHelp(command.getSource());
			}))

			.then(class_2170.method_9247("reset")
			.then(class_2170.method_9247("headcache")
			.executes((command) -> {
				class_2168 source = command.getSource();
				class_1657 player = source.method_44023();

				if (PlayerHeadCacheFeature.resetPlayerHeadCache()) {
					MessageFunctions.sendTranslatableMessage(player, "collective.collective.message.headcachereset", class_124.field_1077);
				}

				return 1;
			})))
		);
	}

	private static int showCommandHelp(class_2168 source) {
		if (source.method_9259(2)) {
			MessageFunctions.sendTranslatableMessage(source, "collective.shared.message.adminusage", true, class_124.field_1065, CollectiveReference.NAME);
			MessageFunctions.sendMessage(source, " /collective reset headcache", class_124.field_1077);
			MessageFunctions.sendTranslatableMessage(source, "     ", "collective.collective.message.headcachehelp", class_124.field_1080);
		}
		return 1;
	}
}
