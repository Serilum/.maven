package com.natamus.collective.services.helpers;

import net.minecraft.class_1921;
import net.minecraft.class_2248;

public interface ClientUtilsHelper {
	void blockSetRenderType(class_2248 block, class_1921 renderType);
	void blockSetRenderCutout(class_2248 block);
}