package com.natamus.collective.translations;

import com.natamus.collective.config.CollectiveConfigHandler;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2477;
import net.minecraft.class_310;

public class TranslationLoader {
	private static String lastLocale = null;

	public static void onLanguageChanged(String locale) {
		if (!CollectiveConfigHandler.downloadNonEnglishTranslations) {
			return;
		}

		if (locale == null || locale.equals(lastLocale)) {
			return;
		}

		lastLocale = locale;

		if (locale.equalsIgnoreCase("en_us")) {
			return;
		}

		new Thread(() -> {
			if (TranslationDownloader.download(locale)) {
				class_310.method_1551().execute(() -> inject(locale));
			}
		}, "Serilum-Translations").start();
	}

	private static void inject(String locale) {
		try {
			Path langFile = TranslationPack.getPackDir().resolve("assets").resolve("collective").resolve("lang").resolve(locale + ".json");
			if (!Files.isRegularFile(langFile)) {
				return;
			}

			Map<String, String> translations = new HashMap<>();
			try (InputStream in = Files.newInputStream(langFile)) {
				class_2477.method_29425(in, translations::put);
			}

			if (class_2477.method_10517() instanceof TranslationStorage storage) {
				storage.collective$mergeTranslations(translations);
			}
		}
		catch (Exception ignored) { }
	}
}
