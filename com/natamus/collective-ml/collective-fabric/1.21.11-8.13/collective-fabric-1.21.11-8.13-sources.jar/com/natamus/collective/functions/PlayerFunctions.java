package com.natamus.collective.functions;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.natamus.collective.data.Constants;
import com.natamus.collective.util.CollectiveReference;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_174;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2522;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4208;
import net.minecraft.class_5217;
import net.minecraft.class_5321;
import net.minecraft.class_5454;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class PlayerFunctions {
	public static boolean respawnPlayer(class_1937 world, class_1657 player) {
		if (!(player instanceof class_3222 serverplayer)) {
			return false;
		}

		MinecraftServer server = world.method_8503();

        if (serverplayer.field_13989) {
			serverplayer.field_13989 = false;
			serverplayer = server.method_3760().method_14556(serverplayer, true, class_1297.class_5529.field_27002);
			class_174.field_1183.method_8794(serverplayer, class_1937.field_25181, class_1937.field_25179);
		}
		else if (serverplayer.method_6032() <= 0.0F) {
			 server.method_3760().method_14556(serverplayer, false, class_1297.class_5529.field_26998);
		}

		return true;
	}

	public static class_1657 matchPlayer(class_1657 player, String other) {
		return matchPlayer(player.method_73183(), other);
	}
	public static class_1657 matchPlayer(class_1937 world, String other) {
		List<? extends class_1657> players = world.method_18456();

		for (class_1657 onlineplayer : players) {
			if (onlineplayer.method_5477().getString().toLowerCase().equals(other)) {
				return onlineplayer;
			}
		}
		return null;
	}

	public static boolean isHoldingWater(class_1657 player) {
		return player.method_5998(class_1268.field_5810).method_7909().equals(class_1802.field_8705) || player.method_5998(class_1268.field_5808).method_7909().equals(class_1802.field_8705);
	}

	public static boolean isJoiningWorldForTheFirstTime(class_1657 player, String modid) {
		return isJoiningWorldForTheFirstTime(player, modid, false);
	}
	public static boolean isJoiningWorldForTheFirstTime(class_1657 player, String modid, boolean mustHaveEmptyInventory) {
		return isJoiningWorldForTheFirstTime(player, modid, false, true);
	}
	public static boolean isJoiningWorldForTheFirstTime(class_1657 player, String modid, boolean mustHaveEmptyInventory, boolean mustBeCloseToSpawn) {
		String firstjointag = CollectiveReference.MOD_ID + ".firstJoin." + modid;
		String playerName = player.method_5477().getString();

		Set<String> tags = player.method_5752();
		if (tags.contains(firstjointag)) {
			return false;
		}

		player.method_5780(firstjointag);

		if (mustHaveEmptyInventory) {
			class_1661 inv = player.method_31548();
			boolean isempty = true;
			for (int i = 0; i < 36; i++) {
				if (!inv.method_5438(i).method_7960()) {
					isempty = false;
					break;
				}
			}

			if (!isempty) {
                Constants.LOG.debug("[{}] Inventory of {} is not empty, first join is false.", modid, playerName);
				return false;
			}
		}

		if (mustBeCloseToSpawn) {
			class_1937 level = player.method_73183();
			class_3218 serverLevel = (class_3218) level;
			class_3222 serverPlayer = (class_3222) player;

			class_5217.class_12064 respawnData = serverLevel.method_74854();
			class_4208 globalSpawnPos = respawnData.comp_4915();

			class_5321<class_1937> spawnDimension = globalSpawnPos.comp_2207();
			class_2338 spawnPos = globalSpawnPos.comp_2208();

			class_3222.class_10766 respawnConfig = serverPlayer.method_67564();
			if (respawnConfig != null) {
				class_5217.class_12064 respawnConfigRespawnData = respawnConfig.comp_4913();

				spawnDimension = respawnConfigRespawnData.method_74894();
				spawnPos = respawnConfigRespawnData.method_74897();
			}

            Constants.LOG.debug("[{}] Checking for first join of {} with spawn position: {}", modid, playerName, spawnPos.method_23854());

			if (!spawnDimension.equals(player.method_73183().method_27983())) {
				return false;
			}

			class_2338 playerPos = player.method_24515();
			class_2338 checkPos = new class_2338(playerPos.method_10263(), spawnPos.method_10264(), playerPos.method_10260());

			int spawnRadius = serverLevel.method_64395().method_76185(class_1928.field_19403);
            Constants.LOG.debug("[{}] Checking for first join of {} with spawn radius: {}", modid, playerName, spawnRadius);

			return checkPos.method_19771(spawnPos, spawnRadius * 2);
		}

		return true;
	}

	public static class_2338 getSpawnPoint(class_1937 level, class_1657 player) {
		class_243 spawnvec = getSpawnVec(level, player);
		return class_2338.method_49637(spawnvec.field_1352, spawnvec.field_1351, spawnvec.field_1350);
	}
	public static class_243 getSpawnVec(class_1937 level, class_1657 player) {
		class_3222 serverplayer = (class_3222)player;
		class_3218 serverLevel = (class_3218)level;

		class_5217.class_12064 respawnData = serverLevel.method_74854();
		class_4208 globalRespawnPos = respawnData.comp_4915();

		class_2338 respawnlocation = globalRespawnPos.comp_2208(); // get spawn point
		class_243 respawnvec = new class_243(respawnlocation.method_10263(), respawnlocation.method_10264(), respawnlocation.method_10260());

		class_2338 bedpos = serverplayer.method_67564().comp_4913().method_74897();
		if (bedpos != null) {
			class_5454 optionalbed = ((class_3222) player).method_60590(true, class_5454.field_52245);

			class_243 bedvec = optionalbed.comp_2821();
			class_2338 bp = class_2338.method_49638(bedvec);
			Iterator<class_2338> it = class_2338.method_17962(bp.method_10263()-1, bp.method_10264()-1, bp.method_10260()-1, bp.method_10263()+1, bp.method_10264()+1, bp.method_10260()+1).iterator();
			while (it.hasNext()) {
				class_2338 np = it.next();
				class_2680 state = level.method_8320(np);
				class_2248 block = state.method_26204();
				if (block instanceof class_2244) { // Found bed
					respawnvec = bedvec;
					break;
				}
			}
		}

		return respawnvec;
	}

	public static class_1268 getOtherHand(class_1268 hand) {
		if (hand.equals(class_1268.field_5808)) {
			return class_1268.field_5810;
		}
		return class_1268.field_5808;
	}

	// Player Gear Functions
	public static String getPlayerGearString(class_1657 player) {
		class_1937 level = player.method_73183();
		StringBuilder skconfig = new StringBuilder();

		class_1799 offhand = player.method_6118(class_1304.field_6171);
		if (!offhand.method_7960()) {
			String nbtstring = ItemFunctions.getNBTStringFromItemStack(level, offhand);
			skconfig.append("'offhand'" + " : " + "'").append(nbtstring).append("',");
		}
		else {
			skconfig.append("'offhand'" + " : " + "'',");
		}

		class_1799 head = player.method_6118(class_1304.field_6169);
		if (!head.method_7960()) {
			String nbtstring = ItemFunctions.getNBTStringFromItemStack(level, head);
			skconfig.append("\n" + "'head'" + " : " + "'").append(nbtstring).append("',");
		}
		else {
			skconfig.append("\n" + "'head'" + " : " + "'',");
		}

		class_1799 chest = player.method_6118(class_1304.field_6174);
		if (!chest.method_7960()) {
			String nbtstring = ItemFunctions.getNBTStringFromItemStack(level, chest);
			skconfig.append("\n" + "'chest'" + " : " + "'").append(nbtstring).append("',");
		}
		else {
			skconfig.append("\n" + "'chest'" + " : " + "'',");
		}

		class_1799 legs = player.method_6118(class_1304.field_6172);
		if (!legs.method_7960()) {
			String nbtstring = ItemFunctions.getNBTStringFromItemStack(level, legs);
			skconfig.append("\n" + "'legs'" + " : " + "'").append(nbtstring).append("',");
		}
		else {
			skconfig.append("\n" + "'legs'" + " : " + "'',");
		}

		class_1799 feet = player.method_6118(class_1304.field_6166);
		if (!feet.method_7960()) {
			String nbtstring = ItemFunctions.getNBTStringFromItemStack(level, feet);
			skconfig.append("\n" + "'feet'" + " : " + "'").append(nbtstring).append("',");
		}
		else {
			skconfig.append("\n" + "'feet'" + " : " + "'',");
		}

		class_1661 inv = player.method_31548();
		for (int i=0; i < 36; i++) {
			class_1799 slot = inv.method_5438(i);
			if (!slot.method_7960()) {
				String nbtstring = ItemFunctions.getNBTStringFromItemStack(level, slot);
				skconfig.append("\n").append(i).append(" : ").append("'").append(nbtstring).append("',");
			}
			else {
				skconfig.append("\n").append(i).append(" : '',");
			}
		}

		return skconfig.toString();
	}

	public static String getPlayerGearStringFromHashMap(class_1937 level, HashMap<String, class_1799> gear) {
		StringBuilder gearstring = new StringBuilder();

		List<String> specialslots = new ArrayList<>(Arrays.asList("offhand", "head", "chest", "legs", "feet"));
		for (String specialslot : specialslots) {
			String specialslotstring = "";
			if (gear.containsKey(specialslot)) {
				specialslotstring = ItemFunctions.getNBTStringFromItemStack(level, gear.get(specialslot));
			}
			if (!gearstring.toString().isEmpty()) {
				gearstring.append("\n");
			}
			gearstring.append("'").append(specialslot).append("'").append(" : ").append("'").append(specialslotstring).append("',");
		}

		List<class_1799> emptyinventory = class_2371.method_10213(36, class_1799.field_8037);
		for (int i = 0; i < emptyinventory.size(); i++) {
			String itemstring = "";
			if (gear.containsKey("" + i)) {
				itemstring = ItemFunctions.getNBTStringFromItemStack(level, gear.get("" + i));
			}
			gearstring.append("\n").append(i).append(" : '").append(itemstring).append("',");
		}

		return gearstring.toString();
	}

	public static void setPlayerGearFromString(class_1657 player, String gearconfig) {
		class_1937 level = player.method_73183();
		String[] gearspl = gearconfig.split("',[\\r\\n]+");
		int newlinecount = gearspl.length;

		if (newlinecount < 40) {
			Constants.LOG.info("[Error] (Collective) setPlayerGearFromString: The gear config does not contain 40 lines and is invalid.");
			return;
		}

		boolean cleared = false;
		for (String line : gearspl) {
			line = line.trim();
			if (line.endsWith(",")) {
				line = line.substring(0, line.length() - 1);
			}
			if (!line.endsWith("'")) {
				line = line + "'";
			}

			String[] lspl = line.split(" : ");
			if (lspl.length != 2) {
                Constants.LOG.info("[Error] (Collective) setPlayerGearFromString: The line {} is invalid.", line);
				return;
			}

			String slotstring = lspl[0].replace("'", "");
			String data = lspl[1];
			if (data.startsWith("'")) {
				data = data.substring(1);
			}
			if (data.endsWith("'")) {
				data = data.substring(0, data.length() - 1);
			}

			if (data.length() < 2) {
				continue;
			}

			data = data.replaceAll("\r", "");

			class_1799 itemStack = class_1799.field_8037;
			try {
				class_2487 compoundTag = class_2522.method_67315(data);
				itemStack = class_1799.field_24671.parse(level.method_30349().method_57093(class_2509.field_11560), compoundTag).result().orElse(class_1799.field_8037);
			} catch (CommandSyntaxException ignored) { }

			if (itemStack.method_7960()) {
				try {
					data = data.replace("\",\"", "|||,|||").replace(" \"", " '").replace("\" ", "' ").replace("|||,|||", "\",\"");

					class_2487 compoundTag = class_2522.method_67315(data);
					itemStack = class_1799.field_24671.parse(level.method_30349().method_57093(class_2509.field_11560), compoundTag).result().orElse(class_1799.field_8037);
				} catch (CommandSyntaxException ex) {
					ex.printStackTrace();
				}
			}

			if (itemStack.method_7960()) {
                Constants.LOG.info("[Error] (Collective) setPlayerGearFromString: Unable to get the correct itemstack data from data {}", data);
				return;
			}

			if (!cleared) {
				cleared = true;
				player.method_31548().method_5448();
			}

			if (NumberFunctions.isNumeric(slotstring)) {
				int slot = Integer.parseInt(slotstring);
				player.method_31548().method_5447(slot, itemStack);
				continue;
			}

			class_1304 type;
			switch (slotstring) {
				case "offhand" -> type = class_1304.field_6171;
				case "head" -> type = class_1304.field_6169;
				case "chest" -> type = class_1304.field_6174;
				case "legs" -> type = class_1304.field_6172;
				case "feet" -> type = class_1304.field_6166;
				default -> {
					continue;
				}
			}

			player.method_5673(type, itemStack);
		}
	}
}
