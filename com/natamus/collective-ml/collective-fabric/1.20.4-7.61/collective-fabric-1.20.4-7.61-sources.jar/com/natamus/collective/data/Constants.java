package com.natamus.collective.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.natamus.collective.util.CollectiveReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1893;

public class Constants {
    public static final Logger LOG = LoggerFactory.getLogger(CollectiveReference.NAME);
    public static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    public static final List<class_1304> equipmentSlots = Arrays.asList(class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166, class_1304.field_6171);

    public static final class_1799 normalPickaxeStack = new class_1799(class_1802.field_22024);
    public static final class_1799 silkPickaxeStack = new class_1799(class_1802.field_22024);

    public static void initConstantData() {
		silkPickaxeStack.method_7978(class_1893.field_9099, 1);
    }
}
