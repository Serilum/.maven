package com.natamus.collective.fabric.mixin;

import com.mojang.authlib.GameProfile;
import com.natamus.collective.fabric.callbacks.CollectiveChatEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.time.Instant;
import net.minecraft.class_2556;
import net.minecraft.class_2561;
import net.minecraft.class_7471;
import net.minecraft.class_7594;

@Mixin(value = class_7594.class, priority = 1001)
public abstract class ChatListenerMixin {
    @Unique class_2556.class_7602 collective$bound;
    @Unique GameProfile collective$gameProfile;

    @Inject(method = "showMessageToPlayer", at = @At("HEAD"))
    public void captureParams(class_2556.class_7602 bound, class_7471 playerChatMessage, class_2561 component, GameProfile gameProfile, boolean bl, Instant instant, CallbackInfoReturnable<Boolean> cir) {
        collective$bound = bound;
        collective$gameProfile = gameProfile;
    }

    @ModifyVariable(method = "showMessageToPlayer", at = @At("HEAD"), argsOnly = true)
    public class_2561 modifyMessage(class_2561 component) {
        try {
            return CollectiveChatEvents.CLIENT_CHAT_RECEIVED.invoker().onClientChat(collective$bound.comp_919().comp_349(), component, (collective$gameProfile != null ? collective$gameProfile.getId() : null));
        } finally {
            collective$bound = null;
            collective$gameProfile = null;
        }
    }
}