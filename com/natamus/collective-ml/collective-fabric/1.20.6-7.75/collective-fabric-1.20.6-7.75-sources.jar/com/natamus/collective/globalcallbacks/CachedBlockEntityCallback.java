package com.natamus.collective.globalcallbacks;

import com.natamus.collective.implementations.event.Event;
import com.natamus.collective.implementations.event.EventFactory;
import net.minecraft.class_1937;
import net.minecraft.class_2586;
import net.minecraft.class_2591;

public class CachedBlockEntityCallback {
	private CachedBlockEntityCallback() { }

    public static final Event<On_Block_Entity_Added> BLOCK_ENTITY_ADDED = EventFactory.createArrayBacked(On_Block_Entity_Added.class, callbacks -> (level, blockEntity, blockEntityType) -> {
        for (On_Block_Entity_Added callback : callbacks) {
        	callback.onBlockEntityAdded(level, blockEntity, blockEntityType);
        }
    });

    public static final Event<On_Block_Entity_Removed> BLOCK_ENTITY_REMOVED = EventFactory.createArrayBacked(On_Block_Entity_Removed.class, callbacks -> (level, blockEntity, blockEntityType) -> {
        for (On_Block_Entity_Removed callback : callbacks) {
        	callback.onBlockEntityRemoved(level, blockEntity, blockEntityType);
        }
    });

	@FunctionalInterface
	public interface On_Block_Entity_Added {
		 void onBlockEntityAdded(class_1937 level, class_2586 blockEntity, class_2591<?> blockEntityType);
	}

	@FunctionalInterface
	public interface On_Block_Entity_Removed {
		 void onBlockEntityRemoved(class_1937 level, class_2586 blockEntity, class_2591<?> blockEntityType);
	}
}
