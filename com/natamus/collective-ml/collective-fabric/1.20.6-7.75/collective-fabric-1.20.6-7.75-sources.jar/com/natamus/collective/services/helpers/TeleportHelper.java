package com.natamus.collective.services.helpers;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_5454;

public interface TeleportHelper {
    <T extends class_1297> class_1297 teleportEntity(T entity, class_3218 serverLevel, class_5454 portalInfo);
    <T extends class_1297> class_1297 teleportEntity(T entity, class_3218 serverLevel, class_243 vec3);
    <T extends class_1297> class_1297 teleportEntity(T entity, class_3218 serverLevel, class_2338 blockPos);
    <T extends class_1297> class_1297 teleportEntity(T entity, class_5321<class_1937> targetDimension, class_243 vec3);
    <T extends class_1297> class_1297 teleportEntity(T entity, class_5321<class_1937> targetDimension, class_2338 blockPos);
}