package com.natamus.collective.services.helpers;

import javax.annotation.Nullable;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public interface RegisterItemHelper {
	class_1792 registerAndGetItem(class_2960 resourceLocation, class_1792 item, @Nullable class_5321<class_1761> creativeModeTabResourceKey);
}