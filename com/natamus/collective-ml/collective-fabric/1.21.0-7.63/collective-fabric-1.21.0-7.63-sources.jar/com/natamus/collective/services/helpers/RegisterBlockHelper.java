package com.natamus.collective.services.helpers;

import com.mojang.datafixers.util.Pair;
import javax.annotation.Nullable;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public interface RegisterBlockHelper {
	Pair<class_2248, class_1747> registerAndGetBlockPair(class_2960 resourceLocation, class_2248 block, @Nullable class_5321<class_1761> creativeModeTabResourceKey);
}