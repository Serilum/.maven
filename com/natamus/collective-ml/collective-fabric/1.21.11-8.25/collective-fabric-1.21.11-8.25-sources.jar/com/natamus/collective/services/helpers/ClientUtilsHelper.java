package com.natamus.collective.services.helpers;

import net.minecraft.class_11515;
import net.minecraft.class_2248;

public interface ClientUtilsHelper {
	void blockSetChunkSectionLayer(class_2248 block, class_11515 chunkSectionLayer);
	void blockSetRenderCutout(class_2248 block);
}