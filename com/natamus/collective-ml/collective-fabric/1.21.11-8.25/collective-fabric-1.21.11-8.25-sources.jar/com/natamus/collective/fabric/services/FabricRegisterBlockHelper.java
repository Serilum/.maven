package com.natamus.collective.fabric.services;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective.services.helpers.RegisterBlockHelper;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class FabricRegisterBlockHelper implements RegisterBlockHelper {
	private static final HashMap<class_2960, class_2248> registeredBlocksWithoutItem = new HashMap<>();
	private static final HashMap<class_2960, Pair<class_2248, class_1792>> registeredBlockWithItemPairs = new HashMap<>();

    @Override
	public <T extends class_2248> void registerBlockWithoutItem(Object modEventBusObject, class_2960 Identifier, Function<class_4970.class_2251, class_2248> blockFunction, class_4970.class_2251 properties, boolean lastBlock) {
		staticRegisterBlock(modEventBusObject, Identifier, blockFunction, properties, null, lastBlock, false);
    }

	@Override
	public class_2248 getRegisteredBlockWithoutItem(class_2960 Identifier) {
		return registeredBlocksWithoutItem.get(Identifier);
	}

    @Override
	public <T extends class_2248> void registerBlockWithItem(Object modEventBusObject, class_2960 Identifier, Function<class_4970.class_2251, class_2248> blockFunction, class_4970.class_2251 properties, class_5321<class_1761> creativeModeTabResourceKey, boolean lastBlock) {
		staticRegisterBlock(modEventBusObject, Identifier, blockFunction, properties, creativeModeTabResourceKey, lastBlock, true);
    }

	@Override
	public class_2248 getRegisteredBlockWithItem(class_2960 Identifier) {
		return registeredBlockWithItemPairs.get(Identifier).getFirst();
	}

	@Override
	public Pair<class_2248, class_1747> getRegisteredBlockWithItemPair(class_2960 Identifier) {
		Pair<class_2248, class_1792> registeredPair = registeredBlockWithItemPairs.get(Identifier);
		return Pair.of(registeredPair.getFirst(), (class_1747)registeredPair.getSecond());
	}

	@Override
	public void setRegisteredBlockWithItemPair(class_2960 Identifier, Class<?> blockClass, String blockFieldName, Class<?> blockItemClass, String blockItemFieldName) {
		Pair<class_2248, class_1792> registeredPair = registeredBlockWithItemPairs.get(Identifier);

        try {
            Field blockField = blockClass.getDeclaredField(blockFieldName);
            blockField.setAccessible(true);
            blockField.set(null, registeredPair.getFirst());

            Field blockItemField = blockItemClass.getDeclaredField(blockItemFieldName);
            blockItemField.setAccessible(true);
            blockItemField.set(null, registeredPair.getSecond());
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
	}

	public static <T extends class_2248> void staticRegisterBlock(Object modEventBusObject, class_2960 Identifier, Function<class_4970.class_2251, class_2248> blockFunction, class_4970.class_2251 properties, class_5321<class_1761> creativeModeTabResourceKey, boolean lastBlock, boolean registerAsItem) {
		class_5321<class_2248> resourceKey = class_5321.method_29179(class_7924.field_41254, Identifier);
		class_2248 block = blockFunction.apply(properties.method_63500(resourceKey));

		class_2378.method_39197(class_7923.field_41175, resourceKey, block);

		if (registerAsItem) {
			class_1792 item = FabricRegisterItemHelper.staticRegisterItem(modEventBusObject, Identifier, (itemProperties) -> new class_1747(block, itemProperties), new class_1792.class_1793().method_63685(), creativeModeTabResourceKey);

			registeredBlockWithItemPairs.put(Identifier, Pair.of(block, item));
		}
		else {
			registeredBlocksWithoutItem.put(Identifier, block);
		}
	}
}