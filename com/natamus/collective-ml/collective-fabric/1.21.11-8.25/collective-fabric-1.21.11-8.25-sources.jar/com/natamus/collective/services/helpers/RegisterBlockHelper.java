package com.natamus.collective.services.helpers;

import com.mojang.datafixers.util.Pair;
import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;

public interface RegisterBlockHelper {
    default <T extends class_2248> void registerBlockWithoutItem(Object modEventBusObject, class_2960 Identifier, Function<class_4970.class_2251, class_2248> blockFunction, class_4970.class_2251 properties) {
        registerBlockWithoutItem(modEventBusObject, Identifier, blockFunction, properties, false);
    }
	<T extends class_2248> void registerBlockWithoutItem(Object modEventBusObject, class_2960 Identifier, Function<class_4970.class_2251, class_2248> blockFunction, class_4970.class_2251 properties, boolean lastBlock);
	class_2248 getRegisteredBlockWithoutItem(class_2960 Identifier);

	default <T extends class_2248> void registerBlockWithItem(Object modEventBusObject, class_2960 Identifier, Function<class_4970.class_2251, class_2248> blockFunction, class_4970.class_2251 properties, class_5321<class_1761> creativeModeTabResourceKey) {
        registerBlockWithItem(modEventBusObject, Identifier, blockFunction, properties, creativeModeTabResourceKey, false);
    }
	<T extends class_2248> void registerBlockWithItem(Object modEventBusObject, class_2960 Identifier, Function<class_4970.class_2251, class_2248> blockFunction, class_4970.class_2251 properties, class_5321<class_1761> creativeModeTabResourceKey, boolean lastBlock);
	class_2248 getRegisteredBlockWithItem(class_2960 Identifier);

	Pair<class_2248, class_1747> getRegisteredBlockWithItemPair(class_2960 Identifier);
	void setRegisteredBlockWithItemPair(class_2960 Identifier, Class<?> blockClass, String blockFieldName, Class<?> blockItemClass, String blockItemFieldName);
}