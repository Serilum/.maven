package com.natamus.collective.data;

import java.util.Map;
import net.minecraft.class_304.class_11900;

public class ClientConstants {
	public static final Map<String, class_11900> keyMappingCategories = Map.of(
		"key.categories.creative", class_11900.field_62561,
		"key.categories.gameplay", class_11900.field_62558,
		"key.categories.inventory", class_11900.field_62559,
		"key.categories.misc", class_11900.field_62556,
		"key.categories.movement", class_11900.field_62555,
		"key.categories.multiplayer", class_11900.field_62557
	);
}
