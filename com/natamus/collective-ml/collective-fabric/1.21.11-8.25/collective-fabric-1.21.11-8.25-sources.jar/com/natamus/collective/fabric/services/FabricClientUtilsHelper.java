package com.natamus.collective.fabric.services;

import com.natamus.collective.services.helpers.ClientUtilsHelper;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.minecraft.class_11515;
import net.minecraft.class_2248;

public class FabricClientUtilsHelper implements ClientUtilsHelper {
    @Override
    public void blockSetChunkSectionLayer(class_2248 block, class_11515 chunkSectionLayer) {
        BlockRenderLayerMap.putBlock(block, chunkSectionLayer);
    }

    @Override
    public void blockSetRenderCutout(class_2248 block) {
        blockSetChunkSectionLayer(block, class_11515.field_60925);
    }
}