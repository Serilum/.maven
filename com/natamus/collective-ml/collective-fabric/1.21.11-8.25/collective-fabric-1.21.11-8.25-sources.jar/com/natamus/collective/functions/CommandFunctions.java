package com.natamus.collective.functions;

import net.minecraft.class_12096;
import net.minecraft.class_128;
import net.minecraft.class_129;
import net.minecraft.class_148;
import net.minecraft.class_1918;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3544;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

public class CommandFunctions {
    public static String getRawCommandOutput(class_3218 serverLevel, @Nullable class_243 vec, String command) {
        class_1918 bcb = new class_1918() {
            public @NotNull class_243 getPosition() {
                return Objects.requireNonNullElseGet(vec, () -> new class_243(0, 0, 0));
            }

            @Override
            public void method_8295(@NotNull class_3218 serverLevel) {

            }

            @Override
            public @NotNull class_2168 method_8303(@NotNull class_3218 serverLevel, @NotNull class_2165 commandSource) {
                return new class_2168(commandSource, getPosition(), class_241.field_1340, serverLevel, class_12096.field_63208, "dev", class_2561.method_43470("dev"), serverLevel.method_8503(), null);
            }

            @Override
            public boolean method_52175() {
                return true;
            }

            @Override
            public boolean method_8301(@NotNull class_3218 serverLevel) {
                if ("Searge".equalsIgnoreCase(this.method_8289())) {
                    this.method_8291(class_2561.method_43470("#itzlipofutzli"));
                    this.method_8298(1);
                }
                else {
                    this.method_8298(0);
                    MinecraftServer minecraftserver = serverLevel.method_8503();
                    if (!class_3544.method_15438(this.method_8289())) {
                        try {
                            this.method_8291(null);

                            try (class_11874 closedCommandBlockSource = new class_11874(serverLevel)) {
                                class_2165 commandSource = (class_2165) Objects.requireNonNullElse(closedCommandBlockSource, class_2165.field_17395);
                                class_2168 commandsourcestack = this.method_8303(serverLevel, commandSource).method_9231((b, i) -> {
                                    if (b) {
                                        this.method_8298(this.method_8304() + 1);
                                    }

                                });
                                minecraftserver.method_3734().method_44252(commandsourcestack, this.method_8289());
                            }
                        }
                        catch (Throwable throwable) {
                            class_128 crashreport = class_128.method_560(throwable, "Executing command block");
                            class_129 crashreportcategory = crashreport.method_562("Command to be executed");
                            crashreportcategory.method_577("Command", this::method_8289);
                            crashreportcategory.method_577("Name", () -> this.method_8299().getString());
                            throw new class_148(crashreport);
                        }
                    }
                }
                return true;
            }
        };

        bcb.method_8286(command);
        bcb.method_8287(true);
        bcb.method_8301(serverLevel);

        return bcb.method_8292().getString();
    }
}