package com.natamus.collective.fabric.services;

import com.natamus.collective.services.helpers.RegisterItemHelper;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.HashMap;
import java.util.function.Function;

public class FabricRegisterItemHelper implements RegisterItemHelper {
	private static final HashMap<class_2960, class_1792> itemMap = new HashMap<>();

    @Override
	public <T extends class_1792> void registerItem(Object modEventBusObject, class_2960 Identifier, Function<class_1792.class_1793, class_1792> itemFunction, class_1792.class_1793 properties, class_5321<class_1761> creativeModeTabResourceKey, boolean lastItem) {
		staticRegisterItem(modEventBusObject, Identifier, itemFunction, properties, creativeModeTabResourceKey);
    }

	public static <T extends class_1792> class_1792 staticRegisterItem(Object modEventBusObject, class_2960 Identifier, Function<class_1792.class_1793, class_1792> itemFunction, class_1792.class_1793 properties, class_5321<class_1761> creativeModeTabResourceKey) {
		class_5321<class_1792> resourceKey = class_5321.method_29179(class_7924.field_41197, Identifier);
		class_1792 item = itemFunction.apply(properties.method_63686(resourceKey));

		class_2378.method_39197(class_7923.field_41178, resourceKey, item);

		if (creativeModeTabResourceKey != null) {
			ItemGroupEvents.modifyEntriesEvent(creativeModeTabResourceKey).register(entries -> entries.method_45421(item));
		}

		itemMap.put(Identifier, item);

		return item;
    }

	@Override
	public class_1792 getRegisteredItem(class_2960 Identifier) {
		return itemMap.get(Identifier);
	}
}