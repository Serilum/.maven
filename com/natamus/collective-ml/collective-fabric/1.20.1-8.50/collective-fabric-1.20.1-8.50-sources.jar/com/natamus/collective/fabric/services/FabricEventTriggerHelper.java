package com.natamus.collective.fabric.services;

import com.natamus.collective.fabric.callbacks.CollectiveBlockEvents;
import com.natamus.collective.services.helpers.EventTriggerHelper;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2424;

public class FabricEventTriggerHelper implements EventTriggerHelper {
	@Override
	public void triggerNetherPortalSpawnEvent(class_1937 level, class_2338 portalPos, class_2424 size) {
		CollectiveBlockEvents.ON_NETHER_PORTAL_SPAWN.invoker().onPossiblePortal(level, portalPos, size);
	}

	@Override
	public void triggerLivingConversionEvent(class_1309 entity, class_1309 outcome) {

	}
}