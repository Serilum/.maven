package com.natamus.collective.services.helpers;

import com.natamus.collective.networking.packets.EntityDataSyncPacket;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import net.minecraft.class_2960;

public interface EntityDataHelper {
    String KEY = "collective_entitydata";

    void init();

    class_2487 getStored(class_1297 entity);

    void setStored(class_1297 entity, class_2487 data);

    default int getInt(class_1297 entity, class_2960 id, int defaultValue) {
        class_2487 data = getStored(entity);
        String key = id.toString();
        if (!data.method_10545(key)) {
            return defaultValue;
        }

        return data.method_10550(key);
    }

    default void setInt(class_1297 entity, class_2960 id, int value) {
        class_2487 data = getStored(entity);
        data.method_10569(id.toString(), value);
        setStored(entity, data);

        if (!entity.method_37908().method_8608()) {
            EntityDataSyncPacket.syncToTrackers(entity);
        }
    }
}
