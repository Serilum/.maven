package com.natamus.collective.fabric.mixin;

import com.natamus.collective.data.BlockEntityData;
import com.natamus.collective.globalcallbacks.CachedBlockEntityCallback;
import net.minecraft.class_1937;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_2586.class, priority = 1001)
public class BlockEntityMixin {
	@Shadow private @Final class_2591<?> type;
	@Shadow protected class_1937 level;

	@Inject(method = "setLevel(Lnet/minecraft/world/level/Level;)V", at = @At(value = "TAIL"))
	public void setLevel(class_1937 level, CallbackInfo ci) {
		if (level == null) {
			return;
		}

		if (!BlockEntityData.shouldCacheOnSide(type, level.method_8608())) {
			return;
		}

		class_2586 blockEntity = (class_2586)(Object)this;

		BlockEntityData.cacheBlockEntity(type, level, blockEntity);
		CachedBlockEntityCallback.BLOCK_ENTITY_ADDED.invoker().onBlockEntityAdded(level, blockEntity, type);
	}

	@Inject(method = "setRemoved()V", at = @At(value = "TAIL"))
	public void setRemoved(CallbackInfo ci) {
		if (level == null) {
			return;
		}

		if (!BlockEntityData.shouldCacheOnSide(type, level.method_8608())) {
			return;
		}

		class_2586 blockEntity = (class_2586)(Object)this;

		BlockEntityData.uncacheBlockEntity(type, level, blockEntity);
		CachedBlockEntityCallback.BLOCK_ENTITY_REMOVED.invoker().onBlockEntityRemoved(level, blockEntity, type);
	}
}
