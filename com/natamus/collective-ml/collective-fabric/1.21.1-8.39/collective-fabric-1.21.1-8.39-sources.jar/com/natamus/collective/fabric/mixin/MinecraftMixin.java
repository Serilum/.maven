package com.natamus.collective.fabric.mixin;

import com.mojang.authlib.minecraft.UserApiService;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.natamus.collective.config.CollectiveConfigHandler;
import com.natamus.collective.data.BlockEntityData;
import com.natamus.collective.data.Constants;
import com.natamus.collective.fabric.callbacks.CollectiveLifecycleEvents;
import com.natamus.collective.services.Services;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;
import net.minecraft.class_434;
import net.minecraft.class_542;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_310.class, priority = 1001)
public class MinecraftMixin {
	@Shadow public class_638 level;

	@Inject(method = "setLevel(Lnet/minecraft/client/multiplayer/ClientLevel;Lnet/minecraft/client/gui/screens/ReceivingLevelScreen$Reason;)V", at = @At(value = "HEAD"))
	public void Minecraft_setLevel(class_638 clientLevel, class_434.class_9678 reason, CallbackInfo ci) {
		BlockEntityData.removeLevelFromCache(level);
	}

    @Inject(method = "<init>(Lnet/minecraft/client/main/GameConfig;)V", at = @At(value = "TAIL"))
    public void Minecraft_init(class_542 gameConfig, CallbackInfo ci) {
        ((class_310)(Object)this).execute(() -> {
            CollectiveLifecycleEvents.MINECRAFT_LOADED.invoker().onMinecraftLoad(true);
        });
    }

    @Inject(method = "createUserApiService", at = @At(value = "HEAD"), cancellable = true)
    public void Minecraft_createUserApiService(YggdrasilAuthenticationService yggdrasilAuthenticationService, class_542 gameConfig, CallbackInfoReturnable<UserApiService> cir) {
        if (FabricLoader.getInstance().isDevelopmentEnvironment()) {
            Constants.LOG.info("Failed to verify authentication");
            cir.setReturnValue(UserApiService.OFFLINE);
        }
    }

	@Inject(method = "createTitle", at = @At("RETURN"), cancellable = true)
	private void Minecraft_createTitle(CallbackInfoReturnable<String> cir) {
        if (CollectiveConfigHandler.updateMinecraftWindowTitleInDevMode && Services.MODLOADER.isDevelopmentEnvironment()) {
            cir.setReturnValue("Minecraft · Dev mode · " + Services.MODLOADER.getModLoaderName());
        }
	}
}
