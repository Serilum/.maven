package com.natamus.collective.functions;

import net.minecraft.class_124;

public class ColourFunctions {
	public static class_124 getById(int id) {
	    if (id < 0) {
			return class_124.field_1070;
	    }

	    class_124[] v = class_124.values();
	    return id < 16 ? v[id] : null;
	}
}