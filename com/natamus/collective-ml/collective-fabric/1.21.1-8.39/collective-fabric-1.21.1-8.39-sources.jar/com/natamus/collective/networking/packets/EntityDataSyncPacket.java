package com.natamus.collective.networking.packets;

import com.natamus.collective.implementations.networking.api.Dispatcher;
import com.natamus.collective.implementations.networking.data.PacketContext;
import com.natamus.collective.implementations.networking.data.Side;
import com.natamus.collective.services.Services;
import com.natamus.collective.util.CollectiveReference;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class EntityDataSyncPacket {
    public static final class_2960 CHANNEL = class_2960.method_60655(CollectiveReference.MOD_ID, "entity_data_sync");

    public final int entityId;
    public final class_2487 data;

    public EntityDataSyncPacket(int entityId, class_2487 data) {
        this.entityId = entityId;
        this.data = data;
    }

    public static EntityDataSyncPacket decode(class_2540 buf) {
        return new EntityDataSyncPacket(buf.method_10816(), buf.method_10798());
    }

    public void encode(class_2540 buf) {
        buf.method_10804(entityId);
        buf.method_10794(data);
    }

    public static void handle(PacketContext<EntityDataSyncPacket> ctx) {
        if (!Side.CLIENT.equals(ctx.side())) {
            return;
        }

        EntityDataSyncClientHandler.apply(ctx.message().entityId, ctx.message().data);
    }

    public static void syncToTrackers(class_1297 entity) {
        if (entity.method_37908().method_8608()) {
            return;
        }

        class_2487 data = Services.ENTITYDATA.getStored(entity);
        if (data.method_33133()) {
            return;
        }

        Dispatcher.sendToClientsLoadingChunk(new EntityDataSyncPacket(entity.method_5628(), data), entity.method_37908().method_8500(entity.method_24515()));
    }

    public static void syncToPlayer(class_1297 entity, class_3222 player) {
        class_2487 data = Services.ENTITYDATA.getStored(entity);
        if (data.method_33133()) {
            return;
        }

        Dispatcher.sendToClient(new EntityDataSyncPacket(entity.method_5628(), data), player);
    }
}
