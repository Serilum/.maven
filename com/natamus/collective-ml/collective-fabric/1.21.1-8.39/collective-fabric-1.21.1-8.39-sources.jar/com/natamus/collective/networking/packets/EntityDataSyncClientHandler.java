package com.natamus.collective.networking.packets;

import com.natamus.collective.services.Services;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_310;

public class EntityDataSyncClientHandler {
    public static void apply(int entityId, class_2487 data) {
        class_1937 level = class_310.method_1551().field_1687;
        if (level == null) {
            return;
        }

        class_1297 entity = level.method_8469(entityId);
        if (entity != null) {
            Services.ENTITYDATA.setStored(entity, data);
        }
    }
}
