package com.natamus.collective.fabric.mixin;

import com.mojang.authlib.minecraft.UserApiService;
import com.mojang.authlib.services.MinecraftServicesDiscoveryService;
import com.natamus.collective.config.CollectiveConfigHandler;
import com.natamus.collective.data.BlockEntityData;
import com.natamus.collective.data.Constants;
import com.natamus.collective.fabric.callbacks.CollectiveLifecycleEvents;
import com.natamus.collective.services.Services;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.main.GameConfig;
import net.minecraft.client.multiplayer.ClientLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = Minecraft.class, priority = 1001)
public class MinecraftMixin {
	@Shadow public ClientLevel level;

	@Inject(method = "setLevel(Lnet/minecraft/client/multiplayer/ClientLevel;)V", at = @At(value = "HEAD"))
	public void Minecraft_setLevel(ClientLevel clientLevel, CallbackInfo ci) {
		BlockEntityData.removeLevelFromCache(level);
	}

	@Inject(method = "<init>(Lnet/minecraft/client/main/GameConfig;)V", at = @At(value = "TAIL"))
	public void Minecraft_init(GameConfig gameConfig, CallbackInfo ci) {
		((Minecraft)(Object)this).execute(() -> {
			CollectiveLifecycleEvents.MINECRAFT_LOADED.invoker().onMinecraftLoad(true);
		});
	}

	@Inject(method = "createUserApiService", at = @At(value = "HEAD"), cancellable = true)
	private static void Minecraft_createUserApiService(MinecraftServicesDiscoveryService discoveryService, GameConfig config, CallbackInfoReturnable<UserApiService> cir) {
		if (FabricLoader.getInstance().isDevelopmentEnvironment()) {
			Constants.LOG.info("Failed to verify authentication");
			cir.setReturnValue(UserApiService.OFFLINE);
		}
	}

	@Inject(method = "createTitle", at = @At("RETURN"), cancellable = true)
	private void Minecraft_createTitle(CallbackInfoReturnable<String> cir) {
		if (CollectiveConfigHandler.updateMinecraftWindowTitleInDevMode && Services.MODLOADER.isDevelopmentEnvironment()) {
			cir.setReturnValue("Minecraft · Dev mode · " + Services.MODLOADER.getModLoaderName());
		}
	}
}
