package com.natamus.collective.fabric.mixin;

import com.natamus.collective.data.IEntityDataHolder;
import com.natamus.collective.fabric.callbacks.CollectivePlayerEvents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.level.portal.TeleportTransition;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = ServerPlayer.class, priority = 1001)
public class ServerPlayerMixin {
	@Inject(method = "tick()V", at = @At(value = "HEAD"))
	public void ServerPlayer_tick(CallbackInfo ci) {
		ServerPlayer serverPlayer = (ServerPlayer)(Object)this;

		CollectivePlayerEvents.PLAYER_TICK.invoker().onTick(serverPlayer.level(), serverPlayer);
	}
	
	@Inject(method = "die(Lnet/minecraft/world/damagesource/DamageSource;)V", at = @At(value = "HEAD"))
	public void ServerPlayer_die(DamageSource damageSource, CallbackInfo ci) {
		ServerPlayer serverPlayer = (ServerPlayer)(Object)this;

		CollectivePlayerEvents.PLAYER_DEATH.invoker().onDeath(serverPlayer.level(), serverPlayer);
	}
	
	@Inject(method = "teleport(Lnet/minecraft/world/level/portal/TeleportTransition;)Lnet/minecraft/server/level/ServerPlayer;", at = @At(value = "RETURN"))
	public void ServerPlayer_teleport(TeleportTransition teleportTransition, CallbackInfoReturnable<ServerPlayer> cir) {
		ServerPlayer serverPlayer = (ServerPlayer)(Object)this;
		
		CollectivePlayerEvents.PLAYER_CHANGE_DIMENSION.invoker().onChangeDimension(serverPlayer.level(), serverPlayer);
	}

	@Inject(method = "restoreFrom(Lnet/minecraft/server/level/ServerPlayer;Z)V", at = @At(value = "TAIL"))
	public void ServerPlayer_restoreFrom(ServerPlayer oldPlayer, boolean restoreAll, CallbackInfo ci) {
		CompoundTag stored = ((IEntityDataHolder)oldPlayer).collective_getStored();
		((IEntityDataHolder)this).collective_setStored(stored);
	}
}
