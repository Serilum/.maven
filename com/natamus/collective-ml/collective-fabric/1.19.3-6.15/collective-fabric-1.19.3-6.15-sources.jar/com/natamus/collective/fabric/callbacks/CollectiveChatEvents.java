package com.natamus.collective.fabric.callbacks;

import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_2556;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.UUID;

public class CollectiveChatEvents {
	private CollectiveChatEvents() { }
	 
    public static final Event<On_Client_Chat> CLIENT_CHAT_RECEIVED = EventFactory.createArrayBacked(On_Client_Chat.class, callbacks -> (chatType, message, senderUUID) -> {
        for (On_Client_Chat callback : callbacks) {
        	class_2561 newMessage = callback.onClientChat(chatType, message, senderUUID);
        	if (newMessage != message) {
        		return newMessage;
        	}
        }
        
        return message;
    });
    
    public static final Event<On_Server_Chat> SERVER_CHAT_RECEIVED = EventFactory.createArrayBacked(On_Server_Chat.class, callbacks -> (serverPlayer, message, senderUUID) -> {
        for (On_Server_Chat callback : callbacks) {
        	Pair<Boolean, class_2561> pair = callback.onServerChat(serverPlayer, message, senderUUID);
        	if (pair != null) {
	        	if (pair.getFirst()) {
	        		return pair;
	        	}
        	}
        }
        
        return null;
    });
    
	@FunctionalInterface
	public interface On_Client_Chat {
		 class_2561 onClientChat(class_2556.class_7603 chatType, class_2561 message, UUID senderUUID);
	}
	
	@FunctionalInterface
	public interface On_Server_Chat {
		 Pair<Boolean, class_2561> onServerChat(class_3222 serverPlayer, class_2561 message, UUID senderUUID);
	}
}
