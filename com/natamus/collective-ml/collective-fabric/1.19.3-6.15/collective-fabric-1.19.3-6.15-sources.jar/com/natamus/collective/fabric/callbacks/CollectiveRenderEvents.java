package com.natamus.collective.fabric.callbacks;

import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_4587;

public class CollectiveRenderEvents {
	private CollectiveRenderEvents() { }

	public static final Event<Render_Specific_Hand> RENDER_SPECIFIC_HAND = EventFactory.createArrayBacked(Render_Specific_Hand.class, callbacks -> (interactionHand, poseStack, itemStack) -> {
		for (Render_Specific_Hand callback : callbacks) {
			if (!callback.onRenderSpecificHand(interactionHand, poseStack, itemStack)) {
				return false;
			}
		}

		return true;
	});

	public static final Event<Set_Entity_Hitbox_Size> SET_ENTITY_HITBOX = EventFactory.createArrayBacked(Set_Entity_Hitbox_Size.class, callbacks -> (entity, pose, oldSize, newSize, oldEyeHeight, newEyeHeight) -> {
		for (Set_Entity_Hitbox_Size callback : callbacks) {
			Pair<class_4048, Float> resultpair = callback.setEntityHitboxSize(entity, pose, oldSize, newSize, oldEyeHeight, newEyeHeight);
			if (resultpair != null) {
				return resultpair;
			}
		}

		return null;
	});

	@FunctionalInterface
	public interface Render_Specific_Hand {
		boolean onRenderSpecificHand(class_1268 interactionHand, class_4587 poseStack, class_1799 itemStack);
	}

	@FunctionalInterface
	public interface Set_Entity_Hitbox_Size {
		Pair<class_4048, Float> setEntityHitboxSize(class_1297 entity, class_4050 pose, class_4048 oldSize, class_4048 newSize, float oldEyeHeight, float newEyeHeight);
	}
}
