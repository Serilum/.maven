package com.natamus.collective.fabric.mixin;

import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value = class_634.class, priority = 1001)
public class ClientPacketListenerMixin {
	/*@Final @Shadow private Minecraft minecraft;
	@Shadow private RegistryAccess.Frozen registryAccess;
	
	@Inject(method = "handlePlayerChat(Lnet/minecraft/network/protocol/game/ClientboundPlayerChatPacket;)V", at = @At(value = "HEAD"), cancellable = true)
	public void ClientPacketListener_handleChatPreview(ClientboundPlayerChatPacket clientboundPlayerChatPacket, CallbackInfo ci) {
		Component message = clientboundPlayerChatPacket.message().serverContent();
		System.out.println("MESSAGE: " + message.getString());
		Component newMessage = CollectiveChatEvents.CLIENT_CHAT_RECEIVED.invoker().onClientChat(clientboundPlayerChatPacket.chatType(), message, null);
		if (message != newMessage) {
			minecraft.gui.getChat().getFocusedChat().getChatPreview().handleResponse(clientboundPlayerChatPacket.chatType().chatType(), newMessage);
			ci.cancel();
		}
	}*/
}
