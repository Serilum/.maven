package com.natamus.collective.fabric.mixin;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective.fabric.callbacks.CollectiveChatEvents;
import com.natamus.collective.functions.MessageFunctions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_5250;
import net.minecraft.class_7471;

@Mixin(value = class_3244.class, priority = 1001, remap = false)
public abstract class ServerGamePacketListenerImplMixin {
    @Shadow public class_3222 player;

    @Inject(method = "method_45064(Lnet/minecraft/network/chat/PlayerChatMessage;Ljava/util/concurrent/CompletableFuture;Ljava/util/concurrent/CompletableFuture;Ljava/lang/Void;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerGamePacketListenerImpl;broadcastChatMessage(Lnet/minecraft/network/chat/PlayerChatMessage;)V"), locals = LocalCapture.CAPTURE_FAILSOFT, cancellable = true)
    public void handleChat(class_7471 playerChatMessage, CompletableFuture<?> completableFuture, CompletableFuture<?> completableFuture2, Void arg3, CallbackInfo ci, class_7471 playerChatMessage2) {
        class_2561 message = class_2561.method_43470("<" + this.player.method_5477().getString() + "> " + playerChatMessage2.method_46291().getString());

        Pair<Boolean, class_2561> pair = CollectiveChatEvents.SERVER_CHAT_RECEIVED.invoker().onServerChat(this.player, message, player.method_5667());
        if (pair != null) {
            class_2561 newMessage = pair.getSecond();

            MessageFunctions.broadcastMessage(this.player.method_5770(), (class_5250) newMessage);
            ci.cancel();
        }
    }
}
