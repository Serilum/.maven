package com.natamus.collective.fabric.mixin;

import com.natamus.collective.networking.packets.EntityDataSyncPacket;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_3231;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_3231.class, priority = 1001)
public class ServerEntityMixin {
	@Shadow @Final private class_1297 entity;

	@Inject(method = "addPairing(Lnet/minecraft/server/level/ServerPlayer;)V", at = @At(value = "TAIL"))
	public void ServerEntity_addPairing(class_3222 player, CallbackInfo ci) {
		EntityDataSyncPacket.syncToPlayer(entity, player);
	}
}
