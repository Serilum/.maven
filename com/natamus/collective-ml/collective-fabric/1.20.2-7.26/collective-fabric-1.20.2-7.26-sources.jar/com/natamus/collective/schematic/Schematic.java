package com.natamus.collective.schematic;

import com.mojang.brigadier.StringReader;
import com.mojang.datafixers.util.Pair;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2259;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2507;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_7923;

@SuppressWarnings("deprecated")
public class Schematic {
	private int size;
	private short width;
	private short height;
	private short length;
	private int offsetX;
	private int offsetY;
	private int offsetZ;
	private boolean oldVersion;
	private HashMap<Integer, String> palette;
	private SchematicBlockObject[] blockObjects;
	private List<class_2487> blockEntities;
	private List<Pair<class_2338, class_2487>> entities;

	public Schematic(InputStream inputStream) {
		String type = "";
		try {
			class_2487 nbtdata = class_2507.method_10629(inputStream);
			inputStream.close();

			if (nbtdata.method_10545("Length")) {
				length = nbtdata.method_10568("Length");
				width = nbtdata.method_10568("Width");
				height = nbtdata.method_10568("Height");
			}
			else {
				class_2499 sizeList = nbtdata.method_10554("size", class_2520.field_33253);
				length = (short)sizeList.method_10600(0);
				width = (short)sizeList.method_10600(1);
				height = (short)sizeList.method_10600(2);
			}

			size = length * width * height;

			if (nbtdata.method_10545("entities")) {
				type = "nbt";
			}
			else if (nbtdata.method_10545("DataVersion")) {
				type = "schem";
			}
			else {
				type = "schematic";
			}

			this.blockObjects = new SchematicBlockObject[size];
			this.entities = new ArrayList<Pair<class_2338, class_2487>>();

			if (type.equals("schem")) {
				byte[] blocks = nbtdata.method_10547("BlockData");

				class_2487 palette = nbtdata.method_10562("Palette");
				this.palette = new HashMap<Integer, String>();
				for (String k : palette.method_10541()) {
					this.palette.put(palette.method_10550(k), k);
				}

				int counter = 0;
				for (int i = 0; i < height; i++) {
					for (int j = 0; j < length; j++) {
						for (int k = 0; k < width; k++) {
							class_2338 pos = new class_2338(k, i , j);
							int id = blocks[counter];

							if (id < 0) {
								id *= -1;
							}

							class_2680 state = getStateFromID(id);

							blockObjects[counter] = new SchematicBlockObject(pos, state);
							counter++;
						}
					}
				}

				class_2499 tileentitynbtlist = nbtdata.method_10554("BlockEntities", class_2520.field_33260);
				this.blockEntities = new ArrayList<class_2487>();

				for (int i = 0; i < tileentitynbtlist.size(); i++) {
					this.blockEntities.add(tileentitynbtlist.method_10602(i));
				}

				class_2487 offsetCompoundTag = nbtdata.method_10562("Metadata");
				offsetX = offsetCompoundTag.method_10550("WEOffsetX");
				offsetY = offsetCompoundTag.method_10550("WEOffsetY");
				offsetZ = offsetCompoundTag.method_10550("WEOffsetZ");

				return;
			}
			else if (type.equals("schematic")) {
				byte[] blockIDs_byte = nbtdata.method_10547("Blocks");
				int[] blockIDs = new int[size];
				for (int x = 0; x < blockIDs_byte.length; x++) {
					blockIDs[x] = Byte.toUnsignedInt(blockIDs_byte[x]);
				}

				byte[] metadata = nbtdata.method_10547("Data");

				int counter = 0;
				for (int i = 0; i < height; i++) {
					for (int j = 0; j < length; j++) {
						for (int k = 0; k < width; k++) {
							class_2338 pos = new class_2338(k, i , j);
							class_2680 state = getStateFromOldIds(blockIDs[counter], metadata[counter]);
							blockObjects[counter] = new SchematicBlockObject(pos, state);
							counter++;
						}
					}
				}

				class_2499 tileentitynbtlist = nbtdata.method_10554("TileEntities", class_2520.field_33260);
				this.blockEntities = new ArrayList<class_2487>();

				for (int i = 0; i < tileentitynbtlist.size(); i++) {
					class_2487 compound = tileentitynbtlist.method_10602(i);
					int i0 = compound.method_10550("x");
					int i1 = compound.method_10550("y");
					int i2 = compound.method_10550("z");
					compound.method_10539("Pos", new int[] {i0, i1, i2});
					this.blockEntities.add(compound);
				}

				offsetX = nbtdata.method_10550("WEOffsetX");
				offsetY = nbtdata.method_10550("WEOffsetY");
				offsetZ = nbtdata.method_10550("WEOffsetZ");

				return;
			}
			else if (type.equals("nbt")) {
				class_2499 paletteNBTList = nbtdata.method_10554("palette", class_2520.field_33260);

				this.palette = new HashMap<Integer, String>();
				for (int i = 0; i < paletteNBTList.size(); i++) {
					class_2487 compound = paletteNBTList.method_10602(i);
					String value = compound.method_10558("Name");

					if (compound.method_10545("Properties")) {
						StringBuilder metaData = new StringBuilder("[");

						class_2487 propertyCompound = compound.method_10562("Properties");
						for (String propertyKey : propertyCompound.method_10541()) {
							if (!metaData.toString().equals("[")) {
								metaData.append(",");
							}

							metaData.append(propertyKey).append("=").append(propertyCompound.method_10580(propertyKey));
						}

						metaData.append("]");
						value += metaData;
					}

					this.palette.put(i, value);
				}

				this.blockEntities = new ArrayList<class_2487>();

				class_2499 blocksNBTList = nbtdata.method_10554("blocks", class_2520.field_33260);
				for (int i = 0; i < blocksNBTList.size(); i++) {
					class_2487 compound = blocksNBTList.method_10602(i);

					class_2499 posList = compound.method_10554("pos", class_2520.field_33253);
					int i0 = posList.method_10600(0);
					int i1 = posList.method_10600(1);
					int i2 = posList.method_10600(2);

					class_2338 pos = new class_2338(i0, i1, i2);

					class_2680 state = getStateFromID(compound.method_10550("state"));
					blockObjects[i] = new SchematicBlockObject(pos, state);

					if (compound.method_10545("nbt")) {
						class_2487 blockEntityCompound = compound.method_10562("nbt");
						blockEntityCompound.method_10539("Pos", new int[] {i0, i1, i2});
						blockEntityCompound.method_10582("Id", blockEntityCompound.method_10558("id"));
						blockEntityCompound.method_10551("id");
						this.blockEntities.add(blockEntityCompound);
					}
				}

				class_2499 entitiesNBTList = nbtdata.method_10554("entities", class_2520.field_33260);
				for (int i = 0; i < entitiesNBTList.size(); i++) {
					class_2487 compound = entitiesNBTList.method_10602(i);

					class_2487 entityCompound = compound.method_10562("nbt");

					class_2499 posList = compound.method_10554("blockPos", class_2520.field_33253);
					int i0 = posList.method_10600(0);
					int i1 = posList.method_10600(1);
					int i2 = posList.method_10600(2);

					this.entities.add(new Pair<class_2338, class_2487>(new class_2338(i0, i1, i2), entityCompound));
				}

				offsetX = 0;
				offsetY = 0;
				offsetZ = 0;

				return;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		System.err.println("Can't load " + type + " Schematic file.");
		this.width = 0;
		this.height = 0;
		this.length = 0;
		this.offsetX = 0;
		this.offsetY = 0;
		this.offsetZ = 0;
		this.size = 0;
		this.blockObjects = null;
		this.palette = null;
		this.blockEntities = null;
	}

	public boolean isOldVersion() {
		return oldVersion;
	}

	private class_2680 getStateFromOldIds(int blockID, byte meta) {
		return class_2248.method_9531(blockID);
	}

	public class_2680 getBlockState(class_2338 pos) {
		for (SchematicBlockObject obj : this.blockObjects) {
			if (obj.getPosition().equals(pos)) {
				return obj.getState();
			}
		}
		return class_2246.field_10124.method_9564();
	}

	public int getSize() {
		return size;
	}

	public SchematicBlockObject[] getBlocks() {
		return blockObjects;
	}

	public class_2680 getStateFromID(int id) {
		String iblockstateS = this.palette.get(id);

		try {
			return class_2259.method_41955(class_7923.field_41175.method_46771(), new StringReader(iblockstateS), false).comp_622();
		} catch (Exception ex) {
			return class_2246.field_10124.method_9564();
		}
	}

	public List<class_2487> getBlockEntities() {
		return this.blockEntities;
	}

	public List<Pair<class_2338, class_2487>> getEntityRelativePosPairs() {
		return this.entities;
	}

	public class_2487 getTileEntity(class_2338 pos) {
		for (class_2487 compound : this.blockEntities) {
			int[] pos1 = compound.method_10561("Pos");

			if (pos1[0] == pos.method_10263() && pos1[1] == pos.method_10264() && pos1[2] == pos.method_10260()) {
				return compound;
			}
		}
		return null;
	}

	public class_2338 getBlockPosFromCompoundTag(class_2487 compoundTag) {
		int[] pos = compoundTag.method_10561("Pos");
		return new class_2338(pos[0], pos[1], pos[2]);
	}

	public short getWidth() {
		return width;
	}
	public short getHeight() {
		return height;
	}
	public short getLength() {
		return length;
	}

	public int getOffsetX() {
		return offsetX;
	}
	public int getOffsetY() {
		return offsetY;
	}
	public int getOffsetZ() {
		return offsetZ;
	}
}