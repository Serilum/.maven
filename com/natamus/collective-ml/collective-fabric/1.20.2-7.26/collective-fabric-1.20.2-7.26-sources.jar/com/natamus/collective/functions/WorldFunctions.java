package com.natamus.collective.functions;

import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_5218;

public class WorldFunctions {
	public static void setWorldTime(class_3218 ServerLevel, Integer time) {
		if (time < 0 || time > 24000) {
			return;
		}

		int days = getTotalDaysPassed(ServerLevel);
		ServerLevel.method_29199(time + (days * 24000L)); // setDayTime
	}
	
	public static int getTotalTimePassed(class_3218 ServerLevel) {
		return (int)ServerLevel.method_8532();
	}
	public static int getTotalDaysPassed(class_3218 ServerLevel) {
		int currenttime = getTotalTimePassed(ServerLevel);
		return (int)Math.floor((double)currenttime/24000);
	}
	public static int getWorldTime(class_3218 ServerLevel) {
		return getTotalTimePassed(ServerLevel) - (getTotalDaysPassed(ServerLevel)*24000);
	}
	
	// Dimension functions
	public static String getWorldDimensionName(class_1937 world) {
		return world.method_27983().method_29177().toString();
	}
	public static boolean isOverworld(class_1937 world) {
		return getWorldDimensionName(world).toLowerCase().endsWith("overworld");
	}
	public static boolean isNether(class_1937 world) {
		return getWorldDimensionName(world).toLowerCase().endsWith("nether");
	}
	public static boolean isEnd(class_1937 world) {
		return getWorldDimensionName(world).toLowerCase().endsWith("end");
	}
	
	// IWorld functions
	public static class_1937 getWorldIfInstanceOfAndNotRemote(class_1936 iworld) {
		if (iworld.method_8608()) {
			return null;
		}
		if (iworld instanceof class_1937) {
			return ((class_1937)iworld);
		}
		return null;
	}
	
	// Path
	public static String getWorldPath(class_3218 ServerLevel) {
		String worldpath = ServerLevel.method_8503().method_27050(class_5218.field_24188).toString();
		return worldpath.substring(0, worldpath.length() - 2);
	}
}
