package com.natamus.collective.fabric.services;

import com.natamus.collective.fabric.callbacks.CollectiveBlockEvents;
import com.natamus.collective.services.helpers.EventTriggerHelper;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2424;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class FabricEventTriggerHelper implements EventTriggerHelper {
	@Override
	public void triggerNetherPortalSpawnEvent(class_1937 level, class_2338 portalPos, class_2424 size) {
		CollectiveBlockEvents.ON_NETHER_PORTAL_SPAWN.invoker().onPossiblePortal(level, portalPos, size);
	}

	@Override
	public void triggerLivingConversionEvent(class_1309 entity, class_1309 outcome) {

	}

	@Override
	public boolean triggerBlockBreakEvent(class_1937 level, class_1657 player, class_2338 pos, class_2680 state) {
		class_2586 blockEntity = level.method_8321(pos);
		boolean isAllowed = PlayerBlockBreakEvents.BEFORE.invoker().beforeBlockBreak(level, player, pos, state, blockEntity);
		if (!isAllowed) {
			PlayerBlockBreakEvents.CANCELED.invoker().onBlockBreakCanceled(level, player, pos, state, blockEntity);
		}
		return isAllowed;
	}

	@Override
	public void triggerAfterBlockBreakEvent(class_1937 level, class_1657 player, class_2338 pos, class_2680 state, class_2586 blockEntity) {
		PlayerBlockBreakEvents.AFTER.invoker().afterBlockBreak(level, player, pos, state, blockEntity);
	}
}