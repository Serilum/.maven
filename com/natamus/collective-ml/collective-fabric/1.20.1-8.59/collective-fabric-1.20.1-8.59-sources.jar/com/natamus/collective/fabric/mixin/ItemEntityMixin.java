package com.natamus.collective.fabric.mixin;

import com.natamus.collective.fabric.callbacks.CollectiveItemEvents;
import com.natamus.collective.fabric.callbacks.CollectivePlayerEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_1542.class, priority = 1001)
public abstract class ItemEntityMixin extends class_1297 {
	public ItemEntityMixin(class_1299<?> entityType, class_1937 level) {
		super(entityType, level);
	}

	@Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/item/ItemEntity;discard()V", ordinal = 1))
	public void ItemEntity_tick(CallbackInfo ci) {
		class_1542 itemEntity = (class_1542)(Object)this;
		class_1799 itemStack = itemEntity.method_6983();
		CollectiveItemEvents.ON_ITEM_EXPIRE.invoker().onItemExpire(itemEntity, itemStack);
	}

	@Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Inventory;add(Lnet/minecraft/world/item/ItemStack;)Z"), method = "playerTouch")
	public void playerTouch(class_1657 player, CallbackInfo ci) {
		class_1799 itemStack = ((class_1542)(Object)this).method_6983();

		CollectivePlayerEvents.ON_ITEM_PICKED_UP.invoker().onItemPickedUp(player.method_37908(), player, itemStack);
	}
}
