package com.natamus.collective.fabric.events;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;

public class CollectiveFabricEvents {
	public static WeakHashMap<class_1309, List<class_1542>> capturedDeathDrops = new WeakHashMap<>();
	public static ArrayDeque<class_1309> livingEntitiesDroppingLoot = new ArrayDeque<>();

	public static void onLivingEntityStartsDroppingLoot(class_1309 livingEntity) {
		livingEntitiesDroppingLoot.push(livingEntity);
		capturedDeathDrops.put(livingEntity, new ArrayList<>());
	}

	public static List<class_1542> onLivingEntityStopsDroppingLoot(class_1309 livingEntity) {
		livingEntitiesDroppingLoot.remove(livingEntity);

		List<class_1542> drops = capturedDeathDrops.remove(livingEntity);
		if (drops == null) {
			return new ArrayList<>();
		}

		return drops;
	}

	public static void onEntityAddedToLevel(class_1297 entity) {
		if (!(entity instanceof class_1542 itemEntity)) {
			return;
		}

		class_1309 livingEntity = livingEntitiesDroppingLoot.peek();
		if (livingEntity == null) {
			return;
		}

		capturedDeathDrops.computeIfAbsent(livingEntity, k -> new ArrayList<>()).add(itemEntity);
	}
}
