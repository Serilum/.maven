package com.natamus.collective.features;

import com.natamus.collective.data.FeatureFlags;
import com.natamus.collective.functions.HeadFunctions;
import java.util.HashMap;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

public class PlayerHeadCacheFeature {
	public static HashMap<String, class_1799> cachedPlayerHeadsMap = new HashMap<String, class_1799>();

	public static class_1799 cachePlayer(class_1657 player) {
		return cachePlayer(player.method_5477().getString());
	}
	public static class_1799 cachePlayer(String playerName) {
		if (cachedPlayerHeadsMap.containsKey(playerName)) {
			return cachedPlayerHeadsMap.get(playerName).method_7972();
		}

		class_1799 headStack = HeadFunctions.getPlayerHead(playerName, 1);
		cachedPlayerHeadsMap.put(playerName, headStack);

		return headStack.method_7972();
	}

	public static class_1799 getPlayerHeadStackFromCache(class_1657 player) {
		return getPlayerHeadStackFromCache(player.method_5477().getString());
	}
	public static class_1799 getPlayerHeadStackFromCache(String playerName) {
		if (cachedPlayerHeadsMap.containsKey(playerName)) {
			return cachedPlayerHeadsMap.get(playerName).method_7972();
		}

		return cachePlayer(playerName);
	}

	public static boolean isHeadCachingEnabled() {
		return FeatureFlags.shouldCachePlayerHeads;
	}

	public static void enableHeadCaching() {
		FeatureFlags.shouldCachePlayerHeads = true;
	}

	public static boolean resetPlayerHeadCache() {
		cachedPlayerHeadsMap = new HashMap<String, class_1799>();
		return true;
	}
}
