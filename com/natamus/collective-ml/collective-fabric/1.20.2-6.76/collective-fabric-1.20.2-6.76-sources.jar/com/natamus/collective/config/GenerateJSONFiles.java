package com.natamus.collective.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.natamus.collective.data.Constants;
import com.natamus.collective.functions.DataFunctions;
import com.natamus.collective.globalcallbacks.JSONCallback;
import com.natamus.collective.services.Services;
import com.natamus.collective.util.CollectiveReference;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class GenerateJSONFiles {
	private static final HashMap<String, List<String>> dependentMods = new HashMap<String, List<String>>();

	public static void requestJSONFile(String modid, List<String> fileNames) {
		for (String fileName : fileNames) {
			requestJSONFile(modid, fileName);
		}
	}
	public static void requestJSONFile(String modid, String fileName) {
		if (dependentMods.containsKey(fileName)) {
			dependentMods.get(fileName).add(modid);
		}
		else {
			dependentMods.put(fileName, Arrays.asList(modid));
		}

		Constants.LOG.info("[" + CollectiveReference.NAME + "] JSON file '" + fileName + "' generation requested by mod '" + modid + "'.");
	}

	private static List<String> getJsonToParse() {
		List<String> jsonToParse = new ArrayList<String>();
		for (String jsonFileName : dependentMods.keySet()) {
			List<String> mods = dependentMods.get(jsonFileName);

			for (String modid : mods) {
				if (Services.MODLOADER.isModLoaded(modid)) {
					jsonToParse.add(jsonFileName);
					break;
				}
			}
		}

		return jsonToParse;
	}

	public static void initGeneration(class_3218 serverLevel) {
		initGeneration(serverLevel.method_8503());
	}
	public static void initGeneration(MinecraftServer minecraftServer) {
		List<String> jsonToParse = getJsonToParse();
		if (jsonToParse.isEmpty()) {
			return;
		}

		String dirpath = DataFunctions.getConfigDirectory() + File.separator + CollectiveReference.MOD_ID;
		File dir = new File(dirpath);
		if (!dir.isDirectory()) {
			boolean ignored = dir.mkdirs();
		}

		for (String fileName : jsonToParse) {
			boolean isCreated = false;
			JsonElement jsonElement = null;

			File file = new File(dirpath + File.separator + fileName);
			if (!file.isFile()) {
				InputStream inputStream = DataFunctions.getDataInputStream(minecraftServer, CollectiveReference.MOD_ID, "json", fileName);
				if (inputStream != null) {
					jsonElement = JsonParser.parseReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));

					PrintWriter writer = null;
					try {
						writer = new PrintWriter(dirpath + File.separator + fileName, StandardCharsets.UTF_8);
						writer.print(Constants.GSON.toJson(jsonElement));
					} catch (IOException ex) {
						Constants.LOG.warn("[" + CollectiveReference.NAME + "] Unable to write the JSON file: " + fileName);
					}

					if (writer != null) {
						writer.close();
					}
				}
				else {
					Constants.LOG.warn("[" + CollectiveReference.NAME + "] Unable to get Input Stream for: " + fileName);
				}
			}

			JSONCallback.JSON_FILE_AVAILABLE.invoker().onJsonFileAvailable(dirpath, fileName, isCreated, jsonElement);
		}

		JSONCallback.ALL_JSON_FILES_AVAILABLE.invoker().onAllJsonFilesAvailable(dirpath);
	}
}
