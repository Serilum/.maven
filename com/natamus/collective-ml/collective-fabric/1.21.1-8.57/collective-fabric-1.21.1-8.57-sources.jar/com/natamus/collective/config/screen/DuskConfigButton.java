package com.natamus.collective.config.screen;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import org.jetbrains.annotations.NotNull;

public class DuskConfigButton extends class_4185 {
	private final class_4241 onRightPress;

	public DuskConfigButton(int x, int y, int width, int height, class_2561 message, class_4241 onPress) {
		this(x, y, width, height, message, onPress, null);
	}

	public DuskConfigButton(int x, int y, int width, int height, class_2561 message, class_4241 onPress, class_4241 onRightPress) {
		super(x, y, width, height, message, onPress, field_40754);
		this.onRightPress = onRightPress;
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		if (onRightPress != null && button == class_3675.field_32002 && this.field_22763 && this.field_22764 && this.method_25405(mouseX, mouseY)) {
			this.method_25354(class_310.method_1551().method_1483());
			onRightPress.onPress(this);
			return true;
		}
		return super.method_25402(mouseX, mouseY, button);
	}

	@Override
	public void method_48589(@NotNull class_332 guiGraphics, @NotNull class_327 font, int colour) {
		int labelWidth = font.method_27525(this.method_25369());
		int maxWidth = this.method_25368() - 6;
		if (labelWidth <= maxWidth) {
			super.method_48589(guiGraphics, font, colour);
			return;
		}

		float scale = maxWidth / (float) labelWidth;
		guiGraphics.method_51448().method_22903();
		guiGraphics.method_51448().method_46416(this.method_46426() + this.method_25368() / 2F, this.method_46427() + (this.method_25364() - 8 * scale) / 2F, 0);
		guiGraphics.method_51448().method_22905(scale, scale, 1F);
		guiGraphics.method_27534(font, this.method_25369(), 0, 0, colour);
		guiGraphics.method_51448().method_22909();
	}
}
