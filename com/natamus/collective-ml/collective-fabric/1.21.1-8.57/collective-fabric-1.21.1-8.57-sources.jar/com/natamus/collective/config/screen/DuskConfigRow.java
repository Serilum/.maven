package com.natamus.collective.config.screen;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4265;
import net.minecraft.class_6379;

public class DuskConfigRow extends class_4265.class_4266<DuskConfigRow> {
	private final String label;
	private final List<class_339> widgets;

	public DuskConfigRow(String label, List<class_339> widgets) {
		this.label = label;
		this.widgets = widgets;
	}

	@Override
	public void method_25343(@NotNull class_332 guiGraphics, int index, int y, int x, int width, int height, int mouseX, int mouseY, boolean hovered, float partialTick) {
		int labelSpace = Integer.MAX_VALUE;
		for (class_339 widget : widgets) {
			widget.method_46419(y);
			widget.method_25394(guiGraphics, mouseX, mouseY, partialTick);
			labelSpace = Math.min(labelSpace, widget.method_46426() - 18);
		}

		class_327 font = class_310.method_1551().field_1772;
		guiGraphics.method_25303(font, fitLabel(font, label, labelSpace), 12, y + 5, 0xFFFFFFFF);
	}

	public static String fitLabel(class_327 font, String label, int width) {
		if (font.method_1727(label) <= width) {
			return label;
		}
		return font.method_27523(label, Math.max(0, width - font.method_1727("..."))) + "...";
	}

	@Override
	public @NotNull List<? extends class_364> method_25396() {
		return widgets;
	}

	@Override
	public @NotNull List<? extends class_6379> method_37025() {
		return widgets;
	}
}
