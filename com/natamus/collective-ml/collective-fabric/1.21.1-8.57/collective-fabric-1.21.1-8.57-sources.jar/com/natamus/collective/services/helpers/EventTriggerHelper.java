package com.natamus.collective.services.helpers;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2424;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public interface EventTriggerHelper {
	void triggerNetherPortalSpawnEvent(class_1937 level, class_2338 portalPos, class_2424 size);
	void triggerLivingConversionEvent(class_1309 entity, class_1309 outcome);
	boolean triggerBlockBreakEvent(class_1937 level, class_1657 player, class_2338 pos, class_2680 state);
	void triggerAfterBlockBreakEvent(class_1937 level, class_1657 player, class_2338 pos, class_2680 state, class_2586 blockEntity);
}
