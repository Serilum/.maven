package com.natamus.collective.cmds;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.natamus.collective.config.DuskConfig;
import com.natamus.collective.config.DuskConfigEntry;
import com.natamus.collective.config.DuskConfigFile;
import com.natamus.collective.config.DuskConfigMod;
import com.natamus.collective.config.DuskConfigModToggles;
import com.natamus.collective.functions.MessageFunctions;
import com.natamus.collective.globalcallbacks.ConfigCallback;
import net.minecraft.class_124;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class CommandCollectiveConfig {
	public static LiteralArgumentBuilder<class_2168> getCommand() {
		LiteralArgumentBuilder<class_2168> configCommand = class_2170.method_9247("config")
			.requires((commandSourceStack) -> commandSourceStack.method_9259(3))
			.executes((command) -> {
				return showConfigMods(command.getSource());
			});

		DuskConfigModToggles.addListOnlyMods();
		for (String modid : getSortedModIds()) {
			configCommand.then(getModCommand(DuskConfigMod.configMods.get(modid)));
		}
		return configCommand;
	}

	private static LiteralArgumentBuilder<class_2168> getModCommand(DuskConfigMod configMod) {
		LiteralArgumentBuilder<class_2168> getSubcommand = class_2170.method_9247("get");
		LiteralArgumentBuilder<class_2168> setSubcommand = class_2170.method_9247("set");
		LiteralArgumentBuilder<class_2168> resetSubcommand = class_2170.method_9247("reset");
		LiteralArgumentBuilder<class_2168> addSubcommand = class_2170.method_9247("add");
		LiteralArgumentBuilder<class_2168> removeSubcommand = class_2170.method_9247("remove");

		boolean hasIdLists = false;
		for (DuskConfigEntry entry : configMod.getActiveEntries()) {
			String key = getCommandKey(entry);

			getSubcommand.then(class_2170.method_9247(key)
				.executes((command) -> {
					return showValue(command.getSource(), entry);
				}));

			setSubcommand.then(class_2170.method_9247(key)
				.then(class_2170.method_9244("value", StringArgumentType.greedyString())
				.suggests((context, builder) -> class_2172.method_9265(getValueSuggestions(entry), builder))
				.executes((command) -> {
					return setValue(command.getSource(), configMod, entry, StringArgumentType.getString(command, "value"));
				})));

			resetSubcommand.then(class_2170.method_9247(key)
				.executes((command) -> {
					return resetValue(command.getSource(), configMod, entry);
				}));

			if (entry.hasRegistry()) {
				hasIdLists = true;

				addSubcommand.then(class_2170.method_9247(key)
					.then(class_2170.method_9244("id", StringArgumentType.greedyString())
					.suggests((context, builder) -> class_2172.method_9265(getRegistryIds(context.getSource().method_9211(), entry.registry), builder))
					.executes((command) -> {
						return addId(command.getSource(), configMod, entry, StringArgumentType.getString(command, "id"));
					})));

				removeSubcommand.then(class_2170.method_9247(key)
					.then(class_2170.method_9244("id", StringArgumentType.greedyString())
					.suggests((context, builder) -> class_2172.method_9265(entry.getIdList(), builder))
					.executes((command) -> {
						return removeId(command.getSource(), configMod, entry, StringArgumentType.getString(command, "id"));
					})));
			}
		}

		LiteralArgumentBuilder<class_2168> modCommand = class_2170.method_9247(configMod.modid)
			.executes((command) -> {
				return showValues(command.getSource(), configMod);
			})
			.then(getSubcommand)
			.then(setSubcommand)
			.then(resetSubcommand)
			.then(class_2170.method_9247("reload")
			.executes((command) -> {
				return reloadConfig(command.getSource(), configMod);
			}));

		if (hasIdLists) {
			modCommand.then(addSubcommand).then(removeSubcommand);
		}
		return modCommand;
	}

	private static int showConfigMods(class_2168 source) {
		MessageFunctions.sendTranslatableMessage(source, "collective.collective.message.configmods", true, class_124.field_1077, String.join(", ", getSortedModIds()));
		return 1;
	}

	private static int showValues(class_2168 source, DuskConfigMod configMod) {
		MessageFunctions.sendTranslatableMessage(source, "collective.collective.gui.configtitle", true, class_124.field_1065, configMod.name);
		for (DuskConfigEntry entry : configMod.getActiveEntries()) {
			MessageFunctions.sendMessage(source, " " + getCommandKey(entry) + ": " + entry.getText(), class_124.field_1077);
		}
		return 1;
	}

	private static int showValue(class_2168 source, DuskConfigEntry entry) {
		MessageFunctions.sendTranslatableMessage(source, "options.generic_value", true, class_124.field_1077, getCommandKey(entry), entry.getText());
		showEntryInfo(source, entry);
		return 1;
	}

	private static int setValue(class_2168 source, DuskConfigMod configMod, DuskConfigEntry entry, String value) {
		if (!entry.setValueFromText(value.strip())) {
			MessageFunctions.sendTranslatableMessage(source, "collective.collective.message.configinvalid", class_124.field_1061, value.strip());
			showEntryInfo(source, entry);
			return 0;
		}

		DuskConfig.write(configMod.modid);
		MessageFunctions.sendTranslatableMessage(source, "collective.collective.message.configset", class_124.field_1077, getCommandKey(entry), entry.getText());
		showRestartNotice(source, configMod, entry);
		return 1;
	}

	private static int resetValue(class_2168 source, DuskConfigMod configMod, DuskConfigEntry entry) {
		entry.resetValue();

		DuskConfig.write(configMod.modid);
		MessageFunctions.sendTranslatableMessage(source, "collective.collective.message.configset", class_124.field_1077, getCommandKey(entry), entry.getText());
		showRestartNotice(source, configMod, entry);
		return 1;
	}

	private static int addId(class_2168 source, DuskConfigMod configMod, DuskConfigEntry entry, String id) {
		String newId = id.strip();
		List<String> idList = entry.getIdList();
		if (getIdIndex(idList, newId) != -1) {
			MessageFunctions.sendTranslatableMessage(source, "collective.collective.message.configidexists", class_124.field_1061, newId);
			return 0;
		}

		if (entry.single) {
			if (newId.contains("*")) {
				MessageFunctions.sendTranslatableMessage(source, "collective.collective.message.configinvalid", class_124.field_1061, newId);
				return 0;
			}
			idList.clear();
		}

		idList.add(newId);
		entry.setIdList(idList);

		DuskConfig.write(configMod.modid);
		MessageFunctions.sendTranslatableMessage(source, "collective.collective.message.configidadded", class_124.field_1077, newId);
		return 1;
	}

	private static int removeId(class_2168 source, DuskConfigMod configMod, DuskConfigEntry entry, String id) {
		String oldId = id.strip();
		List<String> idList = entry.getIdList();
		int index = getIdIndex(idList, oldId);
		if (index == -1) {
			MessageFunctions.sendTranslatableMessage(source, "collective.collective.message.configidmissing", class_124.field_1061, oldId);
			return 0;
		}

		idList.remove(index);
		entry.setIdList(idList);

		DuskConfig.write(configMod.modid);
		MessageFunctions.sendTranslatableMessage(source, "collective.collective.message.configidremoved", class_124.field_1077, oldId);
		return 1;
	}

	private static int reloadConfig(class_2168 source, DuskConfigMod configMod) {
		if (!DuskConfigFile.reload(configMod)) {
			MessageFunctions.sendTranslatableMessage(source, "collective.collective.message.configunreadable", class_124.field_1061);
			return 0;
		}
		ConfigCallback.CONFIG_CHANGED.invoker().onConfigChanged(configMod.modid);

		MessageFunctions.sendTranslatableMessage(source, "collective.collective.message.configreloaded", class_124.field_1077);
		return 1;
	}

	private static void showEntryInfo(class_2168 source, DuskConfigEntry entry) {
		String comment = entry.getComment();
		if (!comment.isEmpty()) {
			MessageFunctions.sendMessage(source, " " + comment, class_124.field_1080);
		}
		MessageFunctions.sendTranslatableMessage(source, " ", "collective.collective.message.configdefault", class_124.field_1080, entry.getDefaultText());
	}

	private static void showRestartNotice(class_2168 source, DuskConfigMod configMod, DuskConfigEntry entry) {
		if (entry == configMod.enableEntry) {
			MessageFunctions.sendTranslatableMessage(source, "collective.collective.message.configrestart", class_124.field_1065);
		}
	}

	private static String getCommandKey(DuskConfigEntry entry) {
		return entry.getName().replace(" ", "");
	}

	private static int getIdIndex(List<String> idList, String id) {
		for (int i = 0; i < idList.size(); i++) {
			if (idList.get(i).equalsIgnoreCase(id)) {
				return i;
			}
		}
		return -1;
	}

	private static List<String> getSortedModIds() {
		List<String> modids = new ArrayList<>(DuskConfigMod.configMods.keySet());
		Collections.sort(modids);
		return modids;
	}

	private static List<String> getValueSuggestions(DuskConfigEntry entry) {
		if (entry.isBoolean()) {
			return Arrays.asList("true", "false");
		}
		if (entry.hasOptions()) {
			return entry.options;
		}
		return Arrays.asList(entry.getText());
	}

	private static List<String> getRegistryIds(MinecraftServer server, String registryName) {
		List<String> ids = new ArrayList<>();
		if (registryName.equals(DuskConfigModToggles.modRegistry)) {
			return DuskConfigModToggles.getListableModIds();
		}
		if (registryName.equals("dimension")) {
			for (class_5321<class_1937> levelKey : server.method_29435()) {
				ids.add(levelKey.method_29177().toString());
			}
			return ids;
		}

		class_2960 registryId = class_2960.method_12829(registryName);
		if (registryId == null) {
			return ids;
		}

		class_2378<?> registry = class_7923.field_41167.method_10223(registryId);
		if (registry == null) {
			Optional<class_2378<Object>> worldRegistry = server.method_30611().method_33310(class_5321.method_29180(registryId));
			if (!worldRegistry.isPresent()) {
				return ids;
			}
			registry = worldRegistry.get();
		}

		for (class_2960 resourceLocation : registry.method_10235()) {
			ids.add(resourceLocation.toString());
		}
		return ids;
	}
}
