package com.natamus.collective.functions;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective.data.GlobalVariables;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import net.minecraft.class_1657;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_1966;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2794;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3215;
import net.minecraft.class_3218;
import net.minecraft.class_3620;
import net.minecraft.class_5321;
import net.minecraft.class_5742;
import net.minecraft.class_6544;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7138;
import net.minecraft.class_7924;

public class BlockPosFunctions {
	// START: GET functions
	public static List<class_2338> getBlocksAround(class_2338 pos, boolean down) {
		List<class_2338> around = new ArrayList<class_2338>();
		around.add(pos.method_10095());
		around.add(pos.method_10078());
		around.add(pos.method_10072());
		around.add(pos.method_10067());
		around.add(pos.method_10084());
		if (down) {
			around.add(pos.method_10074());
		}
		return around;
	}

	// START: RECURSIVE GET BLOCKS
	private static final HashMap<class_2338, Integer> rgnbcount = new HashMap<class_2338, Integer>();

	public static List<class_2338> getBlocksNextToEachOther(class_1937 level, class_2338 startPos, List<class_2248> possibleBlocks) {
		return getBlocksNextToEachOther(level, startPos, possibleBlocks, 50);
	}
	public static List<class_2338> getBlocksNextToEachOther(class_1937 level, class_2338 startPos, List<class_2248> possibleBlocks, int maxDistance) {
		List<class_2338> checkedBlocks = new ArrayList<class_2338>();
		List<class_2338> blocksAround = new ArrayList<class_2338>();
		if (possibleBlocks.contains(level.method_8320(startPos).method_26204())) {
			blocksAround.add(startPos);
			checkedBlocks.add(startPos);
		}

		rgnbcount.put(startPos.method_10062(), 0);
		recursiveGetNextBlocks(level, startPos, startPos, possibleBlocks, blocksAround, checkedBlocks, maxDistance);
		return blocksAround;
	}
	private static void recursiveGetNextBlocks(class_1937 level, class_2338 startPos, class_2338 pos, List<class_2248> possibleBlocks, List<class_2338> blocksAround, List<class_2338> checkedBlocks, int maxDistance) {
		int rgnbc = rgnbcount.get(startPos);
		if (rgnbc > 100) {
			return;
		}
		rgnbcount.put(startPos, rgnbc + 1);

		List<class_2338> possibleBlocksaround = getBlocksAround(pos, true);
		for (class_2338 pba : possibleBlocksaround) {
			if (checkedBlocks.contains(pba)) {
				continue;
			}
			checkedBlocks.add(pba);

			if (possibleBlocks.contains(level.method_8320(pba).method_26204())) {
				if (!blocksAround.contains(pba)) {
					blocksAround.add(pba);
					if (BlockPosFunctions.withinDistance(startPos, pba, maxDistance)) {
						recursiveGetNextBlocks(level, startPos, pba, possibleBlocks, blocksAround, checkedBlocks, maxDistance);
					}
				}
			}
		}
	}


	private static final HashMap<class_2338, Integer> rgnbtcount = new HashMap<class_2338, Integer>();

	public static List<class_2338> getBlocksNextToEachOtherTag(class_1937 level, class_2338 startPos, List<class_6862<class_2248>> possibleBlockTags) {
		return getBlocksNextToEachOtherTag(level, startPos, possibleBlockTags, 50);
	}
	public static List<class_2338> getBlocksNextToEachOtherTag(class_1937 level, class_2338 startPos, List<class_6862<class_2248>> possibleBlockTags, int maxDistance) {
		List<class_2338> checkedBlocks = new ArrayList<class_2338>();
		List<class_2338> blocksAround = new ArrayList<class_2338>();

		class_2680 startBlockState = level.method_8320(startPos);
		for (class_6862<class_2248> blockTagKey : possibleBlockTags) {
			if (startBlockState.method_26164(blockTagKey)) {
				blocksAround.add(startPos);
				checkedBlocks.add(startPos);
				break;
			}
		}

		rgnbtcount.put(startPos.method_10062(), 0);
		recursiveGetNextBlocksTag(level, startPos, startPos, possibleBlockTags, blocksAround, checkedBlocks, maxDistance);
		return blocksAround;
	}
	private static void recursiveGetNextBlocksTag(class_1937 level, class_2338 startPos, class_2338 pos, List<class_6862<class_2248>> possibleBlockTags, List<class_2338> blocksAround, List<class_2338> checkedBlocks, int maxDistance) {
		int rgnbc = rgnbtcount.get(startPos);
		if (rgnbc > 100) {
			return;
		}
		rgnbtcount.put(startPos, rgnbc + 1);

		List<class_2338> possibleBlocksaround = getBlocksAround(pos, true);
		for (class_2338 pba : possibleBlocksaround) {
			if (checkedBlocks.contains(pba)) {
				continue;
			}
			checkedBlocks.add(pba);

			class_2680 pbaState = level.method_8320(pba);
			for (class_6862<class_2248> blockTagKey : possibleBlockTags) {
				if (pbaState.method_26164(blockTagKey)) {
					if (!blocksAround.contains(pba)) {
						blocksAround.add(pba);
						if (BlockPosFunctions.withinDistance(startPos, pba, maxDistance)) {
							recursiveGetNextBlocksTag(level, startPos, pba, possibleBlockTags, blocksAround, checkedBlocks, maxDistance);
						}
					}
					break;
				}
			}
		}
	}


	private static final HashMap<class_2338, Integer> rgnbmcount = new HashMap<class_2338, Integer>();

	public static List<class_2338> getBlocksNextToEachOtherMaterial(class_1937 level, class_2338 startPos, List<class_3620> possibleMaterials) {
		return getBlocksNextToEachOtherMaterial(level, startPos, possibleMaterials, 50);
	}
	public static List<class_2338> getBlocksNextToEachOtherMaterial(class_1937 level, class_2338 startPos, List<class_3620> possibleMaterials, int maxDistance) {
		List<class_2338> checkedBlocks = new ArrayList<class_2338>();
		List<class_2338> blocksAround = new ArrayList<class_2338>();
		if (possibleMaterials.contains(level.method_8320(startPos).method_26205(level, startPos))) {
			blocksAround.add(startPos);
			checkedBlocks.add(startPos);
		}

		rgnbmcount.put(startPos.method_10062(), 0);
		recursiveGetNextBlocksMaterial(level, startPos, startPos, possibleMaterials, blocksAround, checkedBlocks, maxDistance);
		return blocksAround;
	}
	private static void recursiveGetNextBlocksMaterial(class_1937 level, class_2338 startPos, class_2338 pos, List<class_3620> possibleMaterials, List<class_2338> blocksAround, List<class_2338> checkedBlocks, int maxDistance) {
		int rgnbmc = rgnbmcount.get(startPos);
		if (rgnbmc > 100) {
			return;
		}
		rgnbmcount.put(startPos, rgnbmc + 1);

		List<class_2338> possibleBlocksaround = getBlocksAround(pos, true);
		for (class_2338 pba : possibleBlocksaround) {
			if (checkedBlocks.contains(pba)) {
				continue;
			}
			checkedBlocks.add(pba);

			if (possibleMaterials.contains(level.method_8320(pba).method_26205(level, pba))) {
				if (!blocksAround.contains(pba)) {
					blocksAround.add(pba);
					if (BlockPosFunctions.withinDistance(startPos, pba, maxDistance)) {
						recursiveGetNextBlocksMaterial(level, startPos, pba, possibleMaterials, blocksAround, checkedBlocks, maxDistance);
					}
				}
			}
		}
	}
	// END RECURSIVE GET BLOCKS

	public static class_2338 getSurfaceBlockPos(class_3218 serverLevel, int x, int z) {
		return getSurfaceBlockPos(serverLevel, x, z, false);
	}
	public static class_2338 getSurfaceBlockPos(class_3218 serverLevel, int x, int z, boolean ignoreTrees) {
		int height = serverLevel.method_31605();
		int lowestY = serverLevel.method_31607();

		class_2338 returnPos = new class_2338(x, height-1, z);
		if (!WorldFunctions.isNether(serverLevel)) {
			class_2338 pos = new class_2338(x, height, z);
			for (int y = height; y > lowestY; y--) {
				boolean continueCycle = false;

				class_2680 blockState = serverLevel.method_8320(pos);
				if (ignoreTrees) {
					class_2248 block = blockState.method_26204();
					if (CompareBlockFunctions.isTreeLeaf(block) || CompareBlockFunctions.isTreeLog(block)) {
						continueCycle = true;
					}
				}

				if (!continueCycle) {
					class_3620 material = blockState.method_26205(serverLevel, pos);
					if (blockState.method_26193(serverLevel, pos) >= 15 || GlobalVariables.surfacematerials.contains(material)) {
						returnPos = pos.method_10084().method_10062();
						break;
					}
				}

				pos = pos.method_10074();
			}
		}
		else {
			int maxHeight = 128;
			class_2338 pos = new class_2338(x, lowestY, z);
			for (int y = lowestY; y < maxHeight; y++) {
				class_2680 blockState = serverLevel.method_8320(pos);
				if (blockState.method_26204().equals(class_2246.field_10124)) {
					class_2680 upstate = serverLevel.method_8320(pos.method_10084());
					if (upstate.method_26204().equals(class_2246.field_10124)) {
						returnPos = pos.method_10062();
						break;
					}
				}

				pos = pos.method_10084();
			}
		}

		return returnPos;
	}

	public static class_2338 getCenterNearbyVillage(class_3218 serverLevel) {
		return getNearbyVillage(serverLevel, new class_2338(0, 0, 0));
	}
	public static class_2338 getNearbyVillage(class_3218 serverLevel, class_2338 nearPos) {
		return getNearbyVillage(serverLevel, nearPos, "#minecraft:village");
	}
	public static class_2338 getNearbyVillage(class_3218 serverLevel, class_2338 nearPos, String villageTag) {
		if (!serverLevel.method_8503().method_27728().method_28057().method_28029()) {
			return null;
		}

		class_6885<class_3195> villageStructures = getStructureHolderSet(serverLevel, villageTag);
		if (villageStructures == null) {
			return null;
		}

		return getSurfacePosOfNearestStructure(serverLevel, villageStructures, nearPos);
	}

	public static class_2338 getNearbyVillageInSameBiome(class_3218 serverLevel, class_2338 nearPos) {
		return getNearbyVillageInSameBiome(serverLevel, nearPos, "#minecraft:village");
	}
	public static class_2338 getNearbyVillageInSameBiome(class_3218 serverLevel, class_2338 nearPos, String villageTag) {
		if (!serverLevel.method_8503().method_27728().method_28057().method_28029()) {
			return null;
		}

		class_6885<class_3195> villageStructures = getStructureHolderSet(serverLevel, villageTag);
		if (villageStructures == null) {
			return null;
		}

		class_6880<class_1959> biome = serverLevel.method_23753(nearPos);
		List<class_6880<class_3195>> villagesInBiome = new ArrayList<>();
		for (class_6880<class_3195> village : villageStructures) {
			if (village.comp_349().method_41607().method_40241(biome)) {
				villagesInBiome.add(village);
			}
		}

		if (villagesInBiome.isEmpty()) {
			return null;
		}

		return getSurfacePosOfNearestStructure(serverLevel, class_6885.method_40242(villagesInBiome), nearPos);
	}

	private static class_2338 getSurfacePosOfNearestStructure(class_3218 serverLevel, class_6885<class_3195> structures, class_2338 nearPos) {
		Pair<class_2338, class_6880<class_3195>> nearestStructure = serverLevel.method_14178().method_12129().method_12103(serverLevel, structures, nearPos, 100, false);
		if (nearestStructure == null) {
			return null;
		}

		class_2338 structurePos = nearestStructure.getFirst();
		return getSurfaceBlockPos(serverLevel, structurePos.method_10263(), structurePos.method_10260());
	}

	public static class_6885<class_3195> getStructureHolderSet(class_3218 serverLevel, String structure) {
		String strippedStructure = structure.strip();
		class_2960 structureIdentifier = class_2960.method_12829(strippedStructure.replace("#", ""));
		if (structureIdentifier == null) {
			return null;
		}

		class_2378<class_3195> structureRegistry = serverLevel.method_30349().method_30530(class_7924.field_41246);
		if (strippedStructure.startsWith("#")) {
			Optional<class_6885.class_6888<class_3195>> optionalStructureTag = structureRegistry.method_40266(class_6862.method_40092(class_7924.field_41246, structureIdentifier));
			if (optionalStructureTag.isPresent()) {
				return optionalStructureTag.get();
			}
			return null;
		}

		Optional<class_6880.class_6883<class_3195>> optionalStructure = structureRegistry.method_40264(class_5321.method_29179(class_7924.field_41246, structureIdentifier));
		if (optionalStructure.isPresent()) {
			return class_6885.method_40246(optionalStructure.get());
		}
		return null;
	}

	public static class_2338 getCenterNearbyBiome(class_3218 serverLevel, String biome) {
		return getCenterNearbyBiome(serverLevel, biome, 6400, 16, false);
	}
	public static class_2338 getCenterNearbyBiome(class_3218 serverLevel, String biome, int searchRadius, int minimumDistanceFromBiomeEdge, boolean preferLand) {
		return getNearbyBiome(serverLevel, new class_2338(0, 0, 0), biome, searchRadius, minimumDistanceFromBiomeEdge, preferLand);
	}
	public static class_2338 getNearbyBiome(class_3218 serverLevel, class_2338 nearPos, String biome) {
		return getNearbyBiome(serverLevel, nearPos, biome, 6400, 16, false);
	}
	public static class_2338 getNearbyBiome(class_3218 serverLevel, class_2338 nearPos, String biome, int searchRadius, int minimumDistanceFromBiomeEdge, boolean preferLand) {
		Predicate<class_6880<class_1959>> biomePredicate = getBiomePredicate(biome);
		if (biomePredicate == null) {
			return null;
		}

		class_3215 chunkSource = serverLevel.method_14178();
		class_2794 chunkGenerator = chunkSource.method_12129();
		class_1966 biomeSource = chunkGenerator.method_12098();
		if (!canBiomeSourceGenerate(biomeSource, biomePredicate)) {
			return null;
		}

		class_7138 randomState = chunkSource.method_41248();
		class_6544.class_6552 climateSampler = randomState.method_42371();

		class_2338 firstColumnWithBiome = null;
		class_2338 firstLandColumnNearEdge = null;
		class_2338 firstWaterColumnAwayFromEdge = null;
		class_2338 firstWaterColumnNearEdge = null;
		int surfaceChecks = 0;

		for (class_2338.class_2339 sampleColumn : class_2338.method_30512(class_2338.field_10980, searchRadius / 32, class_2350.field_11034, class_2350.field_11035)) {
			int x = nearPos.method_10263() + sampleColumn.method_10263() * 32;
			int z = nearPos.method_10260() + sampleColumn.method_10260() * 32;
			if (!isBiomeInColumn(serverLevel, biomeSource, climateSampler, biomePredicate, x, z)) {
				continue;
			}

			if (firstColumnWithBiome == null) {
				firstColumnWithBiome = new class_2338(x, 0, z);
			}

			int surfaceY = chunkGenerator.method_16397(x, z, class_2902.class_2903.field_13194, serverLevel, randomState);
			if (isBiomeAt(biomeSource, climateSampler, biomePredicate, x, surfaceY, z)) {
				boolean isAwayFromEdge = isBiomeAroundOnSurface(biomeSource, climateSampler, biomePredicate, x, surfaceY, z, minimumDistanceFromBiomeEdge);
				boolean isOnLand = !preferLand || isLandColumn(serverLevel, chunkGenerator, randomState, x, surfaceY, z);
				if (isAwayFromEdge && isOnLand) {
					return getSurfaceBlockPos(serverLevel, x, z);
				}

				class_2338 column = new class_2338(x, 0, z);
				if (isOnLand && firstLandColumnNearEdge == null) {
					firstLandColumnNearEdge = column;
				}
				else if (!isOnLand && isAwayFromEdge && firstWaterColumnAwayFromEdge == null) {
					firstWaterColumnAwayFromEdge = column;
				}
				else if (!isOnLand && !isAwayFromEdge && firstWaterColumnNearEdge == null) {
					firstWaterColumnNearEdge = column;
				}
			}

			surfaceChecks += 1;
			if (surfaceChecks >= 512) {
				break;
			}
		}

		class_2338 bestColumn = getFirstFoundColumn(firstLandColumnNearEdge, firstWaterColumnAwayFromEdge, firstWaterColumnNearEdge, firstColumnWithBiome);
		if (bestColumn == null) {
			return null;
		}

		return getSurfaceBlockPos(serverLevel, bestColumn.method_10263(), bestColumn.method_10260());
	}

	private static boolean isLandColumn(class_3218 serverLevel, class_2794 chunkGenerator, class_7138 randomState, int x, int surfaceY, int z) {
		return chunkGenerator.method_16397(x, z, class_2902.class_2903.field_13195, serverLevel, randomState) >= surfaceY;
	}

	private static class_2338 getFirstFoundColumn(class_2338... columnsInOrderOfPreference) {
		for (class_2338 column : columnsInOrderOfPreference) {
			if (column != null) {
				return column;
			}
		}
		return null;
	}

	private static Predicate<class_6880<class_1959>> getBiomePredicate(String biome) {
		String strippedBiome = biome.strip();
		class_2960 biomeIdentifier = class_2960.method_12829(strippedBiome.replace("#", ""));
		if (biomeIdentifier == null) {
			return null;
		}

		if (strippedBiome.startsWith("#")) {
			class_6862<class_1959> biomeTag = class_6862.method_40092(class_7924.field_41236, biomeIdentifier);
			return biomeHolder -> biomeHolder.method_40220(biomeTag);
		}

		class_5321<class_1959> biomeKey = class_5321.method_29179(class_7924.field_41236, biomeIdentifier);
		return biomeHolder -> biomeHolder.method_40225(biomeKey);
	}

	private static boolean canBiomeSourceGenerate(class_1966 biomeSource, Predicate<class_6880<class_1959>> biomePredicate) {
		for (class_6880<class_1959> possibleBiome : biomeSource.method_28443()) {
			if (biomePredicate.test(possibleBiome)) {
				return true;
			}
		}
		return false;
	}

	private static boolean isBiomeInColumn(class_3218 serverLevel, class_1966 biomeSource, class_6544.class_6552 climateSampler, Predicate<class_6880<class_1959>> biomePredicate, int x, int z) {
		for (int y = serverLevel.method_31607(); y < serverLevel.method_31600(); y += 64) {
			if (isBiomeAt(biomeSource, climateSampler, biomePredicate, x, y, z)) {
				return true;
			}
		}
		return false;
	}

	private static boolean isBiomeAroundOnSurface(class_1966 biomeSource, class_6544.class_6552 climateSampler, Predicate<class_6880<class_1959>> biomePredicate, int x, int surfaceY, int z, int distance) {
		for (class_2350 direction : class_2350.class_2353.field_11062) {
			int aroundX = x + direction.method_10148() * distance;
			int aroundZ = z + direction.method_10165() * distance;
			if (!isBiomeAt(biomeSource, climateSampler, biomePredicate, aroundX, surfaceY, aroundZ)) {
				return false;
			}
		}
		return true;
	}

	private static boolean isBiomeAt(class_1966 biomeSource, class_6544.class_6552 climateSampler, Predicate<class_6880<class_1959>> biomePredicate, int x, int y, int z) {
		return biomePredicate.test(biomeSource.method_38109(class_5742.method_33100(x), class_5742.method_33100(y), class_5742.method_33100(z), climateSampler));
	}

	public static class_2338 getCenterNearbyStructure(class_3218 serverLevel, class_6885<class_3195> structure) {
		return getNearbyStructure(serverLevel, structure, new class_2338(0, 0, 0));
	}
	public static class_2338 getNearbyStructure(class_3218 serverLevel, class_6885<class_3195> structure, class_2338 nearPos) {
		return getNearbyStructure(serverLevel, structure, nearPos, 9999);
	}
	public static class_2338 getNearbyStructure(class_3218 serverLevel, class_6885<class_3195> structure, class_2338 nearPos, int radius) {
		Pair<class_2338, class_6880<class_3195>> pair = serverLevel.method_14178().method_12129().method_12103(serverLevel, structure, nearPos, radius, false);
		if (pair == null) {
			return null;
		}

		class_2338 villagePos = pair.getFirst();
		if (villagePos == null) {
			return null;
		}

		class_2338 spawnpos = null;
		for (int y = serverLevel.method_31605()-1; y > 0; y--) {
			class_2338 checkpos = new class_2338(villagePos.method_10263(), y, villagePos.method_10260());
			if (serverLevel.method_8320(checkpos).method_26204().equals(class_2246.field_10124)) {
				continue;
			}
			spawnpos = checkpos.method_10084().method_10062();
			break;
		}

		return spawnpos;
	}

	public static class_2338 getBlockPlayerIsLookingAt(class_1937 level, class_1657 player, boolean stopOnLiquid) {
		class_239 raytraceresult = RayTraceFunctions.rayTrace(level, player, stopOnLiquid);
		double posX = raytraceresult.method_17784().field_1352;
		double posY = Math.floor(raytraceresult.method_17784().field_1351);
		double posZ = raytraceresult.method_17784().field_1350;

		return class_2338.method_49637(posX, posY, posZ);
	}

	public static class_2338 getRandomCoordinatesInNearestUngeneratedChunk(class_3218 serverLevel, class_2338 aroundPosition) {
		List<String> regionList = new ArrayList<String>();

		try {
			File regionFolder = new File(WorldFunctions.getWorldPath(serverLevel) + File.separator + "region");
			File[] listOfRegionFiles = regionFolder.listFiles();

			for (File regionFile : listOfRegionFiles) {
				if (regionFile.isFile()) {
					regionList.add(regionFile.getName().replaceAll("r.", "").replaceAll(".mca", ""));
				}
			}
		}
		catch(NullPointerException ignored) {
			return null;
		}

		class_1923 chunkPos = serverLevel.method_8500(aroundPosition).method_12004();
		int curRegionX = chunkPos.method_17885();
		int curRegionZ = chunkPos.method_17886();

		int currentRange = 1;
		int loops = 0;

		String closestUngeneratedRegionString = "";
		while (closestUngeneratedRegionString.equals("")) {
			for (int x = -1; x <= 1; x++) {
				for (int z = -1; z <= 1; z++) {
					int regionX = curRegionX + (x*currentRange);
					int regionZ = curRegionZ + (z*currentRange);

					String regionString = regionX + "." + regionZ;
					if (!regionList.contains(regionString)) {
						closestUngeneratedRegionString = regionString;
						break;
					}
				}
				if (!closestUngeneratedRegionString.equals("")) {
					break;
				}
			}

			currentRange += 1;
			loops += 1;

			if (loops > 50) {
				return null;
			}
		}

		int outputRegionX, outputRegionZ;

		String[] cursspl = closestUngeneratedRegionString.split("\\.");
		try {
			outputRegionX = Integer.parseInt(cursspl[0]);
			outputRegionZ = Integer.parseInt(cursspl[1]);
		}
		catch (NumberFormatException ex) {
			return null;
		}

		int minXRange = (outputRegionX * 512) - 256;
		int maxXRange = (outputRegionX * 512) + 256;
		int minZRange = (outputRegionZ * 512) - 256;
		int maxZRange = (outputRegionZ * 512) + 256;

		int randomXCoord = ThreadLocalRandom.current().nextInt(minXRange, maxXRange + 1);
		int randomZCoord = ThreadLocalRandom.current().nextInt(minZRange, maxZRange + 1);
		int randomYCoord = BlockPosFunctions.getSurfaceBlockPos(serverLevel, randomXCoord, randomZCoord).method_10264();

		return new class_2338(randomXCoord, randomYCoord, randomZCoord);
	}
	// END: GET functions


	// START: CHECK functions
	public static Boolean isOnSurface(class_1937 level, class_2338 pos) {
		return level.method_8311(pos);
	}
	public static Boolean isOnSurface(class_1937 level, class_243 vecPos) {
		return isOnSurface(level, class_2338.method_49637(vecPos.field_1352, vecPos.field_1351, vecPos.field_1350));
	}


	public static Boolean withinDistance(class_2338 start, class_2338 end, int distance) {
		return withinDistance(start, end, (double) distance);
	}
	public static Boolean withinDistance(class_2338 start, class_2338 end, double distance) {
		return start.method_19771(end, distance);
	}
	// END: CHECK functions

	public static class_2338 getBlockPosFromHitResult(class_239 hitResult) {
		class_243 vec = hitResult.method_17784();
		return class_2338.method_49637(vec.field_1352, vec.field_1351, vec.field_1350);
	}
}