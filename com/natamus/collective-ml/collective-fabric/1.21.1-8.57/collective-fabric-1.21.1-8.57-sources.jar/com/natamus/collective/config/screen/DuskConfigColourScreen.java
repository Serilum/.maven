package com.natamus.collective.config.screen;

import com.natamus.collective.config.DuskConfigEntry;
import com.natamus.collective.functions.ColourFunctions;
import org.jetbrains.annotations.NotNull;

import java.util.Locale;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;

public class DuskConfigColourScreen extends DuskConfigBaseScreen {
	private static final int areaSize = 120;

	private final class_437 parent;
	private final DuskConfigEntry entry;
	private final int originalColour;
	private int colour;
	private float hue;
	private float saturation;
	private float brightness;
	private int areaX;
	private int hueBarX;
	private int fieldsX;
	private class_342 redBox;
	private class_342 greenBox;
	private class_342 blueBox;
	private class_342 hexBox;
	private boolean updatingBoxes = false;

	public DuskConfigColourScreen(class_437 parent, DuskConfigEntry entry) {
		super(class_2561.method_43470(entry.getDisplayName()));
		this.parent = parent;
		this.entry = entry;

		int entryColour = entry.getRgbColour();
		if (entryColour == -1) {
			entryColour = 0xFFFFFF;
		}
		this.originalColour = entryColour;
		setColour(entryColour);
	}

	@Override
	protected void method_25426() {
		super.method_25426();

		areaX = this.field_22789 / 2 - 130;
		hueBarX = areaX + areaSize + 8;
		fieldsX = hueBarX + 28;

		this.method_37063(new DuskConfigDragArea(areaX, 40, areaSize, areaSize, (x, y) -> {
			saturation = x;
			brightness = 1 - y;
			colour = getColourFromHsv(hue, saturation, brightness);
			updateChannelBoxes();
			updateHexBox();
		}, this::drawSaturationBrightness));
		this.method_37063(new DuskConfigDragArea(hueBarX, 40, 12, areaSize, (x, y) -> {
			hue = y;
			colour = getColourFromHsv(hue, saturation, brightness);
			updateChannelBoxes();
			updateHexBox();
		}, this::drawHueBar));

		this.method_37063(new DuskConfigSwatch(fieldsX, 50, 50, 20, () -> colour));
		this.method_37063(new DuskConfigSwatch(fieldsX + 54, 50, 50, 20, () -> originalColour));

		redBox = addChannelBox(86, "color.minecraft.red");
		greenBox = addChannelBox(110, "color.minecraft.green");
		blueBox = addChannelBox(134, "color.minecraft.blue");

		hexBox = this.method_37063(new class_342(this.field_22793, fieldsX + 20, 158, 64, 20, class_2561.method_43471("collective.collective.gui.hex")));
		hexBox.method_1880(7);
		hexBox.method_1863(text -> onHexChanged());

		updateChannelBoxes();
		updateHexBox();

		addCancelButton(this.field_22789 / 2 - 154, this.field_22790 - 28);
		this.method_37063(class_4185.method_46430(class_5244.field_24334, button -> {
			entry.setValue(ColourFunctions.getRgbString(colour));
			method_25419();
		}).method_46433(this.field_22789 / 2 + 4, this.field_22790 - 28).method_46437(150, 20).method_46431());
	}

	@Override
	protected boolean hasUnsavedChanges() {
		return colour != originalColour;
	}

	private class_342 addChannelBox(int y, String colourKey) {
		class_342 channelBox = this.method_37063(new class_342(this.field_22793, fieldsX + 20, y, 40, 20, class_2561.method_43471(colourKey)));
		channelBox.method_1880(3);
		channelBox.method_1863(text -> onChannelChanged());
		return channelBox;
	}

	private void onChannelChanged() {
		if (updatingBoxes) {
			return;
		}

		int rgbColour = ColourFunctions.getRgbColour(redBox.method_1882() + "," + greenBox.method_1882() + "," + blueBox.method_1882());
		if (rgbColour == -1) {
			return;
		}

		setColour(rgbColour);
		updateHexBox();
	}

	private void onHexChanged() {
		if (updatingBoxes) {
			return;
		}

		String hex = hexBox.method_1882().strip().replace("#", "");
		if (!hex.matches("[0-9a-fA-F]{6}")) {
			return;
		}

		setColour(Integer.parseInt(hex, 16));
		updateChannelBoxes();
	}

	private void updateChannelBoxes() {
		updatingBoxes = true;
		redBox.method_1852(String.valueOf((colour >> 16) & 0xFF));
		greenBox.method_1852(String.valueOf((colour >> 8) & 0xFF));
		blueBox.method_1852(String.valueOf(colour & 0xFF));
		updatingBoxes = false;
	}

	private void updateHexBox() {
		updatingBoxes = true;
		hexBox.method_1852(String.format(Locale.ROOT, "#%06X", colour));
		updatingBoxes = false;
	}

	private void setColour(int rgbColour) {
		colour = rgbColour;

		float red = ((rgbColour >> 16) & 0xFF) / 255F;
		float green = ((rgbColour >> 8) & 0xFF) / 255F;
		float blue = (rgbColour & 0xFF) / 255F;
		float max = Math.max(red, Math.max(green, blue));
		float delta = max - Math.min(red, Math.min(green, blue));

		brightness = max;
		saturation = 0;
		if (max > 0) {
			saturation = delta / max;
		}

		if (delta == 0) {
			return;
		}

		if (max == red) {
			hue = ((green - blue) / delta) / 6;
		}
		else if (max == green) {
			hue = ((blue - red) / delta + 2) / 6;
		}
		else {
			hue = ((red - green) / delta + 4) / 6;
		}

		if (hue < 0) {
			hue += 1;
		}
	}

	private static int getColourFromHsv(float hue, float saturation, float brightness) {
		return class_3532.method_15369(Math.min(hue, 0.999F), saturation, brightness) & 0xFFFFFF;
	}

	private void drawSaturationBrightness(class_332 guiGraphics) {
		for (int column = 0; column < areaSize; column++) {
			int topColour = 0xFF000000 | getColourFromHsv(hue, column / (float) (areaSize - 1), 1);
			guiGraphics.method_25296(areaX + column, 40, areaX + column + 1, 40 + areaSize, topColour, 0xFF000000);
		}

		int markerX = areaX + Math.round(saturation * (areaSize - 1));
		int markerY = 40 + Math.round((1 - brightness) * (areaSize - 1));
		drawMarker(guiGraphics, markerX - 2, markerY - 2, markerX + 3, markerY + 3);
	}

	private void drawHueBar(class_332 guiGraphics) {
		for (int row = 0; row < areaSize; row++) {
			guiGraphics.method_25294(hueBarX, 40 + row, hueBarX + 12, 41 + row, 0xFF000000 | getColourFromHsv(row / (float) (areaSize - 1), 1, 1));
		}

		int markerY = 40 + Math.round(hue * (areaSize - 1));
		drawMarker(guiGraphics, hueBarX - 1, markerY - 1, hueBarX + 13, markerY + 2);
	}

	private static void drawMarker(class_332 guiGraphics, int left, int top, int right, int bottom) {
		guiGraphics.method_25294(left, top, right, top + 1, 0xFFFFFFFF);
		guiGraphics.method_25294(left, bottom - 1, right, bottom, 0xFFFFFFFF);
		guiGraphics.method_25294(left, top, left + 1, bottom, 0xFFFFFFFF);
		guiGraphics.method_25294(right - 1, top, right, bottom, 0xFFFFFFFF);
	}

	@Override
	public void method_25419() {
		this.field_22787.method_1507(parent);
	}

	@Override
	public void method_25420(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		if (this.field_22787.field_1687 == null) {
			this.method_57728(guiGraphics, partialTick);
		}

		this.method_57734(partialTick);
	}

	@Override
	public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

		guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 12, 0xFFFFFFFF);
		guiGraphics.method_27535(this.field_22793, class_2561.method_43471("collective.collective.gui.new"), fieldsX, 40, 0xFFA0A0A0);
		guiGraphics.method_27535(this.field_22793, class_2561.method_43471("collective.collective.gui.old"), fieldsX + 54, 40, 0xFFA0A0A0);
		guiGraphics.method_25303(this.field_22793, getInitial("color.minecraft.red"), fieldsX, 92, 0xFFA0A0A0);
		guiGraphics.method_25303(this.field_22793, getInitial("color.minecraft.green"), fieldsX, 116, 0xFFA0A0A0);
		guiGraphics.method_25303(this.field_22793, getInitial("color.minecraft.blue"), fieldsX, 140, 0xFFA0A0A0);
		guiGraphics.method_27535(this.field_22793, class_2561.method_43471("collective.collective.gui.hex"), fieldsX - 4, 164, 0xFFA0A0A0);
	}

	private static String getInitial(String colourKey) {
		String colourName = class_2561.method_43471(colourKey).getString();
		return colourName.substring(0, colourName.offsetByCodePoints(0, 1));
	}
}
