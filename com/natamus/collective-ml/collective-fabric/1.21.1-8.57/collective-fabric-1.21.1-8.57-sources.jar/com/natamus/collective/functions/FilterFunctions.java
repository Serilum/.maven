package com.natamus.collective.functions;

import com.natamus.collective.services.Services;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_3481;
import net.minecraft.class_5151;

public class FilterFunctions {
	public static boolean isInFilter(String filter, Object value) {
		if (value instanceof class_1792 item) {
			return isInItemFilter(filter, item);
		}
		if (value instanceof class_2248 block) {
			return isInBlockFilter(filter, block);
		}
		if (value instanceof class_1299<?> entityType) {
			return isInEntityTypeFilter(filter, entityType);
		}
		return false;
	}

	public static boolean isInItemFilter(String filter, class_1792 item) {
		class_1799 itemStack = new class_1799(item);
		return switch (filter) {
			case "tools" -> Services.TOOLFUNCTIONS.isTool(itemStack) || Services.TOOLFUNCTIONS.isSword(itemStack) || (itemStack.method_7963() && !(item instanceof class_5151));
			case "axes" -> Services.TOOLFUNCTIONS.isAxe(itemStack);
			case "pickaxes" -> Services.TOOLFUNCTIONS.isPickaxe(itemStack);
			case "shovels" -> Services.TOOLFUNCTIONS.isShovel(itemStack);
			case "hoes" -> Services.TOOLFUNCTIONS.isHoe(itemStack);
			case "swords" -> Services.TOOLFUNCTIONS.isSword(itemStack);
			case "blocks" -> item instanceof class_1747;
			default -> false;
		};
	}

	public static boolean isInBlockFilter(String filter, class_2248 block) {
		return switch (filter) {
			case "logs" -> block.method_9564().method_26164(class_3481.field_15475);
			case "leaves" -> block.method_9564().method_26164(class_3481.field_15503);
			case "ores" -> Services.BLOCKTAGS.isOre(block.method_9564(), true);
			default -> false;
		};
	}

	public static boolean isInEntityTypeFilter(String filter, class_1299<?> entityType) {
		class_1311 category = entityType.method_5891();
		return switch (filter) {
			case "mobs" -> category != class_1311.field_17715;
			case "monsters" -> category == class_1311.field_6302;
			case "animals" -> category != class_1311.field_17715 && category.method_6136();
			default -> false;
		};
	}
}
