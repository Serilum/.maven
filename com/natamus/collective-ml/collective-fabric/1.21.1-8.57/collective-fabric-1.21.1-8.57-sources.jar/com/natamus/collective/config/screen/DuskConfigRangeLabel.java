package com.natamus.collective.config.screen;

import com.natamus.collective.config.DuskConfigEntry;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;
import org.jetbrains.annotations.NotNull;

public class DuskConfigRangeLabel extends class_339 {
	private final String min;
	private final String max;

	public DuskConfigRangeLabel(int x, int width, DuskConfigEntry entry) {
		super(x, 0, width, 20, class_2561.method_43473());
		this.min = entry.getMinText();
		this.max = entry.getMaxText();
		this.field_22763 = false;
	}

	@Override
	protected void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		class_327 font = class_310.method_1551().field_1772;

		guiGraphics.method_51448().method_22903();
		guiGraphics.method_51448().method_46416(this.method_46426(), this.method_46427(), 0);
		guiGraphics.method_51448().method_22905(0.85F, 0.85F, 1F);

		class_2561 minLabel = class_2561.method_43471("collective.collective.gui.min");
		class_2561 maxLabel = class_2561.method_43471("collective.collective.gui.max");
		int valueX = Math.max(font.method_27525(minLabel), font.method_27525(maxLabel)) + 5;

		guiGraphics.method_27535(font, minLabel, 0, 2, 0xFF808080);
		guiGraphics.method_25303(font, min, valueX, 2, 0xFFC0C0C0);
		guiGraphics.method_27535(font, maxLabel, 0, 13, 0xFF808080);
		guiGraphics.method_25303(font, max, valueX, 13, 0xFFC0C0C0);

		guiGraphics.method_51448().method_22909();
	}

	@Override
	protected void method_47399(@NotNull class_6382 narrationElementOutput) { }
}
