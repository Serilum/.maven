package com.natamus.collective.config.screen;

import org.jetbrains.annotations.NotNull;

import java.util.function.IntSupplier;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

public class DuskConfigSwatch extends class_339 {
	private final IntSupplier colourSupplier;

	public DuskConfigSwatch(int x, int y, int width, int height, IntSupplier colourSupplier) {
		super(x, y, width, height, class_2561.method_43473());
		this.colourSupplier = colourSupplier;
		this.field_22763 = false;
	}

	@Override
	protected void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		int x = this.method_46426();
		int y = this.method_46427();

		guiGraphics.method_25294(x, y, x + this.field_22758, y + this.field_22759, 0xFF000000);
		guiGraphics.method_25294(x + 1, y + 1, x + this.field_22758 - 1, y + this.field_22759 - 1, 0xFF000000 | colourSupplier.getAsInt());
	}

	@Override
	protected void method_47399(@NotNull class_6382 narrationElementOutput) { }
}
