package com.natamus.collective.config.screen;

import com.natamus.collective.services.Services;
import com.natamus.collective.util.CollectiveReference;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class DuskConfigModIcons {
	private static final HashMap<String, DuskConfigModIcons> icons = new HashMap<>();

	public final class_2960 texture;
	public final int width;
	public final int height;

	private DuskConfigModIcons(class_2960 texture, int width, int height) {
		this.texture = texture;
		this.width = width;
		this.height = height;
	}

	public static DuskConfigModIcons getIcon(String modid) {
		if (icons.containsKey(modid)) {
			return icons.get(modid);
		}

		DuskConfigModIcons icon = loadIcon(modid);
		icons.put(modid, icon);
		return icon;
	}

	private static DuskConfigModIcons loadIcon(String modid) {
		byte[] iconBytes = Services.MODLOADER.getModIcon(modid);
		if (iconBytes == null) {
			return null;
		}

		class_1011 image;
		try {
			image = class_1011.method_4309(new ByteArrayInputStream(iconBytes));
		}
		catch (IOException ignored) {
			return null;
		}

		class_2960 texture = class_2960.method_60655(CollectiveReference.MOD_ID, "modicon/" + modid);
		DuskConfigModIcons icon = new DuskConfigModIcons(texture, image.method_4307(), image.method_4323());
		class_310.method_1551().method_1531().method_4616(texture, new class_1043(image));
		return icon;
	}
}
