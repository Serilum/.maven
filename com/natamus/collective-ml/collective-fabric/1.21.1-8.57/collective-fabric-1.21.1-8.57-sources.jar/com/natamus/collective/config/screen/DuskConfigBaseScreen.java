package com.natamus.collective.config.screen;

import com.natamus.collective.config.CollectiveConfigHandler;
import com.natamus.collective.config.DuskConfigFile;
import com.natamus.collective.config.DuskConfigMod;
import com.natamus.collective.util.CollectiveReference;
import net.minecraft.class_1041;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import org.jetbrains.annotations.NotNull;

public abstract class DuskConfigBaseScreen extends class_437 {
	private class_4185 cancelButton;
	private boolean cancelPending = false;
	private static final int smallestGuiScale = 2;

	protected DuskConfigBaseScreen(class_2561 title) {
		super(title);
	}

	protected abstract boolean hasUnsavedChanges();

	protected void addCancelButton(int x, int y) {
		cancelPending = false;
		cancelButton = this.method_37063(class_4185.method_46430(class_5244.field_24335, button -> pressCancel()).method_46433(x, y).method_46437(150, 20).method_46431());
	}

	private void pressCancel() {
		if (cancelPending || !hasUnsavedChanges()) {
			method_25419();
			return;
		}

		cancelPending = true;
		cancelButton.method_25355(class_2561.method_43471("collective.collective.gui.discardchanges").method_27692(class_124.field_1061));
	}

	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers) {
		if (keyCode == class_3675.field_31958 && this.method_25422()) {
			pressCancel();
			return true;
		}
		return super.method_25404(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		boolean pendingBeforeClick = cancelPending;
		boolean handled = super.method_25402(mouseX, mouseY, button);

		if (pendingBeforeClick && cancelPending) {
			cancelPending = false;
			cancelButton.method_25355(class_5244.field_24335);
		}
		return handled;
	}

	@Override
	public void method_49589() {
		super.method_49589();
		applyGuiScale();
	}

	@Override
	public void method_25432() {
		super.method_25432();
		class_310.method_1551().method_22683().method_15997(getGameGuiScale());
	}

	@Override
	public void method_25410(@NotNull class_310 minecraft, int width, int height) {
		applyGuiScale();

		class_1041 window = minecraft.method_22683();
		super.method_25410(minecraft, window.method_4486(), window.method_4502());
	}

	protected void cycleGuiScale(boolean smaller) {
		int guiScale = getScreenGuiScale();
		if (smaller) {
			guiScale -= 1;
		}
		else {
			guiScale += 1;
		}

		int maxGuiScale = getMaxGuiScale();
		if (guiScale < smallestGuiScale) {
			guiScale = maxGuiScale;
		}
		else if (guiScale > maxGuiScale) {
			guiScale = smallestGuiScale;
		}

		if (guiScale == getGameGuiScale()) {
			guiScale = 0;
		}

		CollectiveConfigHandler.configScreenGuiScale = guiScale;
		DuskConfigMod collectiveConfig = DuskConfigMod.configMods.get(CollectiveReference.MOD_ID);
		DuskConfigFile.writeValue(collectiveConfig, collectiveConfig.getEntry("configScreenGuiScale"));
		this.method_25410(class_310.method_1551(), this.field_22789, this.field_22790);
	}

	protected class_2561 getGuiScaleLabel() {
		if (CollectiveConfigHandler.configScreenGuiScale <= 0) {
			return class_2561.method_43471("options.guiScale.auto");
		}
		return class_2561.method_43470(String.valueOf(getScreenGuiScale()));
	}

	private void applyGuiScale() {
		class_310.method_1551().method_22683().method_15997(getScreenGuiScale());
	}

	private int getScreenGuiScale() {
		int guiScale = CollectiveConfigHandler.configScreenGuiScale;
		if (guiScale <= 0) {
			return getGameGuiScale();
		}
		return Math.max(smallestGuiScale, Math.min(guiScale, getMaxGuiScale()));
	}

	private int getGameGuiScale() {
		class_310 minecraft = class_310.method_1551();
		return minecraft.method_22683().method_4476(minecraft.field_1690.method_42474().method_41753(), minecraft.method_1573());
	}

	private int getMaxGuiScale() {
		class_310 minecraft = class_310.method_1551();
		return minecraft.method_22683().method_4476(0, minecraft.method_1573()) + 1;
	}
}
