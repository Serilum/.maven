package com.natamus.collective.config.screen;

import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_4265;

public class DuskConfigList extends class_4265<DuskConfigRow> {
	public DuskConfigList(class_310 minecraft, int width, int height, int y, int rowHeight) {
		super(minecraft, width, height, y, rowHeight);
		this.field_22744 = false;
	}

	public void setRows(List<DuskConfigRow> rows) {
		double scroll = this.method_25341();
		this.method_25314(rows);
		this.method_25307(scroll);
	}

	@Override
	protected boolean method_53812(int button) {
		return button == class_3675.field_32000 || button == class_3675.field_32002;
	}

	@Override
	public int method_25322() {
		return 10000;
	}

	@Override
	protected int method_25329() {
		return this.field_22758 - 7;
	}
}
