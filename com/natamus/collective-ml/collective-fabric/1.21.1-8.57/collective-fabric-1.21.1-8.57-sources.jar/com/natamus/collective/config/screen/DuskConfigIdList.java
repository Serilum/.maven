package com.natamus.collective.config.screen;

import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_4265;

public class DuskConfigIdList extends class_4265<DuskConfigIdRow> {
	public DuskConfigIdList(class_310 minecraft, int x, int y, int width, int height) {
		super(minecraft, width, height, y, 24);
		this.field_22744 = false;
		this.method_46421(x);
	}

	public void setRows(List<DuskConfigIdRow> rows) {
		double scroll = this.method_25341();
		this.method_25314(rows);
		this.method_25307(scroll);
	}

	@Override
	public int method_25322() {
		return this.field_22758 - 12;
	}

	@Override
	protected int method_25329() {
		return this.method_46426() + this.field_22758 - 6;
	}
}
