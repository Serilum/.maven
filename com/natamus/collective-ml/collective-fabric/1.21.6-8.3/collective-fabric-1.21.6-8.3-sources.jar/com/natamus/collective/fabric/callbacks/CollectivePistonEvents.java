package com.natamus.collective.fabric.callbacks;

import com.natamus.collective.implementations.event.Event;
import com.natamus.collective.implementations.event.EventFactory;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public class CollectivePistonEvents {
	private CollectivePistonEvents() { }
	 
    public static final Event<Piston_Activate> PRE_PISTON_ACTIVATE = EventFactory.createArrayBacked(Piston_Activate.class, callbacks -> (level, blockPos, direction, isExtending) -> {
        for (Piston_Activate callback : callbacks) {
        	if (!callback.onPistonActivate(level, blockPos, direction, isExtending)) {
				return false;
			}
        }
		return true;
    });
    
	@FunctionalInterface
	public interface Piston_Activate {
		 boolean onPistonActivate(class_1937 level, class_2338 blockPos, class_2350 direction, boolean isExtending);
	}
}
