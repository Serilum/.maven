package com.natamus.collective.fabric.callbacks;

import com.natamus.collective.implementations.event.Event;
import com.natamus.collective.implementations.event.EventFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class CollectiveAttackEvents {
	private CollectiveAttackEvents() { }
	 
    public static final Event<On_Arrow_Nock> ON_ARROW_NOCK = EventFactory.createArrayBacked(On_Arrow_Nock.class, callbacks -> (item, level, player, hand, hasAmmo) -> {
        for (On_Arrow_Nock callback : callbacks) {
			class_1269 interactionResult = callback.onArrowNock(item, level, player, hand, hasAmmo);
        	if (!interactionResult.equals(class_1269.field_5811)) {
        		return interactionResult;
        	}
        }
        
        return class_1269.field_5811;
    });
    
	@FunctionalInterface
	public interface On_Arrow_Nock {
		 class_1269 onArrowNock(class_1799 item, class_1937 level, class_1657 player, class_1268 hand, boolean hasAmmo);
	}
}
