package com.natamus.collective.fakeplayer;

import com.google.common.collect.Maps;
import com.mojang.authlib.GameProfile;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_3218;

public class FakePlayerFactory {
	private static final GameProfile MINECRAFT = new GameProfile(UUID.fromString("41C82C87-7AfB-4024-BA57-13D2C99CAE77"), "[Minecraft]");
	private static final Map<GameProfile, FakePlayer> fakePlayers = Maps.newHashMap();
	private static WeakReference<FakePlayer> MINECRAFT_PLAYER = null;

	public static FakePlayer getMinecraft(class_3218 world) {
		FakePlayer ret = MINECRAFT_PLAYER != null ? MINECRAFT_PLAYER.get() : null;
		if (ret == null) {
			ret = FakePlayerFactory.get(world,  MINECRAFT);
			MINECRAFT_PLAYER = new WeakReference<>(ret);
		}
		return ret;
	}

	public static FakePlayer get(class_3218 serverLevel, GameProfile gameProfile) {
		if (!fakePlayers.containsKey(gameProfile)) {
			FakePlayer fakePlayer = new FakePlayer(serverLevel.method_8503(), serverLevel, gameProfile, null);
			fakePlayers.put(gameProfile, fakePlayer);
		}

		return fakePlayers.get(gameProfile);
	}

	public static void unloadWorld(class_3218 world) {
		fakePlayers.entrySet().removeIf(entry -> entry.getValue().method_37908() == world);
		if (MINECRAFT_PLAYER != null && MINECRAFT_PLAYER.get() != null && MINECRAFT_PLAYER.get().method_37908() == world) {
			FakePlayer mc = MINECRAFT_PLAYER.get();
			if (mc != null && mc.method_37908() == world) {
				MINECRAFT_PLAYER = null;
			}
		}
	}
}