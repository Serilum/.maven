package com.natamus.collective.events;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective.check.RegisterMod;
import com.natamus.collective.config.CollectiveConfigHandler;
import com.natamus.collective.data.GlobalVariables;
import com.natamus.collective.functions.BlockPosFunctions;
import com.natamus.collective.functions.EntityFunctions;
import com.natamus.collective.functions.SpawnEntityFunctions;
import com.natamus.collective.objects.SAMObject;
import com.natamus.collective.util.CollectiveReference;
import net.minecraft.class_1268;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1297.class_5529;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3738;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class CollectiveEvents {
	public static WeakHashMap<class_3218, List<class_1297>> entitiesToSpawn = new WeakHashMap<class_3218, List<class_1297>>();
	public static WeakHashMap<class_3218, WeakHashMap<class_1297, class_1297>> entitiesToRide = new WeakHashMap<class_3218, WeakHashMap<class_1297, class_1297>>();
	public static CopyOnWriteArrayList<Pair<Integer, Runnable>> scheduledRunnables = new CopyOnWriteArrayList<Pair<Integer, Runnable>>();

	public static void onWorldTick(class_3218 serverlevel) {
		if (entitiesToSpawn.computeIfAbsent(serverlevel, k -> new ArrayList<class_1297>()).size() > 0) {
			class_1297 tospawn = entitiesToSpawn.get(serverlevel).get(0);

			serverlevel.method_30771(tospawn);

			if (entitiesToRide.computeIfAbsent(serverlevel, k -> new WeakHashMap<class_1297, class_1297>()).containsKey(tospawn)) {
				class_1297 rider = entitiesToRide.get(serverlevel).get(tospawn);

				rider.method_5804(tospawn);

				entitiesToRide.get(serverlevel).remove(tospawn);
			}

			entitiesToSpawn.get(serverlevel).remove(0);
		}
	}

	public static void onServerTick(MinecraftServer minecraftServer) {
		int serverTickCount = minecraftServer.method_3780();
		for (Pair<Integer, Runnable> pair : scheduledRunnables) {
			if (pair.getFirst() <= serverTickCount) {
				minecraftServer.method_18858(new class_3738(minecraftServer.method_3780(), pair.getSecond()));
				scheduledRunnables.remove(pair);
			}
		}
	}
	
	public static boolean onEntityJoinLevel(class_1937 world, class_1297 entity) {
		if (!(entity instanceof class_1309)) {
			return true;
		}
		
		if (RegisterMod.shouldDoCheck) {
			if (entity instanceof class_1657) {
				RegisterMod.joinWorldProcess(world, (class_1657)entity);
			}
		}
		
		if (entity.method_31481()) {
			return true;
		}
		
		if (GlobalVariables.samobjects.isEmpty()) {
			return true;
		}
		
		Set<String> tags = entity.method_5752();
		if (tags.contains(CollectiveReference.MOD_ID + ".checked")) {
			return true;
		}
		entity.method_5780(CollectiveReference.MOD_ID + ".checked");
		
		class_1299<?> entitytype = entity.method_5864();
		if (entitytype == null || !GlobalVariables.activesams.contains(entitytype)) {
			return true;
		}
		
		boolean isspawner = tags.contains(CollectiveReference.MOD_ID + ".fromspawner");
		
		List<SAMObject> possibles = new ArrayList<SAMObject>();
		for (SAMObject samobject : GlobalVariables.samobjects) {
			if (samobject == null) {
				continue;
			}

			if (samobject.fromtype == null) {
				continue;
			}
			if (samobject.fromtype.equals(entitytype)) {
				if ((samobject.spawner && !isspawner) || (!samobject.spawner && isspawner)) {
					continue;
				}
				possibles.add(samobject);
			}
		}
		
		int size = possibles.size();
		if (size == 0) {
			return true;
		}

		boolean ageable = entity instanceof class_1296;

		for (SAMObject sam : possibles) {
			double num = GlobalVariables.random.nextDouble();
			if (num > sam.chance) {
				continue;
			}
			
			class_243 evec = entity.method_19538();
			if (sam.surface) {
				if (!BlockPosFunctions.isOnSurface(world, evec)) {
					continue;
				}
			}
			
			class_1297 to = sam.totype.method_5883(world);
			if (to == null) {
				return true;
			}

			//to.setWorld(Level);
			to.method_5814(evec.field_1352, evec.field_1351, evec.field_1350);

			if (ageable && to instanceof class_1296) {
				class_1296 am = (class_1296)to;
				am.method_5614(((class_1296)entity).method_5618());
				to = am;
			}

			boolean ignoremainhand = false;
			if (sam.helditem != null) {
				if (to instanceof class_1309) {
					class_1309 le = (class_1309)to;
					if (!le.method_6047().method_7909().equals(sam.helditem)) {
						le.method_6122(class_1268.field_5808, new class_1799(sam.helditem, 1));
						ignoremainhand = true;
					}
				}
			}
			
			boolean ride = false;
			if (EntityFunctions.isHorse(to) && sam.rideable) {
				class_1496 ah = (class_1496)to;
				ah.method_6766(true);

				ride = true;
			}
			else {
				if (CollectiveConfigHandler.transferItemsBetweenReplacedEntities) {
					EntityFunctions.transferItemsBetweenEntities(entity, to, ignoremainhand);
				}
			}

			if (!(world instanceof class_3218)) {
				return true;
			}
			
			class_3218 serverworld = (class_3218)world;

			if (ride) {
				SpawnEntityFunctions.startRidingEntityOnNextTick(serverworld, to, entity);
			}
			else {
				entity.method_5650(class_5529.field_26999);
			}

			to.method_5780(CollectiveReference.MOD_ID + ".checked");
			SpawnEntityFunctions.spawnEntityOnNextTick(serverworld, to);

			return ride;
		}

		return true;
	}
}