package com.natamus.collective.functions;

import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_492;

public class ScreenFunctions {
	public static void setScreenTitle(class_437 screen, class_2561 titleComponent) {
		screen.field_22785 = titleComponent;
	}

	public static void setMerchantScreenTitle(class_492 merchantScreen, class_2561 titleComponent) {
		merchantScreen.field_22785 = titleComponent;
	}
}
