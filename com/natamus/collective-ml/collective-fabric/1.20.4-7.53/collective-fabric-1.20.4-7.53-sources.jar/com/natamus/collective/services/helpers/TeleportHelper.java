package com.natamus.collective.services.helpers;

import net.minecraft.class_1297;
import net.minecraft.class_3218;
import net.minecraft.class_5454;

public interface TeleportHelper {
    <T extends class_1297> class_1297 teleportEntity(T entity, class_3218 serverLevel, class_5454 portalInfo);
}