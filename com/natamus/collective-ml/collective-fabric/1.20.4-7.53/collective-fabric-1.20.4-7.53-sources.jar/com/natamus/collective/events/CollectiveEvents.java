package com.natamus.collective.events;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.yggdrasil.ProfileResult;
import com.mojang.datafixers.util.Pair;
import com.natamus.collective.check.RegisterMod;
import com.natamus.collective.config.CollectiveConfigHandler;
import com.natamus.collective.data.GlobalVariables;
import com.natamus.collective.features.PlayerHeadCacheFeature;
import com.natamus.collective.functions.BlockPosFunctions;
import com.natamus.collective.functions.EntityFunctions;
import com.natamus.collective.functions.HeadFunctions;
import com.natamus.collective.functions.SpawnEntityFunctions;
import com.natamus.collective.objects.SAMObject;
import com.natamus.collective.util.CollectiveReference;
import net.minecraft.class_1268;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1297.class_5529;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1809;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2484;
import net.minecraft.class_2487;
import net.minecraft.class_2549;
import net.minecraft.class_2586;
import net.minecraft.class_2631;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3738;
import net.minecraft.server.MinecraftServer;
import javax.annotation.Nullable;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class CollectiveEvents {
	public static WeakHashMap<class_3218, List<class_1297>> entitiesToSpawn = new WeakHashMap<class_3218, List<class_1297>>();
	public static WeakHashMap<class_3218, WeakHashMap<class_1297, class_1297>> entitiesToRide = new WeakHashMap<class_3218, WeakHashMap<class_1297, class_1297>>();
	public static CopyOnWriteArrayList<Pair<Integer, Runnable>> scheduledRunnables = new CopyOnWriteArrayList<Pair<Integer, Runnable>>();

	public static void onWorldTick(class_3218 serverLevel) {
		if (entitiesToSpawn.computeIfAbsent(serverLevel, k -> new ArrayList<class_1297>()).size() > 0) {
			class_1297 tospawn = entitiesToSpawn.get(serverLevel).get(0);

			serverLevel.method_30771(tospawn);

			if (entitiesToRide.computeIfAbsent(serverLevel, k -> new WeakHashMap<class_1297, class_1297>()).containsKey(tospawn)) {
				class_1297 rider = entitiesToRide.get(serverLevel).get(tospawn);

				rider.method_5804(tospawn);

				entitiesToRide.get(serverLevel).remove(tospawn);
			}

			entitiesToSpawn.get(serverLevel).remove(0);
		}
	}

	public static void onServerTick(MinecraftServer minecraftServer) {
		int serverTickCount = minecraftServer.method_3780();
		for (Pair<Integer, Runnable> pair : scheduledRunnables) {
			if (pair.getFirst() <= serverTickCount) {
				minecraftServer.method_18858(new class_3738(minecraftServer.method_3780(), pair.getSecond()));
				scheduledRunnables.remove(pair);
			}
		}
	}

	public static boolean onEntityJoinLevel(class_1937 level, class_1297 entity) {
		if (!(entity instanceof class_1309)) {
			return true;
		}

		if (entity instanceof class_1657) {
			class_1657 player = (class_1657)entity;

			if (RegisterMod.shouldDoCheck) {
				RegisterMod.joinWorldProcess(level, player);
			}

			if (PlayerHeadCacheFeature.isHeadCachingEnabled()) {
				PlayerHeadCacheFeature.cachePlayer(player);
			}
		}

		if (entity.method_31481()) {
			return true;
		}

		if (GlobalVariables.globalSAMs.isEmpty()) {
			return true;
		}

		Set<String> tags = entity.method_5752();
		if (tags.contains(CollectiveReference.MOD_ID + ".checked")) {
			return true;
		}
		entity.method_5780(CollectiveReference.MOD_ID + ".checked");

		class_1299<?> entityType = entity.method_5864();
		if (!GlobalVariables.activeSAMEntityTypes.contains(entityType)) {
			return true;
		}

		boolean isFromSpawner = tags.contains(CollectiveReference.MOD_ID + ".fromspawner");

		List<SAMObject> possibles = new ArrayList<SAMObject>();
		for (SAMObject sam : GlobalVariables.globalSAMs) {
			if (sam == null) {
				continue;
			}

			if (sam.fromEntityType == null) {
				continue;
			}
			if (sam.fromEntityType.equals(entityType)) {
				if ((sam.onlyFromSpawner && !isFromSpawner) || (!sam.onlyFromSpawner && isFromSpawner)) {
					continue;
				}
				possibles.add(sam);
			}
		}

		int size = possibles.size();
		if (size == 0) {
			return true;
		}

		class_243 eVec = entity.method_19538();
		boolean ageable = entity instanceof class_1296;
		boolean isOnSurface = BlockPosFunctions.isOnSurface(level, eVec);

		for (SAMObject sam : possibles) {
			double num = GlobalVariables.random.nextDouble();
			if (num > sam.changeChance) {
				continue;
			}

			if (sam.onlyOnSurface) {
				if (!isOnSurface) {
					continue;
				}
			}
			else if (sam.onlyBelowSurface) {
				if (isOnSurface) {
					continue;
				}
			}

			if (sam.onlyBelowSpecificY) {
				if (eVec.field_1351 >= sam.specificY) {
					continue;
				}
			}

			class_1297 to = sam.toEntityType.method_5883(level);
			if (to == null) {
				return true;
			}

			to.method_5814(eVec.field_1352, eVec.field_1351, eVec.field_1350);

			if (ageable && to instanceof class_1296) {
				class_1296 am = (class_1296)to;
				am.method_5614(((class_1296)entity).method_5618());
				to = am;
			}

			boolean ignoreMainhand = false;
			if (sam.itemToHold != null) {
				if (to instanceof class_1309) {
					class_1309 le = (class_1309)to;
					if (!le.method_6047().method_7909().equals(sam.itemToHold)) {
						le.method_6122(class_1268.field_5808, new class_1799(sam.itemToHold, 1));
						ignoreMainhand = true;
					}
				}
			}

			boolean ride = false;
			if (EntityFunctions.isHorse(to) && sam.rideNotReplace) {
				class_1496 ah = (class_1496)to;
				ah.method_6766(true);

				ride = true;
			}
			else {
				if (CollectiveConfigHandler.transferItemsBetweenReplacedEntities) {
					EntityFunctions.transferItemsBetweenEntities(entity, to, ignoreMainhand);
				}
			}

			if (!(level instanceof class_3218)) {
				return true;
			}

			class_3218 serverLevel = (class_3218)level;

			if (ride) {
				SpawnEntityFunctions.startRidingEntityOnNextTick(serverLevel, to, entity);
			}
			else {
				entity.method_5650(class_5529.field_26999);
			}

			to.method_5780(CollectiveReference.MOD_ID + ".checked");
			SpawnEntityFunctions.spawnEntityOnNextTick(serverLevel, to);

			return ride;
		}

		return true;
	}

	public static boolean onBlockBreak(class_1937 level, class_1657 player, class_2338 pos, class_2680 state, @Nullable class_2586 blockEntity) {
		if (level.field_9236) {
			return true;
		}

		class_2248 block = state.method_26204();
		if (block instanceof class_2484 || block instanceof class_2549) {
			if (player.method_7337()) {
				return true;
			}

			class_2586 targetBlockEntity = level.method_8321(pos);
			if (!(targetBlockEntity instanceof class_2631)) {
				return true;
			}

			class_2631 skullBlockEntity = (class_2631)targetBlockEntity;
			if (skullBlockEntity == null) {
				return true;
			}

			GameProfile gameProfile = skullBlockEntity.method_11334();
			if (gameProfile == null) {
				return true;
			}

			UUID uuid = gameProfile.getId();
			if (uuid.toString().startsWith("ffffffff")) { // Old player head format
				return true;
			}

			class_1799 namedHeadStack = null;
			if (!gameProfile.getName().equals("")) {
				namedHeadStack = HeadFunctions.getNewPlayerHead(gameProfile, 1);
			}

			if (namedHeadStack == null) {
				GameProfile uuidGameProfile;
				if (PlayerHeadCacheFeature.cachedGameProfileMap.containsKey(uuid)) {
					uuidGameProfile = PlayerHeadCacheFeature.cachedGameProfileMap.get(uuid);
				} else {
					MinecraftSessionService minecraftSessionService = ((class_3218)level).method_8503().method_3844();

					ProfileResult uuidProfileResult = minecraftSessionService.fetchProfile(uuid, false);
					if (uuidProfileResult == null) {
						return true;
					}

					uuidGameProfile = uuidProfileResult.profile();

					if (uuidGameProfile.getName().equals("")) {
						return true;
					}

					PlayerHeadCacheFeature.cachedGameProfileMap.put(uuid, uuidGameProfile);
				}

				namedHeadStack = HeadFunctions.getNewPlayerHead(uuidGameProfile, 1);
			}

			if (namedHeadStack != null) {
				level.method_22352(pos, false);

				level.method_8649(new class_1542(level, pos.method_10263(), pos.method_10264()+0.5, pos.method_10260(), namedHeadStack));
				return false;
			}
		}

		return true;
	}

	public static boolean onEntityBlockPlace(class_1937 level, class_2338 pos, class_2680 state, class_1309 entity, class_1799 itemStack) {
		if (level.field_9236) {
			return true;
		}

		if (!(entity instanceof class_1657)) {
			return true;
		}

		if (!(itemStack.method_7909() instanceof class_1809)) {
			return true;
		}
		String itemName = itemStack.method_7964().getString();
		if (!itemName.contains("'s Head")) {
			return true;
		}

		class_2487 skullOwner = itemStack.method_7941("SkullOwner");
		if (skullOwner == null) {
			return true;
		}

		int[] idIntArray = skullOwner.method_10561("Id");
		if (idIntArray[0] != -1) {
			return true;
		}

		String headName = itemName.replace("'s Head", "");

		class_1799 newHeadStack = HeadFunctions.getNewPlayerHead((class_3218)level, headName, itemStack.method_7947());

		class_2487 skullOwnerCompoundTag = HeadFunctions.getSkullOwnerCompoundTag((class_3218)level, headName);
		itemStack.method_7959("SkullOwner", skullOwnerCompoundTag);
		return false;
	}
}