package com.natamus.collective.services.helpers;

import javax.annotation.Nullable;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import java.util.function.Supplier;

public interface RegisterItemHelper {
	<T extends class_1792> void registerItem(Object modEventBusObject, class_2960 resourceLocation, Supplier<T> itemSupplier, @Nullable class_5321<class_1761> creativeModeTabResourceKey);

	class_1792 getRegisteredItem(class_2960 resourceLocation);
}