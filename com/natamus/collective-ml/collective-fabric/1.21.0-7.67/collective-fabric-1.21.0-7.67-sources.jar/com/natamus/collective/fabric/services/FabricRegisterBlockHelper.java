package com.natamus.collective.fabric.services;

import com.mojang.datafixers.util.Pair;
import com.natamus.collective.services.helpers.RegisterBlockHelper;
import javax.annotation.Nullable;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import java.util.HashMap;
import java.util.function.Supplier;

public class FabricRegisterBlockHelper implements RegisterBlockHelper {
	private final HashMap<class_2960, Pair<class_2248, class_1792>> registeredBlockPairs = new HashMap<>();

    @Override
	public <T extends class_2248> void registerBlockPair(Object modEventBusObject, class_2960 resourceLocation, Supplier<T> blockSupplier, @Nullable class_5321<class_1761> creativeModeTabResourceKey) {
		class_2248 block = blockSupplier.get();

		class_2378.method_10230(class_7923.field_41175, resourceLocation, block);
		class_1792 item = FabricRegisterItemHelper.staticRegisterItem(modEventBusObject, resourceLocation, () -> new class_1747(block, new class_1792.class_1793()), creativeModeTabResourceKey);

		registeredBlockPairs.put(resourceLocation, Pair.of(block, item));
    }

	@Override
	public Pair<class_2248, class_1747> getRegisteredBlockPair(class_2960 resourceLocation) {
		Pair<class_2248, class_1792> registeredPair = registeredBlockPairs.get(resourceLocation);
		return Pair.of(registeredPair.getFirst(), (class_1747)registeredPair.getSecond());
	}
}