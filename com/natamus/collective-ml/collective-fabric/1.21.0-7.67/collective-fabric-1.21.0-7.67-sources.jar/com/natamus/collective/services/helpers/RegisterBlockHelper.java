package com.natamus.collective.services.helpers;

import com.mojang.datafixers.util.Pair;
import javax.annotation.Nullable;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import java.util.function.Supplier;

public interface RegisterBlockHelper {
	<T extends class_2248> void registerBlockPair(Object modEventBusObject, class_2960 resourceLocation, Supplier<T> blockSupplier, @Nullable class_5321<class_1761> creativeModeTabResourceKey);

	Pair<class_2248, class_1747> getRegisteredBlockPair(class_2960 resourceLocation);
}