package com.natamus.collective.fabric.services;

import com.natamus.collective.services.helpers.TeleportHelper;
import net.fabricmc.fabric.api.dimension.v1.FabricDimensions;
import net.minecraft.class_1297;
import net.minecraft.class_3218;
import net.minecraft.class_5454;

public class FabricTeleportHelper implements TeleportHelper {
    @Override
    public <T extends class_1297> class_1297 teleportEntity(T entity, class_3218 serverLevel, class_5454 portalInfo) {
        return FabricDimensions.teleport(entity, serverLevel, portalInfo);
    }
}
