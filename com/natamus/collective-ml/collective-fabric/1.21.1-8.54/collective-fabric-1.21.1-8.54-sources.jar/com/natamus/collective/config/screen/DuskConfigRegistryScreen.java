package com.natamus.collective.config.screen;

import com.natamus.collective.config.DuskConfigEntry;
import com.natamus.collective.functions.ConfigFunctions;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7919;

public class DuskConfigRegistryScreen extends DuskConfigBaseScreen {
	private final class_437 parent;
	private final DuskConfigEntry entry;
	private final List<String> selectedIds = new ArrayList<>();
	private final List<String> initialIds;
	private final List<String> registryIds;
	private final List<String> suggestedIds;
	private final HashMap<String, class_1799> icons = new HashMap<>();
	private final HashMap<String, String> names = new HashMap<>();
	private final HashMap<String, Boolean> loadedIds = new HashMap<>();
	private DuskConfigIdList selectedList;
	private DuskConfigIdList availableList;
	private class_342 searchBox;
	private boolean showAll;
	private String pendingRemovalId = null;
	private String search = "";

	public DuskConfigRegistryScreen(class_437 parent, DuskConfigEntry entry) {
		super(class_2561.method_43470(entry.getDisplayName()));
		this.parent = parent;
		this.entry = entry;
		for (String id : entry.getIdList()) {
			if (!isSelected(id)) {
				selectedIds.add(id);
			}
		}
		this.initialIds = new ArrayList<>(selectedIds);
		this.registryIds = DuskConfigRegistryIds.getIds(entry.registry);
		this.suggestedIds = DuskConfigRegistryIds.getSuggestedIds(entry.registry, entry.filter);
		this.showAll = suggestedIds.isEmpty();
	}

	@Override
	protected void method_25426() {
		super.method_25426();

		int listWidth = this.field_22789 / 2 - 15;
		int listHeight = this.field_22790 - 122;

		double selectedScroll = 0;
		double availableScroll = 0;
		if (selectedList != null) {
			selectedScroll = selectedList.method_25341();
			availableScroll = availableList.method_25341();
		}

		selectedList = this.method_25429(new DuskConfigIdList(this.field_22787, 10, 58, listWidth, listHeight));
		availableList = this.method_25429(new DuskConfigIdList(this.field_22787, this.field_22789 / 2 + 5, 58, listWidth, listHeight));

		int searchWidth = listWidth;
		if (!entry.filter.isEmpty()) {
			searchWidth = listWidth - 84;
			addFilterButton(this.field_22789 / 2 + 5 + searchWidth + 4);
		}

		searchBox = this.method_37063(new class_342(this.field_22793, this.field_22789 / 2 + 5, 34, searchWidth, 20, class_2561.method_43471("gui.recipebook.search_hint")));
		searchBox.method_47404(class_2561.method_43471("gui.recipebook.search_hint").method_27692(class_124.field_1063));
		searchBox.method_1852(search);
		searchBox.method_1863(text -> {
			search = text;
			refreshAvailableList();
			availableList.method_25307(0);
		});

		class_342 patternBox = this.method_37063(new class_342(this.field_22793, 10, this.field_22790 - 54, listWidth - 45, 20, class_2561.method_43471("collective.collective.gui.idpattern")));
		patternBox.method_1880(Integer.MAX_VALUE);
		patternBox.method_47404(class_2561.method_43471("collective.collective.gui.idpattern").method_27692(class_124.field_1063));
		this.method_37063(new DuskConfigButton(listWidth - 30, this.field_22790 - 54, 40, 20, class_2561.method_43471("collective.collective.gui.add"), button -> {
			addId(patternBox.method_1882().strip());
			patternBox.method_1852("");
		}));

		addCancelButton(this.field_22789 / 2 - 154, this.field_22790 - 28);
		this.method_37063(class_4185.method_46430(class_5244.field_24334, button -> {
			entry.setIdList(selectedIds);
			method_25419();
		}).method_46433(this.field_22789 / 2 + 4, this.field_22790 - 28).method_46437(150, 20).method_46431());

		refreshLists();
		selectedList.method_25307(selectedScroll);
		availableList.method_25307(availableScroll);
	}

	@Override
	protected boolean hasUnsavedChanges() {
		return !selectedIds.equals(initialIds);
	}

	private void addFilterButton(int x) {
		class_4185 filterButton = this.method_37063(new DuskConfigButton(x, 34, 80, 20, getFilterLabel(), this::toggleFilter, this::toggleFilter));

		if (suggestedIds.isEmpty()) {
			filterButton.field_22763 = false;
			filterButton.method_47400(class_7919.method_47407(class_2561.method_43471("collective.collective.gui.worldneeded")));
		}
	}

	private void toggleFilter(class_4185 button) {
		showAll = !showAll;
		button.method_25355(getFilterLabel());
		refreshAvailableList();
		availableList.method_25307(0);
	}

	private class_2561 getFilterLabel() {
		if (showAll) {
			return DuskConfigRegistryIds.getAllLabel(entry.registry);
		}
		return DuskConfigRegistryIds.getFilterLabel(entry.filter);
	}

	private void refreshLists() {
		refreshSelectedList();
		refreshAvailableList();
	}

	private void refreshSelectedList() {
		List<DuskConfigIdRow> selectedRows = new ArrayList<>();
		for (String id : selectedIds) {
			int colour = 0xFF808080;
			if (isLoaded(id)) {
				colour = 0xFFFFFFFF;
			}
			selectedRows.add(new DuskConfigIdRow(getIcon(id), getName(id), id, colour, getRemoveLabel(id), button -> pressRemove(id)));
		}
		selectedList.setRows(selectedRows);
	}

	private void refreshAvailableList() {
		String search = searchBox.method_1882().strip().toLowerCase(Locale.ROOT);

		List<String> shownIds = suggestedIds;
		if (showAll) {
			shownIds = registryIds;
		}

		List<DuskConfigIdRow> availableRows = new ArrayList<>();
		for (String id : shownIds) {
			if (!isSelected(id) && (id.contains(search) || getName(id).toLowerCase(Locale.ROOT).contains(search))) {
				availableRows.add(new DuskConfigIdRow(getIcon(id), getName(id), id, 0xFFFFFFFF, class_2561.method_43470("+").method_27692(class_124.field_1060), button -> addId(id)));
			}
		}
		availableList.setRows(availableRows);
	}

	private boolean isSelected(String id) {
		for (String selectedId : selectedIds) {
			if (selectedId.equalsIgnoreCase(id)) {
				return true;
			}
		}
		return false;
	}

	private boolean isLoaded(String id) {
		return loadedIds.computeIfAbsent(id, loadedId -> {
			for (String registryId : registryIds) {
				if (ConfigFunctions.isInIdList(loadedId, registryId)) {
					return true;
				}
			}
			return false;
		});
	}

	private class_1799 getIcon(String id) {
		return icons.computeIfAbsent(id, iconId -> DuskConfigRegistryIds.getIcon(entry.registry, iconId));
	}

	private String getName(String id) {
		return names.computeIfAbsent(id, nameId -> DuskConfigRegistryIds.getName(entry.registry, nameId));
	}

	private void addId(String id) {
		if (!id.isEmpty() && !isSelected(id)) {
			selectedIds.add(id);
			refreshLists();
		}
	}

	private class_2561 getRemoveLabel(String id) {
		if (id.equals(pendingRemovalId)) {
			return class_2561.method_43470("✔").method_27692(class_124.field_1061);
		}
		return class_2561.method_43470("-").method_27692(class_124.field_1061);
	}

	private void pressRemove(String id) {
		if (id.equals(pendingRemovalId)) {
			pendingRemovalId = null;
			removeId(id);
			return;
		}

		pendingRemovalId = id;
		refreshSelectedList();
	}

	private void removeId(String id) {
		selectedIds.removeIf(selectedId -> selectedId.equalsIgnoreCase(id));
		refreshLists();
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		String pendingBeforeClick = pendingRemovalId;

		boolean handled;
		if (button == class_3675.field_32002 && searchBox.method_25405(mouseX, mouseY)) {
			searchBox.method_1852("");
			handled = true;
		}
		else {
			handled = super.method_25402(mouseX, mouseY, button);
		}

		if (pendingBeforeClick != null && pendingBeforeClick.equals(pendingRemovalId)) {
			pendingRemovalId = null;
			refreshSelectedList();
		}
		return handled;
	}

	@Override
	public void method_25419() {
		this.field_22787.method_1507(parent);
	}

	@Override
	public void method_25420(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		if (this.field_22787.field_1687 == null) {
			this.method_57728(guiGraphics, partialTick);
		}
		this.method_57734(partialTick);
	}

	@Override
	public void method_25394(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

		selectedList.method_25394(guiGraphics, mouseX, mouseY, partialTick);
		availableList.method_25394(guiGraphics, mouseX, mouseY, partialTick);

		guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 12, 0xFFFFFFFF);
		guiGraphics.method_27535(this.field_22793, class_2561.method_43471("pack.selected.title").method_27693(" (" + selectedIds.size() + ")"), 12, 40, 0xFFA0A0A0);
		if (registryIds.isEmpty()) {
			guiGraphics.method_27535(this.field_22793, class_2561.method_43471("collective.collective.gui.worldneeded"), this.field_22789 / 2 + 7, 64, 0xFFA0A0A0);
		}
		else if (this.field_22787.field_1687 == null && !entry.filter.isEmpty() && suggestedIds.isEmpty()) {
			guiGraphics.method_51448().method_22903();
			guiGraphics.method_51448().method_46416(this.field_22789 / 2F, 23, 0);
			guiGraphics.method_51448().method_22905(0.75F, 0.75F, 1F);
			guiGraphics.method_27534(this.field_22793, class_2561.method_43471("collective.collective.gui.worldneeded"), 0, 0, 0xFFFFAA00);
			guiGraphics.method_51448().method_22909();
		}
	}
}
