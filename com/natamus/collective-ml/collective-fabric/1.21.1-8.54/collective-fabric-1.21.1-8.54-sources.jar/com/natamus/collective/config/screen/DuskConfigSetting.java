package com.natamus.collective.config.screen;

import com.natamus.collective.config.DuskConfigEntry;
import com.natamus.collective.functions.ColourFunctions;
import com.natamus.collective.functions.StringFunctions;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_7919;

public class DuskConfigSetting {
	private final DuskConfigEditScreen screen;
	public final DuskConfigEntry entry;
	public final List<class_339> widgets = new ArrayList<>();
	private final class_339 valueWidget;
	private final class_4185 resetButton;
	public boolean isValid = true;

	public DuskConfigSetting(DuskConfigEditScreen screen, DuskConfigEntry entry, int screenWidth) {
		this.screen = screen;
		this.entry = entry;

		int valueX = screenWidth - 160;
		int valueWidth = 150;
		if (entry.isText()) {
			widgets.add(class_4185.method_46430(class_2561.method_43470("..."), button -> class_310.method_1551().method_1507(new DuskConfigTextScreen(screen, entry))).method_46433(screenWidth - 30, 0).method_46437(20, 20).method_46431());
			valueWidth -= 25;
		}
		else if (entry.isRgb()) {
			widgets.add(new DuskConfigSwatch(screenWidth - 30, 0, 20, 20, entry::getRgbColour));
			valueWidth -= 25;
		}

		if (entry.hasRegistry() || entry.isRgb()) {
			valueWidget = new DuskConfigButton(valueX, 0, valueWidth, 20, getButtonLabel(), button -> openValueScreen());
		}
		else if (entry.isBoolean() || entry.hasOptions() || entry.isChatColour()) {
			valueWidget = new DuskConfigButton(valueX, 0, valueWidth, 20, getButtonLabel(), button -> cycleValue(false), button -> cycleValue(true));
		}
		else {
			int boxWidth = valueWidth;
			if (entry.hasRange()) {
				boxWidth = 75;
				widgets.add(new DuskConfigRangeLabel(screenWidth - 81, 71, entry));
			}

			class_342 editBox = new class_342(class_310.method_1551().field_1772, valueX, 0, boxWidth, 20, class_2561.method_43471("options.generic_value"));
			editBox.method_1880(Integer.MAX_VALUE);
			editBox.method_1852(entry.getText());
			editBox.method_1863(this::onTextChanged);
			valueWidget = editBox;
		}

		if (DuskConfigEditScreen.showTooltips && !entry.description.isEmpty()) {
			valueWidget.method_47400(class_7919.method_47407(class_2561.method_43470(String.join(" ", entry.description))));
		}

		resetButton = new DuskConfigButton(screenWidth - 205, 0, 40, 20, class_2561.method_43471("controls.reset").method_27692(class_124.field_1061), button -> resetValue());
		updateResetButton();

		widgets.add(valueWidget);
		widgets.add(resetButton);
	}

	private class_2561 getButtonLabel() {
		if (entry.hasRegistry()) {
			int amount = entry.getIdList().size();
			if (amount == 0) {
				return class_2561.method_43471("gui.none").method_27692(class_124.field_1080);
			}
			return DuskConfigRegistryIds.getAmountLabel(entry.registry, amount);
		}

		if (entry.hasOptions()) {
			return class_2561.method_43470(entry.getOptionLabel(entry.getOption()));
		}

		if (entry.isRgb()) {
			return class_2561.method_43470(entry.getText().replace(",", ", "));
		}

		if (entry.isChatColour()) {
			class_124 colour = ColourFunctions.getById((Integer) entry.getValue());
			if (colour == null) {
				return class_2561.method_43470(String.valueOf(entry.getValue()));
			}
			return class_2561.method_43470(StringFunctions.capitalizeEveryWord(colour.name().replace("_", " "))).method_27692(colour);
		}

		if ((Boolean) entry.getValue()) {
			return class_2561.method_43471("gui.yes").method_27692(class_124.field_1060);
		}
		return class_2561.method_43471("gui.no").method_27692(class_124.field_1061);
	}

	private void openValueScreen() {
		if (entry.hasRegistry()) {
			class_310.method_1551().method_1507(new DuskConfigRegistryScreen(screen, entry));
		}
		else {
			class_310.method_1551().method_1507(new DuskConfigColourScreen(screen, entry));
		}
	}

	private void cycleValue(boolean backwards) {
		if (entry.hasOptions()) {
			if (backwards) {
				entry.setOption(entry.getPreviousOption());
			}
			else {
				entry.setOption(entry.getNextOption());
			}
		}
		else if (entry.isChatColour()) {
			int step = 1;
			if (backwards) {
				step = 15;
			}
			entry.setValue(((Integer) entry.getValue() + step) % 16);
		}
		else {
			entry.setValue(!(Boolean) entry.getValue());
		}

		valueWidget.method_25355(getButtonLabel());
		screen.onSettingChanged();
	}

	private void onTextChanged(String text) {
		Object value = entry.getValueFromText(text);
		isValid = value != null;

		if (isValid) {
			entry.setValue(value);
			((class_342) valueWidget).method_1868(0xFFFFFFFF);
		}
		else {
			((class_342) valueWidget).method_1868(0xFFFF7777);
		}

		screen.onSettingChanged();
	}

	private void resetValue() {
		entry.resetValue();

		if (valueWidget instanceof class_342 editBox) {
			editBox.method_1852(entry.getText());
		}
		else {
			valueWidget.method_25355(getButtonLabel());
		}

		screen.onSettingChanged();
	}

	public void updateResetButton() {
		resetButton.field_22763 = !entry.isDefault();
	}
}
