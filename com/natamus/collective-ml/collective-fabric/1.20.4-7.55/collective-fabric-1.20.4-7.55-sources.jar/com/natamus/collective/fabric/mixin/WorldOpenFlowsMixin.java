package com.natamus.collective.fabric.mixin;

import com.mojang.serialization.Lifecycle;
import com.natamus.collective.services.Services;
import net.minecraft.class_310;
import net.minecraft.class_525;
import net.minecraft.class_7196;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_7196.class, priority = 1001)
public class WorldOpenFlowsMixin {
	@ModifyVariable(method = "loadLevel", at = @At(value= "STORE"), ordinal = 3)
	public boolean loadLevel_bl2(boolean isLifeCycleStable) {
		System.out.println("loadLevel (Collective): " + Services.MODLOADER.isModLoaded("collective"));
		System.out.println("loadLevel (Experimental): " + Services.MODLOADER.isModLoaded("hideexperimentalwarning"));
		System.out.println("loadLevel (Dev): " + Services.MODLOADER.isDevelopmentEnvironment());
		return !Services.MODLOADER.isDevelopmentEnvironment() && !Services.MODLOADER.isModLoaded("hideexperimentalwarning");
	}

	@Inject(method = "confirmWorldCreation", at = @At(value = "INVOKE_ASSIGN", target = "Lcom/mojang/serialization/Lifecycle;experimental()Lcom/mojang/serialization/Lifecycle;"), cancellable = true)
	private static void confirmWorldCreation(class_310 minecraft, class_525 screen, Lifecycle lifecycle, Runnable loadWorld, boolean skipWarnings, CallbackInfo ci) {
		System.out.println("confirmWorldCreation (Collective): " + Services.MODLOADER.isModLoaded("collective"));
		System.out.println("confirmWorldCreation (Experimental): " + Services.MODLOADER.isModLoaded("hideexperimentalwarning"));
		System.out.println("confirmWorldCreation (Dev): " + Services.MODLOADER.isDevelopmentEnvironment());

		if (Services.MODLOADER.isDevelopmentEnvironment() || Services.MODLOADER.isModLoaded("hideexperimentalwarning")) {
			loadWorld.run();
			ci.cancel();
		}
	}
}
