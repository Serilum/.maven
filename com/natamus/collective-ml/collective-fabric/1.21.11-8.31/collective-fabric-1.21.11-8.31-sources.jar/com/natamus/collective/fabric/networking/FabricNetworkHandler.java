package com.natamus.collective.fabric.networking;

import com.natamus.collective.data.Constants;
import com.natamus.collective.implementations.networking.PacketRegistrationHandler;
import com.natamus.collective.implementations.networking.data.CommonPacketWrapper;
import com.natamus.collective.implementations.networking.data.PacketContainer;
import com.natamus.collective.implementations.networking.data.PacketContext;
import com.natamus.collective.implementations.networking.data.Side;
import com.natamus.collective.implementations.networking.exceptions.RegistrationException;
import net.fabricmc.fabric.api.client.networking.v1.ClientConfigurationNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerConfigurationNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_3222;

/** The networking code is based on the MIT licensed
 *   <a href="https://github.com/mysticdrew/common-networking">common-networking</a> v1.0.8
 *  by MysticDrew */

public class FabricNetworkHandler extends PacketRegistrationHandler {
    public FabricNetworkHandler(Side side) {
        super(side);
    }

    protected <T> void registerPacket(PacketContainer<T> container) {
        try {
            if (container.packetType() == PacketContainer.PacketType.PLAY) {
                PayloadTypeRegistry.playC2S().register(container.getType(), container.getCodec());
                PayloadTypeRegistry.playS2C().register(container.getType(), container.getCodec());
            }
            else {
                PayloadTypeRegistry.configurationC2S().register(container.getType(), container.getCodec());
                PayloadTypeRegistry.configurationS2C().register(container.getType(), container.getCodec());
            }
        }
        catch (IllegalArgumentException e) {
            // do nothing
        }

        if (Side.CLIENT.equals(this.side)) {
            Constants.LOG.debug("Registering packet {} : {} on the: {}", container.type().comp_2242(), container.classType(), Side.CLIENT);

            if (container.packetType() == PacketContainer.PacketType.PLAY) {
                // play packets
                ClientPlayNetworking.registerGlobalReceiver(container.getType(),
                        (ClientPlayNetworking.PlayPayloadHandler<CommonPacketWrapper<T>>) (payload, context) -> context.client().execute(() ->
                                container.handler().accept(
                                        new PacketContext<>(payload.packet(), Side.CLIENT))));
            }
            else {
                // configuration packets
                ClientConfigurationNetworking.registerGlobalReceiver(container.getType(),
                        (ClientConfigurationNetworking.ConfigurationPayloadHandler<CommonPacketWrapper<T>>) (payload, context) -> context.client().execute(() ->
                                container.handler().accept(
                                        new PacketContext<>(payload.packet(), Side.CLIENT))));
            }
        }

        Constants.LOG.debug("Registering packet {} : {} on the: {}", container.type().comp_2242(), container.classType(), Side.SERVER);
        if (container.packetType() == PacketContainer.PacketType.PLAY) {
            // play packets
            ServerPlayNetworking.registerGlobalReceiver(container.getType(),
                    (ServerPlayNetworking.PlayPayloadHandler<CommonPacketWrapper<T>>) (payload, context) -> context.player().method_51469().method_8503().execute(() ->
                            container.handler().accept(
                                    new PacketContext<>(context.player(), payload.packet(), Side.SERVER))));
        }
        else {
            // configuration packets
            ServerConfigurationNetworking.registerGlobalReceiver(container.getType(),
                    (ServerConfigurationNetworking.ConfigurationPacketHandler<CommonPacketWrapper<T>>) (payload, context) -> context.server().execute(() ->
                            container.handler().accept(
                                    new PacketContext<>(null, payload.packet(), Side.SERVER))));
        }

    }

    public <T> void sendToServer(T packet) {
        this.sendToServer(packet, false);
    }

    @SuppressWarnings("unchecked")
	public <T> void sendToServer(T packet, boolean ignoreCheck) {
        PacketContainer<T> container = (PacketContainer<T>) PACKET_MAP.get(packet.getClass());
        if (container != null) {
            if (ignoreCheck || ClientPlayNetworking.canSend(container.type().comp_2242())) {
                ClientPlayNetworking.send(new CommonPacketWrapper<>(container, packet));
            }
        }
        else {
            throw new RegistrationException(packet.getClass() + "{} packet not registered on the client, packets need to be registered on both sides!");
        }
    }

    @SuppressWarnings("unchecked")
    public <T> void sendToClient(T packet, class_3222 player) {
        PacketContainer<T> container = (PacketContainer<T>) PACKET_MAP.get(packet.getClass());
        if (container != null) {
            if (ServerPlayNetworking.canSend(player, container.type().comp_2242())) {
                ServerPlayNetworking.send(player, new CommonPacketWrapper<>(container, packet));
            }
        }
        else {
            throw new RegistrationException(packet.getClass() + "{} packet not registered on the server, packets need to be registered on both sides!");
        }
    }

    @SuppressWarnings("unchecked")
    public <T> boolean isRegisteredOnClient(Class<T> packetClass, class_3222 player) {
        PacketContainer<T> container = (PacketContainer<T>) PACKET_MAP.get(packetClass);
        return container != null && ServerPlayNetworking.canSend(player, container.type().comp_2242());
    }
}
