package com.natamus.collective.networking.packets;

import com.natamus.collective.implementations.networking.data.PacketContext;
import com.natamus.collective.util.CollectiveReference;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public class CollectiveInstalledPacket {
    public static final class_2960 CHANNEL = class_2960.method_60655(CollectiveReference.MOD_ID, "collective_installed_packet");

    public CollectiveInstalledPacket() {
    }

    public static CollectiveInstalledPacket decode(class_2540 buf) {
        return new CollectiveInstalledPacket();
    }

    public void encode(class_2540 buf) {
    }

    public static void handle(PacketContext<CollectiveInstalledPacket> ctx) {
    }
}
