package com.natamus.collective.fabric.services;

import com.natamus.collective.data.Constants;
import com.natamus.collective.services.helpers.RegisterKeyMappingHelper;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import javax.annotation.Nullable;

public class FabricRegisterKeyMappingHelper implements RegisterKeyMappingHelper {
	public @Nullable class_304 registerKeyMapping(String description, int key, String category) {
		if (!Constants.keyMappingCategories.containsKey(category)) {
			return null;
		}

		return registerKeyMapping(description, key, Constants.keyMappingCategories.get(category));
	}
	public class_304 registerKeyMapping(String description, int key, class_304.class_11900 keyMappingCategory) {
		return KeyBindingHelper.registerKeyBinding(new class_304(description, key, keyMappingCategory));
	}
}