package com.natamus.collective.services.helpers;

import com.mojang.datafixers.util.Pair;
import java.util.function.Supplier;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public interface RegisterBlockHelper {
	default <T extends class_2248> void registerBlockWithoutItem(Object modEventBusObject, class_2960 resourceLocation, Supplier<T> blockSupplier) {
		registerBlockWithoutItem(modEventBusObject, resourceLocation, blockSupplier, false);
	}
	<T extends class_2248> void registerBlockWithoutItem(Object modEventBusObject, class_2960 resourceLocation, Supplier<T> blockSupplier, boolean lastBlock);
	class_2248 getRegisteredBlockWithoutItem(class_2960 resourceLocation);

	default <T extends class_2248> void registerBlockWithItem(Object modEventBusObject, class_2960 resourceLocation, Supplier<T> blockSupplier, class_5321<class_1761> creativeModeTabResourceKey) {
		registerBlockWithItem(modEventBusObject, resourceLocation, blockSupplier, creativeModeTabResourceKey, false);
	}
	<T extends class_2248> void registerBlockWithItem(Object modEventBusObject, class_2960 resourceLocation, Supplier<T> blockSupplier, class_5321<class_1761> creativeModeTabResourceKey, boolean lastBlock);
	class_2248 getRegisteredBlockWithItem(class_2960 resourceLocation);

	Pair<class_2248, class_1747> getRegisteredBlockWithItemPair(class_2960 resourceLocation);
	void setRegisteredBlockWithItemPair(class_2960 resourceLocation, Class<?> blockClass, String blockFieldName, Class<?> blockItemClass, String blockItemFieldName);
}