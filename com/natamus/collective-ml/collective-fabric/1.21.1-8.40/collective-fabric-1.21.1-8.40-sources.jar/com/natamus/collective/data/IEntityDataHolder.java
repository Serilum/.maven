package com.natamus.collective.data;

import net.minecraft.class_2487;

public interface IEntityDataHolder {
	class_2487 collective_getStored();

	void collective_setStored(class_2487 data);
}
