package com.natamus.collective.services.helpers;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_5321;

public interface TeleportHelper {
	boolean teleportEntity(class_1297 entity, class_3218 serverLevel, class_243 vec3);
	boolean teleportEntity(class_1297 entity, class_3218 serverLevel, class_2338 blockPos);
	boolean teleportEntity(class_1297 entity, class_5321<class_1937> targetDimension, class_243 vec3);
	boolean teleportEntity(class_1297 entity, class_5321<class_1937> targetDimension, class_2338 blockPos);
}