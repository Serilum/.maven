package com.natamus.collective.fabric.callbacks;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_1927;
import net.minecraft.class_1937;

public class CollectiveExplosionEvents {
	private CollectiveExplosionEvents() { }
	 
	public static final Event<Explosion_Detonate> EXPLOSION_DETONATE = EventFactory.createArrayBacked(Explosion_Detonate.class, callbacks -> (world, sourceEntity, explosion) -> {
		for (Explosion_Detonate callback : callbacks) {
			callback.onDetonate(world, sourceEntity, explosion);
		}
	});
    
	@FunctionalInterface
	public interface Explosion_Detonate {
		 void onDetonate(class_1937 world, class_1297 sourceEntity, class_1927 explosion);
	}
}
