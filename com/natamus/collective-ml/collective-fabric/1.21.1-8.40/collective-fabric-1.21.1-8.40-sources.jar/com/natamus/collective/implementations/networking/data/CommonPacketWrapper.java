package com.natamus.collective.implementations.networking.data;

import net.minecraft.class_2540;
import net.minecraft.class_8710;
import org.jetbrains.annotations.NotNull;

/** The networking code is based on the MIT licensed
 *   <a href="https://github.com/mysticdrew/common-networking">common-networking</a> v1.0.8
 *  by MysticDrew */

public record CommonPacketWrapper<T>(PacketContainer<T> container, T packet) implements class_8710 {
	public void encode(class_2540 buf) {
		container().encoder().accept(packet(), buf);
	}

	@Override
	public @NotNull class_9154<? extends class_8710> method_56479() {
		return container.type();
	}
}
