package com.natamus.collective.schematic;

import it.unimi.dsi.fastutil.io.FastBufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;
import net.minecraft.class_2487;
import net.minecraft.class_2505;
import net.minecraft.class_2507;

public class SchematicFunctions {
	public static class_2487 readCompressed(InputStream inputStream) throws IOException {
		DataInputStream dataInputStream = createDecompressorStream(inputStream);

		class_2487 compoundTag;
		try {
			compoundTag = class_2507.method_10625(dataInputStream, class_2505.method_53898());
		} catch (Throwable t1) {
			if (dataInputStream != null) {
				try {
					dataInputStream.close();
				} catch (Throwable t2) {
					t1.addSuppressed(t2);
				}
			}

			throw t1;
		}

		if (dataInputStream != null) {
			dataInputStream.close();
		}

		return compoundTag;
	}

	private static DataInputStream createDecompressorStream(InputStream inputStream) throws IOException {
		return new DataInputStream(new FastBufferedInputStream(new GZIPInputStream(inputStream)));
	}
}
