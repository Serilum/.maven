package com.natamus.collective.services.helpers;

import net.minecraft.class_2680;

public interface BlockTagsHelper {
	boolean isOre(class_2680 blockState);
	boolean isOre(class_2680 blockState, boolean fuzzyCheck);
}