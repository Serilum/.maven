package com.natamus.collective.services.helpers;

import net.minecraft.class_1799;

public interface ToolFunctionsHelper {
	boolean isTool(class_1799 itemstack);
	boolean isSword(class_1799 itemStack);
	boolean isShield(class_1799 itemStack);
	boolean isPickaxe(class_1799 itemStack);
	boolean isAxe(class_1799 itemStack);
	boolean isShovel(class_1799 itemStack);
	boolean isHoe(class_1799 itemStack);
	boolean isShears(class_1799 itemStack);
	boolean isFlintAndSteel(class_1799 itemStack);
}