package com.natamus.collective.services.helpers;

import java.util.function.Supplier;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public interface RegisterItemHelper {
	default <T extends class_1792> void registerItem(Object modEventBusObject, class_2960 resourceLocation, Supplier<T> itemSupplier, class_5321<class_1761> creativeModeTabResourceKey) {
		registerItem(modEventBusObject, resourceLocation, itemSupplier, creativeModeTabResourceKey, false);
	}
	<T extends class_1792> void registerItem(Object modEventBusObject, class_2960 resourceLocation, Supplier<T> itemSupplier, class_5321<class_1761> creativeModeTabResourceKey, boolean lastItem);

	class_1792 getRegisteredItem(class_2960 resourceLocation);
}