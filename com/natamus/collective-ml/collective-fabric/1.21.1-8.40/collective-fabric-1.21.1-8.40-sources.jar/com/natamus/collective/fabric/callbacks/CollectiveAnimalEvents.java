package com.natamus.collective.fabric.callbacks;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1296;
import net.minecraft.class_1429;
import net.minecraft.class_3218;

public class CollectiveAnimalEvents {
	private CollectiveAnimalEvents() { }
	 
	public static final Event<On_Baby_Spawn> PRE_BABY_SPAWN = EventFactory.createArrayBacked(On_Baby_Spawn.class, callbacks -> (world, parentA, parentB, offspring) -> {
		for (On_Baby_Spawn callback : callbacks) {
			if (!callback.onBabySpawn(world, parentA, parentB, offspring)) {
				return false;
			}
		}
        
		return true;
	});
    
	@FunctionalInterface
	public interface On_Baby_Spawn {
		 boolean onBabySpawn(class_3218 world, class_1429 parentA, class_1429 parentB, class_1296 offspring);
	}
}
