package com.natamus.collective.fabric.callbacks;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class CollectiveAttackEvents {
	private CollectiveAttackEvents() { }
	 
	public static final Event<On_Arrow_Nock> ON_ARROW_NOCK = EventFactory.createArrayBacked(On_Arrow_Nock.class, callbacks -> (item, level, player, hand, hasAmmo) -> {
		for (On_Arrow_Nock callback : callbacks) {
			class_1271<class_1799> resultHolder = callback.onArrowNock(item, level, player, hand, hasAmmo);
			if (!resultHolder.method_5467().equals(class_1269.field_5811)) {
				return resultHolder;
			}
		}
        
		return class_1271.method_22430(item);
	});
    
	@FunctionalInterface
	public interface On_Arrow_Nock {
		 class_1271<class_1799> onArrowNock(class_1799 item, class_1937 level, class_1657 player, class_1268 hand, boolean hasAmmo);
	}
}
