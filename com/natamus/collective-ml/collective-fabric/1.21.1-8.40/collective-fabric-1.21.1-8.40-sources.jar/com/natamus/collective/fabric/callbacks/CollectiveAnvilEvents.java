package com.natamus.collective.fabric.callbacks;

import oshi.util.tuples.Triplet;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1657;
import net.minecraft.class_1706;
import net.minecraft.class_1799;

public class CollectiveAnvilEvents {
	private CollectiveAnvilEvents() { }
	 
	public static final Event<Anvil_Change> ANVIL_CHANGE = EventFactory.createArrayBacked(Anvil_Change.class, callbacks -> (anvilmenu, left, right, output, itemName, baseCost, player) -> {
		for (Anvil_Change callback : callbacks) {
			Triplet<Integer, Integer, class_1799> triple = callback.onAnvilChange(anvilmenu, left, right, output, itemName, baseCost, player);
			if (triple != null) {
				return triple;
			}
		}
        
		return null;
	});
    
	@FunctionalInterface
	public interface Anvil_Change {
		 Triplet<Integer, Integer, class_1799> onAnvilChange(class_1706 anvilmenu, class_1799 left, class_1799 right, class_1799 output, String itemName, int baseCost, class_1657 player);
	}
}
