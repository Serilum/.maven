package com.natamus.collective.services.helpers;

import net.minecraft.class_304;

public interface RegisterKeyMappingHelper {
	class_304 registerKeyMapping(String description, int key, String category);
}