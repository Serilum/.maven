package com.natamus.collective.fabric.callbacks;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_3218;
import net.minecraft.class_638;

public class CollectiveWorldEvents {
	private CollectiveWorldEvents() { }

    public static final Event<World_Unload> WORLD_UNLOAD = EventFactory.createArrayBacked(World_Unload.class, callbacks -> (serverLevel) -> {
        for (World_Unload callback : callbacks) {
        	callback.onWorldUnload(serverLevel);
        }
    });

    public static final Event<Client_World_Load> CLIENT_WORLD_LOAD = EventFactory.createArrayBacked(Client_World_Load.class, callbacks -> (clientLevel) -> {
        for (Client_World_Load callback : callbacks) {
        	callback.onClientWorldLoad(clientLevel);
        }
    });

	@FunctionalInterface
	public interface World_Unload {
		 void onWorldUnload(class_3218 serverLevel);
	}

	@FunctionalInterface
	public interface Client_World_Load {
		 void onClientWorldLoad(class_638 clientLevel);
	}
}
