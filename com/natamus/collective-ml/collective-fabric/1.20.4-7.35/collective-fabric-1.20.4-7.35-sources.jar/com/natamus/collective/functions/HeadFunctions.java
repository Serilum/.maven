package com.natamus.collective.functions;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.natamus.collective.data.GlobalVariables;
import java.util.*;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;

public class HeadFunctions {
	public static class_1799 getPlayerHead(String playername, Integer amount) {
		String nameIdJsonString = DataFunctions.readStringFromURL(GlobalVariables.playerdataurl + playername.toLowerCase());
		if (nameIdJsonString.equals("")) {
			return null;
		}

		try {
			Map<String, String> nameIdJson = new Gson().fromJson(nameIdJsonString, new TypeToken<HashMap<String, String>>() {}.getType());

			String headName = nameIdJson.get("name");
			String headUUID = nameIdJson.get("id");

			String profileJsonString = DataFunctions.readStringFromURL(GlobalVariables.skindataurl + headUUID);
			if (profileJsonString.equals("")) {
				return null;
			}

			String[] rawValue = profileJsonString.replaceAll(" ", "").split("value\":\"");

			String texturevalue = rawValue[1].split("\"")[0];
			String d = new String(Base64.getDecoder().decode((texturevalue.getBytes())));

			String texture = Base64.getEncoder().encodeToString((("{\"textures\"" + d.split("\"textures\"")[1]).getBytes()));
			String oldid = new UUID(texture.hashCode(), texture.hashCode()).toString();

			return HeadFunctions.getTexturedHead(headName + "'s Head", texture, oldid, 1);
		}
		catch (ArrayIndexOutOfBoundsException ignored) { }

		return null;
	}
	
	public static class_1799 getTexturedHead(String headname, String texture, String oldid, Integer amount) {
		class_1799 texturedhead = new class_1799(class_1802.field_8575, amount);
		
		List<Integer> intarray = UUIDFunctions.oldIdToIntArray(oldid);
		
		class_2487 skullOwner = new class_2487();
		skullOwner.method_10572("Id", intarray);
		
		class_2487 properties = new class_2487();
		class_2499 textures = new class_2499();
		class_2487 tex = new class_2487();
		tex.method_10582("Value", texture);
		textures.add(tex);

		properties.method_10566("textures", textures);
		skullOwner.method_10566("Properties", properties);
		texturedhead.method_7959("SkullOwner", skullOwner);
		
		class_2561 tcname = class_2561.method_43470(headname);
		texturedhead.method_7977(tcname);		
		return texturedhead;
	}
	
	public static boolean hasStandardHead(String mobname) {
        return mobname.equals("creeper") || mobname.equals("zombie") || mobname.equals("skeleton");
    }
}
