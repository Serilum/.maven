package com.natamus.collective.services.helpers;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2424;

public interface EventTriggerHelper {
    void triggerNetherPortalSpawnEvent(class_1937 level, class_2338 portalPos, class_2424 size);
}