package com.natamus.collective.implementations.networking.data;

import net.minecraft.class_1657;

/** The networking code is based on the MIT licensed
 *   <a href="https://github.com/mysticdrew/common-networking">common-networking</a> v1.0.6
 *  by MysticDrew */

public record PacketContext<T>(class_1657 sender, T message, Side side) {
    public PacketContext(T message, Side side) {
        this(null, message, side);
    }
}
