package com.natamus.collective.implementations.networking.data;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/** The networking code is based on the MIT licensed
 *   <a href="https://github.com/mysticdrew/common-networking">common-networking</a> v1.0.6
 *  by MysticDrew */

public record PacketContainer<T>(class_2960 packetIdentifier,
                                 Class<T> messageType,
                                 BiConsumer<T, class_2540> encoder,
                                 Function<class_2540, T> decoder,
                                 Consumer<PacketContext<T>> handler)
{
}
