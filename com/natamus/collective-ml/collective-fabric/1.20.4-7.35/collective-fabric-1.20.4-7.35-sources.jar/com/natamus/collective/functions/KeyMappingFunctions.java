package com.natamus.collective.functions;

import net.minecraft.class_304;
import net.minecraft.class_3675;

public class KeyMappingFunctions {
    public static class_3675.class_306 getKey(class_304 keyMapping) {
        return keyMapping.field_1655;
    }
}