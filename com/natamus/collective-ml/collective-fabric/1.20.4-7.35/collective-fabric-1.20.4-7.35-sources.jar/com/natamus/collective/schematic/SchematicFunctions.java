package com.natamus.collective.schematic;

import it.unimi.dsi.fastutil.io.FastBufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;
import net.minecraft.class_2487;
import net.minecraft.class_2505;
import net.minecraft.class_2507;

public class SchematicFunctions {
    public static class_2487 readCompressed(InputStream $$0) throws IOException {
        DataInputStream dataInputStream = createDecompressorStream($$0);

        class_2487 var2;
        try {
            var2 = class_2507.method_10625(dataInputStream, class_2505.method_53898());
        } catch (Throwable var5) {
            if (dataInputStream != null) {
                try {
                    dataInputStream.close();
                } catch (Throwable var4) {
                    var5.addSuppressed(var4);
                }
            }

            throw var5;
        }

        if (dataInputStream != null) {
            dataInputStream.close();
        }

        return var2;
    }

    private static DataInputStream createDecompressorStream(InputStream $$0) throws IOException {
        return new DataInputStream(new FastBufferedInputStream(new GZIPInputStream($$0)));
    }
}
